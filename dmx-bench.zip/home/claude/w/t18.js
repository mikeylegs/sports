const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2]; const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx'));
fs.copyFileSync(FILE,path.join(d,'artnet-controller.js')); fs.mkdirSync(path.join(d,'logs'));
const ev=[{k:'start',src:'bridge',t:0},{k:'a',mime:'audio/mp4',ext:'m4a',t:1000}]; for(let i=0;i<300;i++) ev.push({k:'f',t:i*100,e:[0.3,0.01,0.02,0.01]});
for(let t=2000;t<20000;t+=500) ev.push({k:'h',b:1,s:0.5,r:2,t});
fs.writeFileSync(path.join(d,'logs','bridge-20260926-140000.ndjson'),ev.sort((a,b)=>a.t-b.t).map(e=>JSON.stringify(e)).join('\n')+'\n');
fs.writeFileSync(path.join(d,'logs','bridge-20260926-140000.m4a'),Buffer.alloc(100));
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'});
const B='http://127.0.0.1:8080'; let fails=0,n=0; const ok=(c,m)=>{n++; if(!c){fails++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{ await sleep(800); const {JSDOM}=require('jsdom');
  const v=new JSDOM(await (await fetch(B+'/logs/bridge-20260926-140000.ndjson')).text(),{runScripts:'outside-only',url:B+'/logs/x'}).window;
  v.HTMLCanvasElement.prototype.getContext=()=>new Proxy({},{get:(t,k)=>k==='measureText'?()=>({width:0}):(k in t?t[k]:()=>{}),set:(t,k,x)=>{t[k]=x;return true;}});
  v.fetch=(u,o)=>fetch(B+u,o); let raf=[]; v.requestAnimationFrame=f=>{ raf.push(f); return raf.length; };
  v.eval([...v.document.querySelectorAll('script')].map(x=>x.textContent).join('\n'));
  for(let i=0;i<30 && !v.eval('TL');i++) await sleep(100);
  const sel=v.document.getElementById('strb'); ok(!!sel,'strobe preview picker');
  if(!sel){ console.log(`${n-fails}/${n} passed`); p.kill(); process.exit(1); }
  const aud=v.document.getElementById('aud'); let ct=0, paused=true; Object.defineProperty(aud,'currentTime',{get:()=>ct,set:x=>{ct=x;}}); Object.defineProperty(aud,'paused',{get:()=>paused});
  const fx=v.document.getElementById('strbfx'); let flashes=0; v.__cnt=()=>flashes++; v.eval('var __sf=strbFlash; strbFlash=function(){ __cnt(); __sf(); };');
  sel.value='g'; sel.dispatchEvent(new v.Event('change'));   await sleep(200); ok(/No beat grid/.test(v.document.getElementById('strbmsg').textContent),'no grid: says why instead of doing nothing');
  sel.value=''; sel.dispatchEvent(new v.Event('change'));
  sel.value='r'; sel.dispatchEvent(new v.Event('change')); ok(/36 flashes/.test(v.document.getElementById('strbmsg').textContent),'reactive: 36 kick flashes listed');
  const step=async ms=>{ ct+=ms/1000; const f=raf; raf=[]; f.forEach(x=>x(0)); await sleep(1); };
  paused=false; ct=(2000-1000)/1000-0.05;   // audio 0.95 s = event time 1950 ms
  const f0=()=>flashes; for(let i=0;i<60;i++) await step(1000/60);   // 1 s of playback: event 1950..2950 -> hits at 2000 and 2500
  await sleep(80); ok(flashes===2,'1 s of playback flashes exactly twice ('+flashes+')');
  ok(fx.style.opacity==='0','flash turns off again');
  ct=15.02; await step(0); await step(1000/60); await sleep(80); ok(flashes===2,'seek forward: no backlog burst ('+flashes+')');
  paused=true; const before=flashes; for(let i=0;i<60;i++) await step(1000/60); ok(flashes===before,'paused: no flashes');
  sel.value=''; sel.dispatchEvent(new v.Event('change')); ok(fx.style.opacity==='0','off');
  console.log(`${n-fails}/${n} passed`); p.kill(); process.exit(fails?1:0);
})().catch(e=>{console.log('ERR',e.message); p.kill(); process.exit(2);});
