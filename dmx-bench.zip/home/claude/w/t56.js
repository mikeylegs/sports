// 27h body layer (Govee-style envelope on the PAR dimmer) + pavilion POV stage with the Govee strip
const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2]; const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx'));
fs.copyFileSync(FILE,path.join(d,'artnet-controller.js')); fs.mkdirSync(path.join(d,'logs')); fs.mkdirSync(path.join(d,'tracks'));
fs.copyFileSync('/mnt/user-data/uploads/track-15337193-247718.ndjson',path.join(d,'logs','track-15337193-247718.ndjson'));
fs.writeFileSync(path.join(d,'tracks','Chris Lake, Green Velvet - Deceiver (Max Styler Remix).m4a'),Buffer.alloc(100));
fs.writeFileSync(path.join(d,'settings.json'),JSON.stringify({targetIP:'127.0.0.1'}));
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'});
const B='http://127.0.0.1:8080'; let fails=0,n=0; const ok=(c,m)=>{n++; if(!c){fails++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const post=(u,b)=>fetch(B+u,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)});
const body=async()=>(await (await fetch(B+'/liveshow')).json()).body;
(async()=>{ await sleep(800); const {JSDOM}=require('jsdom');
  await post('/liveshow',{enabled:true}); await post('/bridgestate',{levels:[0.3,0,0,0],active:[true,false,false,false],hits:[1,0,0,0],recording:true,build:'x'});
  for(let i=0;i<10;i++){ await post('/lv',{k:0.3,a:0.5}); await sleep(33); }
  let b=await body(); ok(b && b.active && b.dim>=240,'loud kick level: PARs near full ('+(b&&b.dim)+')');
  await post('/lv',{k:0.0}); await sleep(400); await post('/lv',{k:0.0}); b=await body(); ok(b.dim>5 && b.dim<90,'400 ms after the sound stops: falling (~2 half-lives) ('+b.dim+')');
  for(let i=0;i<15;i++){ await post('/lv',{k:0.005}); await sleep(33); } b=await body(); ok(b.dim<=10,'below the noise floor: fades out to (near) off ('+b.dim+')');
  for(let i=0;i<10;i++){ await post('/lv',{k:0.1}); await sleep(33); } b=await body(); ok(b.dim>40 && b.dim<200,'a quieter passage glows, not full (vs the recent peak) ('+b.dim+')');
  await post('/livecue',{washIdx:4}); for(let i=0;i<6;i++){ await post('/lv',{k:0}); await sleep(60); } b=await body(); ok(b.dim===255,'the drop boom holds the PARs at full over the body for a bar');
  await post('/liveshow',{enabled:false});
  // viewer
  const v=new JSDOM(await (await fetch(B+'/logs/track-15337193-247718.ndjson')).text(),{runScripts:'outside-only',url:B+'/logs/x'}).window;
  v.HTMLCanvasElement.prototype.getContext=()=>new Proxy({},{get:(t,k)=>k==='measureText'?()=>({width:0}):(k in t?t[k]:()=>{}),set:(t,k,x)=>{t[k]=x;return true;}});
  v.fetch=(u,o)=>fetch(B+u,o); v.requestAnimationFrame=()=>0; v.eval([...v.document.querySelectorAll('script')].map(x=>x.textContent).join('\n'));
  for(let i=0;i<50 && !v.eval('TL');i++) await sleep(100);
  const $=id=>v.document.getElementById(id); ok($('stBg') && /data:image\/jpeg;base64/.test($('stBg').getAttribute('style')) && $('stWash') && $('stGv') && $('stGvLine'),'pavilion backdrop, PAR wash, Govee strip');
  v.eval('ensureLivePlan()'); for(let i=0;i<900 && !v.eval('!!TL.rigLive');i++) await sleep(100); v.eval('TL.rig=TL.rigLive');
  // a loud groove moment vs the quiet pad in the 3:01 breakdown
  const E=JSON.parse(v.eval("JSON.stringify(TL.ev.filter(function(e){return e.k==='f';}).map(function(f){return [f.t,f.e[0]];}))"));
  const loud=E.filter(x=>x[0]>100000 && x[0]<130000).sort((a,b)=>b[1]-a[1])[0][0], quiet=E.filter(x=>x[0]>181000 && x[0]<195000).sort((a,b)=>a[1]-b[1])[0][0];
  v.eval('stagePaint('+loud+')'); const wl=parseFloat($('stWash').style.opacity), gl=parseFloat($('stGv').style.opacity);
  v.eval('stagePaint('+(quiet+50)+')'); const wq=parseFloat($('stWash').style.opacity), gq=parseFloat($('stGv').style.opacity);
  ok(wl>0.6 && wq<wl/2,'PAR wash pumps with the kick: loud '+wl+' vs quiet '+wq); ok(gl>0.5 && gq<gl,'Govee strip follows the sound: '+gl+' vs '+gq);
  v.document.getElementById('stagebtn').click(); await sleep(200); const chips=[...v.document.querySelectorAll('#stChips button')].map(b=>b.dataset.f); ok(chips.includes('gv'),'Govee chip to isolate it');
  v.close(); console.log(`${n-fails}/${n} passed`); p.kill(); process.exit(fails?1:0);
})().catch(e=>{ console.log('ERR',e.stack); p.kill(); process.exit(2); });
