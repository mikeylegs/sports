// 27g controller: build ramp + breath + drop explosion; burst switch; reactive v2 beat follower
const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2]; const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx'));
fs.copyFileSync(FILE,path.join(d,'artnet-controller.js')); fs.writeFileSync(path.join(d,'settings.json'),JSON.stringify({targetIP:'127.0.0.1'}));
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'});
const B='http://127.0.0.1:8080'; let fails=0,n=0; const ok=(c,m)=>{n++; if(!c){fails++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const post=(u,b)=>fetch(B+u,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)});
const log=async()=>(await (await fetch(B+'/liveshow')).json()).log;
const snap=o=>post('/bridgestate',{levels:[0.3,0,0,0],active:[true,false,false,false],hits:[1,0,0,0],recording:true,build:'x',live:Object.assign({beatMs:480,nextBeatIn:0,pb:8,groove:false,mode:'none',slvl:0,kickOn:false,hatsOn:false,washIdx:3,washNextIn:null,bpm:125,build:true,rise:0.8},o)});
(async()=>{ await sleep(800);
  await fetch(B+'/liveshow',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({strobe:'full'})});   // 27s: this suite tests the FULL strobe behaviour
  await post('/liveshow',{enabled:true,latencyMs:0});
  // 27j: in a build the strobe follows the snare roll (band-2 hits) at full speed; the breath still comes one beat before the predicted 1
  let T0=Date.now(); await snap({nextPhraseIn:1920}); for(let k=0;k<12;k++){ await post('/bridgehit',{band:2,strength:2}); await sleep(100); } await sleep(500); let L=(await log()).filter(x=>x.t>=T0);
  const fl=L.filter(x=>x.kind==='flash').map(x=>x.t-T0), gaps=fl.slice(1).map((t,i)=>t-fl[i]);
  ok(fl.length>=8 && Math.min(...gaps)>=85,'build: flashes follow the snare roll ('+fl.length+' flashes, min gap '+Math.min(...gaps)+' ms)');
  ok(L.some(x=>x.kind==='black' && Math.abs(x.t-T0-1440)<=80),'the breath: blackout one beat before the predicted 1');
  T0=Date.now(); await post('/livecue',{washIdx:5}); await sleep(400); L=(await log()).filter(x=>x.t>=T0);
  ok(L.filter(x=>x.kind==='flash' && (x.why==='drop'||x.why==='boom')).length===4 && L.some(x=>x.kind==='wash' && x.why==='cue' && x.fade===0),'the drop explodes: 4-flash burst + hard colour cut');
  // burst off -> the roll is capped at 4/s
  await post('/liveshow',{burst:false}); T0=Date.now(); await snap({nextPhraseIn:6*1920}); for(let k=0;k<10;k++){ await post('/bridgehit',{band:2,strength:2}); await sleep(100); } L=(await log()).filter(x=>x.t>=T0 && x.kind==='flash').map(x=>x.t-T0);
  ok(L.length>=2 && L.slice(1).every((t,i)=>t-L[i]>=240),'Build burst OFF: the roll is capped at 4 flashes/s');
  await post('/liveshow',{burst:true});
  // no kick and no roll in a build: nothing
  await sleep(2100); T0=Date.now(); await snap({nextPhraseIn:6*1920}); await sleep(1100); L=(await log()).filter(x=>x.t>=T0 && x.kind==='flash');
  ok(L.length===0,'build with no roll and no kick: no strobe ('+L.length+')');
  // reactive v2: no grid, kicks every 480 ms -> locks, then fires on the predicted beats; an off-beat hit is ignored
  await sleep(2300);   // snapshot goes stale -> reactive
  await post('/bridgestate',{levels:[0.3,0,0,0],active:[true,false,false,false],hits:[1,0,0,0],recording:true,build:'x'});
  let s=await (await fetch(B+'/liveshow')).json(); ok(s.mode==='reactive','no grid: reactive');
  T0=Date.now(); for(let k=0;k<5;k++){ await post('/bridgehit',{band:1,strength:2}); await sleep(480); if(k%2) await post('/bridgestate',{levels:[0.3,0,0,0],active:[true,false,false,false],hits:[1,0,0,0],recording:true,build:'x'}); }
  await sleep(200); await post('/bridgehit',{band:1,strength:2}); await sleep(900);
  L=(await log()).filter(x=>x.t>=T0); ok(L.some(x=>x.kind==='lock'),'beat follower locks after a few even kicks');
  const pr=L.filter(x=>x.kind==='flash' && x.why==='predicted'); ok(pr.length>=2,'then flashes on the predicted beats ('+pr.length+')');
  console.log(`${n-fails}/${n} passed`); p.kill(); process.exit(fails?1:0);
})().catch(e=>{ console.log('ERR',e.stack); p.kill(); process.exit(2); });
