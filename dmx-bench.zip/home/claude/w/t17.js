const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2], SRC=fs.readFileSync(FILE,'utf8'); const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx'));
fs.copyFileSync(FILE,path.join(d,'artnet-controller.js')); fs.mkdirSync(path.join(d,'logs'));
let fails=0,n=0; const ok=(c,m)=>{n++; if(!c){fails++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const TDJ=(SRC.match(/const TRACK_DETECT_JS = `([\s\S]*?)`;/)||[])[1]; const g={}; new Function('G',TDJ+';G.a=tdAnalyze;')(g);
// 128 BPM: groove 0-31, break 32-47 (riser), DROP 48-79, break 80-91, 1-bar fake kick 92, out 93-95, DROP 96-111
const sr=44100, BL=60/128, bars=112, N=Math.ceil(bars*4*BL*sr)+sr, a=new Float32Array(N); let seed=3; const rnd=()=>((seed=(seed*16807)%2147483647)/2147483647)*2-1;
const kickOn=bar=>(bar<32)||(bar>=48&&bar<80)||bar===92||bar>=96;
for(let i=0;i<N;i++) a[i]=rnd()*0.004;
for(let b=0;b<bars*4;b++){ const bar=Math.floor(b/4), s0=Math.floor(b*BL*sr);
  if(kickOn(bar)) for(let j=0;j<sr*0.15&&s0+j<N;j++) a[s0+j]+=0.8*Math.sin(2*Math.PI*60*j/sr)*Math.exp(-j/sr/0.05);
  if(b%2===1) for(let j=0;j<sr*0.04&&s0+j<N;j++) a[s0+j]+=0.3*Math.sin(2*Math.PI*2000*j/sr)*Math.exp(-j/sr/0.015);
  const h=Math.floor((b+0.5)*BL*sr); for(let j=0;j<sr*0.03&&h+j<N;j++) a[h+j]+=0.15*Math.sin(2*Math.PI*8000*j/sr+rnd())*Math.exp(-j/sr/0.008);
  if((bar>=40&&bar<48)||(bar>=88&&bar<92)) for(let j=0;j<BL*sr&&s0+j<N;j++) a[s0+j]+=rnd()*0.05*((bar%8)+1)/8; }   // risers
(async()=>{
  const cfg={bands:[{lo:40,hi:120,sens:1.5},{lo:1000,hi:4000,sens:1.05},{lo:6000,hi:12000,sens:1.3},{lo:12000,hi:16000,sens:1.3}]};
  const out=await new Promise(r=>g.a([a],sr,cfg.bands,()=>{},r));
  const ev=[{k:'start',src:'bridge',t:0}].concat(out.ft.map((t,i)=>({k:'f',e:out.frames.map(f=>f[i]),t})),out.hits).sort((x,y)=>x.t-y.t);
  const ms=bar=>Math.round(bar*4*BL*1000);
  fs.writeFileSync(path.join(d,'logs','bridge-20260926-100000.ndjson'),ev.concat([{k:'m',label:'drop',t:ms(48),post:true},{k:'m',label:'drop',t:ms(96),post:true},{k:'m',label:'drop',t:ms(20),post:true}]).map(e=>JSON.stringify(e)).join('\n')+'\n');
  const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'}); await sleep(800); const B='http://127.0.0.1:8080';
  const {JSDOM}=require('jsdom'); const html=await (await fetch(B+'/logs/bridge-20260926-100000.ndjson')).text();
  const v=new JSDOM(html,{runScripts:'outside-only'}).window;
  v.HTMLCanvasElement.prototype.getContext=()=>new Proxy({},{get:(t,k)=>k==='measureText'?()=>({width:0}):(k in t?t[k]:()=>{}),set:(t,k,x)=>{t[k]=x;return true;}});
  v.fetch=(u,o)=>fetch(B+u,o);
  v.eval([...v.document.querySelectorAll('script')].map(x=>x.textContent).join('\n'));
  for(let i=0;i<50 && !v.eval('TL');i++) await sleep(100);
  ok(v.eval('!!(TL&&TL.sec)'),'full-file phrase view present');
  const btn=v.document.getElementById('czbtn'); ok(!!btn,'Causal replay button');
  if(!btn){ console.log(`${n-fails}/${n} passed`); p.kill(); process.exit(1); }
  const seen=[]; v.eval('var __AS=analyzeSections;'); v.__rec=x=>seen.push(x);
  v.eval('analyzeSections=function(ev){ var m=0, mk=false; ev.forEach(function(e){ if(e.t>m) m=e.t; if(e.k==="m") mk=true; }); __rec({max:m, mk:mk}); return __AS(ev); };');
  btn.click(); for(let i=0;i<600 && !v.eval('TL.cz');i++) await sleep(100);
  const z=v.eval('TL.cz'); ok(!!z,'replay finished');
  const G=z.gate; ok(!!G,'gate simulation present');
  if(!G){ console.log(`${n-fails}/${n} passed`); p.kill(); process.exit(1); }
  const R=G.react, F=G.gated.filter(x=>x.fire), rb=R.filter(x=>!x.want).length, gb=F.filter(x=>!x.want).length, miss=G.gated.filter(x=>x.missed).length, grooveHits=R.filter(x=>x.want&&!x.dbl).length;
  console.log('   reactive',R.length,'unwanted',rb,'dbl',R.filter(x=>x.dbl).length,'| gated',F.length,'unwanted',gb,'missed',miss,'of groove hits',grooveHits);
  ok(R.length===v.eval("TL.ev.filter(function(e){return e.k==='h'&&laneOf(e)===0;}).length"),'reactive = every kick-band hit');
  ok(rb>50,'reactive fires in the breakdowns (synthetic leakage) ('+rb+')');
  ok(gb<=rb/5,'gated cuts breakdown flashes by 80%+ ('+rb+' -> '+gb+')');
  ok(F.every((x,i)=>!i || x.t-F[i-1].t>=150),'gated never fires twice within 150 ms');
  { const T0=z.lane.find(g=>g.st).T, m2=G.gated.filter(x=>x.missed && x.t>=T0).length, g2=R.filter(x=>x.want&&!x.dbl&&x.t>=T0).length;
    ok(m2<=0.15*g2,'once the live view exists, gated misses at most 15% of groove kicks ('+m2+'/'+g2+'; dark before '+(T0/1000).toFixed(0)+' s by design)');
    ok(!G.gated.some(x=>x.fire && x.t<T0),'no flashes before the live view exists'); }
  ok(/Kick strobe, reactive/.test(v.document.getElementById('czout').innerHTML) && /section-gated/.test(v.document.getElementById('czout').innerHTML),'summary lines');
  // vacuity inside: a gate that is always open must equal reactive minus doubles
  const open=G.gated.filter(x=>x.fire).length<=R.length; ok(open,'gated fires no more than reactive');
  console.log(`${n-fails}/${n} passed`); p.kill(); process.exit(fails?1:0);
})().catch(e=>{console.log('ERR',e.stack); process.exit(2);});
