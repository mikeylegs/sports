// Link as the grid source: synthetic djay Link data for Odd Mob (exact tempo, djay clock 40 ms ahead of the speakers)
const fs=require('fs'); const {G}=require('./t28.js'); let n=0,f=0; const ok=(c,m)=>{n++; if(!c){f++; console.log('FAIL',m);} };
const ev=fs.readFileSync('/mnt/user-data/uploads/track-96314428-446959.ndjson','utf8').trim().split('\n').map(JSON.parse);
const full=G.AS(ev), beats=[]; full.bars.forEach(b=>{ const L=(b.t1-b.t)/4; for(let q=0;q<4;q++) beats.push(b.t+q*L); });
const P=(full.bars[60].t1-full.bars[60].t)/4, t0=full.bars[0].t;   // true beat grid (hindsight) = the reference
const bpos=t=>{ let lo=0,hi=beats.length-1; while(lo<hi){ const m=(lo+hi+1)>>1; if(beats[m]<=t) lo=m; else hi=m-1; } const k=Math.min(lo,beats.length-2); return k+(t-beats[k])/(beats[k+1]-beats[k]); };
const mkLink=(bpm,off)=>{ const out=[]; for(let t=500;t<ev[ev.length-1].t;t+=250){ const tl=t-off; out.push({k:'l', b:+(bpm===120?(t/500):bpos(tl)).toFixed(4), bpm:bpm, rtt:6, t:Math.round(t+3)}); } return out; };   // djay's grid = the true beats, its clock 'off' ms ahead
const withL=ev.concat(mkLink(+(60000/P).toFixed(2),-40)).sort((a,b)=>a.t-b.t);
const r=G.AS(withL); ok(r.src==='Link','Link grid used when it agrees with the kicks'); ok(r.linkShift!=null && Math.abs(r.linkShift-40)<=12,'Link grid slid onto the kicks by ~40 ms ('+(r.linkShift&&r.linkShift.toFixed(1))+')');
const stuck=G.AS(ev.concat(mkLink(120,0)).sort((a,b)=>a.t-b.t)); ok(stuck.src==='kick','a stuck 120 Link is ignored (grid from the kicks)');
function live(E0){ const E=E0.filter(e=>e.k==='f'||e.k==='h'||e.k==='l').sort((a,b)=>a.t-b.t), L=new G.LE(), er=[]; let i=0;
  const near=t=>{ let lo=0,hi=beats.length-1; while(lo<hi){ const m=(lo+hi)>>1; if(beats[m]<t) lo=m+1; else hi=m; } return Math.min(Math.abs(beats[lo]-t), lo?Math.abs(beats[lo-1]-t):1e9); };
  let firstGroove=null; for(let now=0; now<=E[E.length-1].t; now+=100){ while(i<E.length && E[i].t<=now) L.push(E[i++]); L.step(now); if(now%300===0){ const s=L.snap(now); if(s && s.groove){ if(firstGroove===null) firstGroove=now; er.push(near(now+s.nextBeatIn)); } } }
  er.sort((a,b)=>a-b); return {med:er[er.length>>1], p90:er[Math.floor(er.length*0.9)], n:er.length, first:firstGroove}; }
const a=live(ev), b=live(withL);
console.log('   live predicted beat vs hindsight grid — audio only: median',Math.round(a.med),'p90',Math.round(a.p90),'| with Link: median',Math.round(b.med),'p90',Math.round(b.p90));
ok(b.med<=20 && b.med<a.med/2 && b.p90<a.p90/3,'Odd Mob live beat prediction with Link: '+Math.round(b.med)+' ms median (audio only: '+Math.round(a.med)+')');
console.log(`${n-f}/${n} passed`); process.exit(f?1:0);
