// controller live-show scheduler: predictive firing times, wash changes, cues, on/off
const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2]; const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx'));
fs.copyFileSync(FILE,path.join(d,'artnet-controller.js')); fs.writeFileSync(path.join(d,'settings.json'),JSON.stringify({targetIP:'127.0.0.1'}));
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'});
const B='http://127.0.0.1:8080'; let fails=0,n=0; const ok=(c,m)=>{n++; if(!c){fails++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const post=(u,b)=>fetch(B+u,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)}).then(r=>r.json());
const snap=(o)=>post('/bridgestate',{levels:[0,0,0,0],active:[false,false,false,false],hits:[0,0,0,0],recording:true,build:'x',live:Object.assign({beatMs:480,nextBeatIn:300,pb:5,groove:true,mode:'heavy',slvl:1,kickOn:true,hatsOn:false,washIdx:3,washNextIn:700,bpm:125},o||{})});
const get=()=>fetch(B+'/liveshow').then(r=>r.json());
(async()=>{ await sleep(800);
  await fetch(B+'/liveshow',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({strobe:'full'})});   // 27s: this suite tests the FULL strobe behaviour
  let c=await get(); ok(c.enabled===false && c.latencyMs===80,'off by default, latency 80 ms');
  if(c.enabled!==false){ console.log(`${n-fails}/${n} passed`); p.kill(); process.exit(1); }
  await snap(); await sleep(900); c=await get(); ok(!c.log.some(x=>x.kind==='flash'),'switched off: nothing fires');
  await post('/liveshow',{enabled:true}); await post('/bridgehit',{band:1,strength:2}); let T0=Date.now(); await snap(); await sleep(1300); c=await get();
  const fl=c.log.filter(x=>x.kind==='flash' && x.t>=T0).map(x=>x.t-T0), wa=c.log.filter(x=>x.kind==='wash' && x.t>=T0);
  console.log('   flashes at (ms after the snapshot):',fl.join(', '),'| wash:',wa.map(x=>(x.t-T0)+'ms #'+x.idx+' '+x.why).join(', '));
  ok(fl.length>=2 && Math.abs(fl[0]-(300-80))<=30 && (Math.abs(fl[1]-(780-80))<=30 || Math.abs(fl[1]-620)<=30),'heavy groove: flashes at the predicted beats minus 80 ms (≈220, ≈700; 27w: this test\'s off-beat phrase change at ≈620 now fires a phrase accent that takes the 700 slot)');
  ok(wa.some(x=>x.why==='sync' && x.idx===3) && wa.some(x=>x.why==='phrase' && x.idx===4 && Math.abs(x.t-T0-620)<=30),'wash: synced to #3, then #4 at the predicted phrase change minus 80 ms');
  await post('/liveshow',{latencyMs:0}); T0=Date.now(); await snap({mode:'hats',slvl:0.45,hatsOn:true,kickOn:true,washIdx:4,washNextIn:null}); await sleep(900); c=await get();
  const fh=c.log.filter(x=>x.kind==='flash' && x.t>=T0+30);
  ok(fh.length<=1,'lighter groove: the downbeat only, no off-beat flashes ('+fh.length+')');
  T0=Date.now(); await snap({groove:false,mode:'none',washNextIn:null,washIdx:4}); await sleep(800); c=await get();
  ok(!c.log.some(x=>x.kind==='flash' && x.t>=T0+10),'break: no strobe');
  T0=Date.now(); await post('/livecue',{washIdx:5}); await sleep(100); c=await get();
  ok(c.log.some(x=>x.kind==='flash' && x.why==='drop' && x.lvl===1 && x.t>=T0) && c.log.some(x=>x.kind==='wash' && x.idx===5 && x.why==='cue'),'drop cue: full flash + next colour at once');
  T0=Date.now(); await sleep(2300); await sleep(700); c=await get(); ok(c.stale && !c.log.some(x=>x.kind==='flash' && x.t>=T0+400),'no snapshots for 2 s: stops firing (after the drop burst has finished)');
  ok((await fetch(B+'/liveshow',{method:'POST',body:JSON.stringify({latencyMs:999})})).status===400,'bad latency rejected');
  ok(JSON.parse(fs.readFileSync(path.join(d,'liveshow.json'),'utf8')).enabled===true,'switch state persisted');
  const sh=await (await fetch(B+'/lab/show')).text(); ok(/LIVE SHOW/.test(sh.replace(/\\u25[a-f0-9]{2}/g,'')) || /id="sw"/.test(sh),'Show tab served');
  console.log(`${n-fails}/${n} passed`); p.kill(); process.exit(fails?1:0);
})().catch(e=>{ console.log('ERR',e.stack); p.kill(); process.exit(2); });
