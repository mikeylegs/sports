// every TRUE drop (drum stems) across the tracks: crisp (first flash within +-60 ms of the kick) / sloppy / no flash; false drop bursts
const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2]; const TR=[['dare',134.03],['meduza',126],['deceiver',126.98],['vision',130.05],['espresso',126],['dtmf',130],['dolce',130]];
const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx')); fs.copyFileSync(FILE,path.join(d,'artnet-controller.js')); fs.mkdirSync(path.join(d,'logs'));
TR.forEach((t,i)=>fs.copyFileSync('/tmp/'+t[0]+(process.env.SUF||'-27o')+'.ndjson',path.join(d,'logs','track-9000000'+i+'-000001.ndjson')));
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'}); const B='http://127.0.0.1:8080'; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{ await sleep(800); const {JSDOM}=require('jsdom'); const T={D:0,crisp:0,sloppy:0,none:0,fake:0}; const rows=[];
 for(let i=0;i<TR.length;i++){ const nm='track-9000000'+i+'-000001.ndjson', beat=60000/TR[i][1];
  const v=new JSDOM(await (await fetch(B+'/logs/'+nm)).text(),{runScripts:'outside-only',url:B+'/logs/x'}).window;
  v.HTMLCanvasElement.prototype.getContext=()=>new Proxy({},{get:(t,k)=>k==='measureText'?()=>({width:0}):(k in t?t[k]:()=>{}),set:(t,k,x)=>{t[k]=x;return true;}});
  v.fetch=(u,o)=>fetch(B+u,o); v.requestAnimationFrame=()=>0; v.eval([...v.document.querySelectorAll('script')].map(x=>x.textContent).join('\n'));
  for(let j=0;j<50 && !v.eval('TL');j++) await sleep(100); await sleep(150); v.eval('ensureLivePlan()'); for(let j=0;j<900 && !v.eval('!!TL.rigLive');j++) await sleep(100);
  const P=JSON.parse(v.eval('JSON.stringify(TL.rigLive)')); const K=JSON.parse(fs.readFileSync('/tmp/'+TR[i][0]+'Kick.json')).map(x=>x*1000);
  const D=K.filter((k,q)=>q>0 && k-K[q-1]>=16*beat && k>5000); const row=[];
  D.forEach(x=>{ T.D++; const fl=P.strobe.filter(t=>t>=x-2*beat && t<=x+2*beat); const f0=fl.length?fl.reduce((b,t)=>Math.abs(t-x)<Math.abs(b-x)?t:b):null;
    if(f0===null){ T.none++; row.push((x/1000).toFixed(1)+':none'); } else if(Math.abs(f0-x)<=60){ T.crisp++; row.push((x/1000).toFixed(1)+':'+Math.round(f0-x)); } else { T.sloppy++; row.push((x/1000).toFixed(1)+':'+Math.round(f0-x)+'!'); } });
  const fake=(P.boom||[]).concat(P.d1||[]).filter(b=>!D.some(x=>Math.abs(x-b)<=2*beat)).sort((a,b)=>a-b).filter((b,i,a)=>!i||b-a[i-1]>1500); T.fake+=fake.length;   // 28s: predicted drop hits count too
  rows.push(TR[i][0]+' '+row.join(' ')+(fake.length?' | bursts with no drop: '+fake.map(b=>(b/1000).toFixed(1)).join(','):''));
  v.close(); }
 rows.forEach(r=>console.log('   '+r)); console.log(`ALL ${T.D} drops: crisp ${T.crisp} · sloppy ${T.sloppy} · no flash ${T.none} · bursts where there's no drop ${T.fake}`);
 p.kill(); process.exit(0); })();
