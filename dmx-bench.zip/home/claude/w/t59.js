// 27k pump-onset kick detection: synthetic audio -- kicks on a sustained sub-bass (the 'Dare' case), plain kicks, bass only
const fs=require('fs'); const FILE=process.argv[2]; const SRC=fs.readFileSync(FILE,'utf8');
const TD=(SRC.match(/const TRACK_DETECT_JS = `([\s\S]*?)`;/)||[])[1]; let n=0,f=0; const ok=(c,m)=>{n++; if(!c){f++; console.log('FAIL',m);} };
global.setTimeout=(fn)=>fn(); const G={}; new Function('G',TD+'\nG.tdBand=tdBand;')(G);
const sr=22050, dur=30, bpm=126, beat=60/bpm;
function synth(kick, bass){ const x=new Float32Array(sr*dur); for(let i=0;i<x.length;i++){ const t=i/sr, bt=t%beat;
    let v=0; if(bass) v+=0.35*Math.sin(2*Math.PI*55*t)*(bass==='pump'?(0.75+0.25*Math.min(1,bt/0.12)):1);
    if(kick){ const a=bt<0.18?Math.exp(-bt/0.05):0; v+=0.6*a*Math.sin(2*Math.PI*(50+60*Math.exp(-bt/0.02))*bt); }
    x[i]=v; } return x; }
function run(x){ const out={hits:[],frames:[],ft:[]}; G.tdBand([x],sr,{lo:40,hi:120,sens:1.4},0,out,()=>{},()=>{}); return out.hits.map(h=>h.t/1000); }
const onBeat=h=>h.filter(t=>{ const ph=t%beat; return Math.min(ph,beat-ph)<=0.07; }).length;
const A=run(synth(true,'sustain')), B=run(synth(true,false)), C=run(synth(false,'sustain')), beats=Math.floor(dur/beat);
console.log('   kick on sustained bass: '+A.length+' hits, '+onBeat(A)+' on the beat ('+beats+' beats) | plain kick: '+B.length+' ('+onBeat(B)+') | bass only: '+C.length);
ok(onBeat(A)>=0.85*beats,'kicks riding a sustained sub-bass are detected ('+onBeat(A)+'/'+beats+')');
ok(A.length-onBeat(A)<=0.1*beats,'...without off-beat extras ('+(A.length-onBeat(A))+')');
ok(onBeat(B)>=0.9*beats,'plain kicks still detected');
ok(C.length<=3,'a sustained bass alone does not trigger ('+C.length+')');
console.log(`${n-f}/${n} passed`); process.exit(f?1:0);
