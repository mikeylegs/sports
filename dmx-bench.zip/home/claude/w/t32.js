const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2]; const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx'));
fs.copyFileSync(FILE,path.join(d,'artnet-controller.js')); fs.mkdirSync(path.join(d,'tracks'));
for(const f of ['a.wav','b.M4A','c.flac','d.aiff','e.ogg','f.opus','g.aac','h.mp3','x.exe','y.txt']) fs.writeFileSync(path.join(d,'tracks',f),Buffer.alloc(3000,1));
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'});
const B='http://127.0.0.1:8080'; let fails=0,n=0; const ok=(c,m)=>{n++; if(!c){fails++; console.log('FAIL',m);} };
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{ await sleep(800);
  const list=await (await fetch(B+'/lab/tracks')).text();
  for(const f of ['a.wav','b.M4A','c.flac','d.aiff','e.ogg','f.opus','g.aac','h.mp3']) ok(list.includes('>'+f+'<'),'listed '+f);
  ok(!list.includes('x.exe') && !list.includes('y.txt'),'non-audio not listed');
  const types={'a.wav':'audio/wav','b.M4A':'audio/mp4','c.flac':'audio/flac','d.aiff':'audio/aiff','e.ogg':'audio/ogg','g.aac':'audio/aac','h.mp3':'audio/mpeg'};
  for(const f in types){ const r=await fetch(B+'/tracks/'+f,{headers:{Range:'bytes=0-9'}}); ok(r.status===206 && r.headers.get('content-type')===types[f],f+' 206 '+types[f]+' (got '+r.status+' '+r.headers.get('content-type')+')'); }
  ok((await fetch(B+'/tracks/x.exe')).status===400,'.exe rejected');
  // analyze a wav end-to-end (decode stubbed), then a decode failure
  const {JSDOM}=require('jsdom'); const sr=44100, sig=new Float32Array(sr*40); for(let i=0;i<sig.length;i++) sig[i]=((i%22050)<2000)?0.8*Math.sin(i/100):0.001;
  async function run(f,fail){ const html=await (await fetch(B+'/lab/track?f='+encodeURIComponent(f))).text(); const w=new JSDOM(html,{runScripts:'outside-only'}).window; let rep=null;
    w.fetch=(u,o)=>fetch(B+u,o); w.__rep=u=>{rep=u;};
    w.AudioContext=function(){ this.decodeAudioData=(b,res,rej)=>{ fail?rej(new Error('EncodingError')):res({numberOfChannels:1,sampleRate:sr,duration:40,getChannelData:()=>sig}); }; this.close=()=>{}; };
    w.eval([...w.document.querySelectorAll('script')].map(x=>x.textContent).join('\n').replace('location.replace(','window.__rep('));
    for(let i=0;i<100 && !rep && !/Failed/.test(w.document.getElementById('st').textContent);i++) await sleep(100);
    return {rep, st:w.document.getElementById('st').textContent}; }
  const r=await run('a.wav'); ok(!!r.rep,'wav analyzed ('+r.st+')');
  if(r.rep){ const raw=await (await fetch(B+r.rep.replace('/logs/','/logs/raw/'))).text(), ev=raw.trim().split('\n').map(JSON.parse);
    ok(ev[1].k==='a' && ev[1].ext==='wav' && ev[1].mime==='audio/wav','audio event says wav');
    ok(/src="\/tracks\/a\.wav"/.test(await (await fetch(B+r.rep)).text()),'viewer plays the wav'); }
  { const sig2=new Float32Array(sr*40+sr*30); sig2.set(sig); const html=await (await fetch(B+'/lab/track?f=h.mp3')).text(); const w=new JSDOM(html,{runScripts:'outside-only'}).window; let rep=null;
    w.fetch=(u,o)=>fetch(B+u,o); w.__rep=u=>{rep=u;};
    w.AudioContext=function(){ this.decodeAudioData=(b,res)=>res({numberOfChannels:1,sampleRate:sr,duration:70,getChannelData:()=>sig2}); this.close=()=>{}; };
    w.eval([...w.document.querySelectorAll('script')].map(x=>x.textContent).join('\n').replace('location.replace(','window.__rep('));
    for(let i=0;i<100 && !rep;i++) await sleep(100);
    const ev=(await (await fetch(B+rep.replace('/logs/','/logs/raw/'))).text()).trim().split('\n').map(JSON.parse), stop=ev[ev.length-1], fr=ev.filter(e=>e.k==='f');
    ok(stop.k==='stop' && stop.t>39000 && stop.t<42000 && fr[fr.length-1].t<42000 && ev[0].trailingSilenceCut>=28,'30 s of trailing digital silence cut (stop '+stop.t+', cut '+ev[0].trailingSilenceCut+')'); }
  const f2=await run('d.aiff',true); ok(/can\u2019t decode \.aiff/.test(f2.st),'decode failure explained ('+f2.st+')');
  console.log(`${n-fails}/${n} passed`); p.kill(); process.exit(fails?1:0);
})().catch(e=>{console.log('ERR',e.stack); p.kill(); process.exit(2);});
