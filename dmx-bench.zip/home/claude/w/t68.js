// 27s: simple phrase clock; strobe + laser on drops only (switchable); laser Ch1 capped at 100
const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os'), dgram=require('dgram');
const FILE=process.argv[2], SRC=fs.readFileSync(FILE,'utf8'); let n=0,f=0; const ok=(c,m)=>{n++; if(!c){f++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
// ---- phrase clock (engine only) ----
const LJ=(SRC.match(/const LIVE_JS = `([\s\S]*?)`;/)||[])[1]; const G={}; new Function('G',LJ+'\nG.LE=LiveEngine;')(G);
function clock(bpmAt, cues){ let seed=3; const rnd=()=>{ seed=(seed*16807)%2147483647; return seed/2147483647; };
  const o=Object.create(G.LE.prototype); o.wash={idx:0,cueT:null,next:null}; o.r={bpm:0};
  o.lastBarAt=now=>{ const bar=4*60000/o.r.bpm; const k=Math.floor(now/bar); return {t:k*bar, t1:k*bar+bar, pb:1+Math.floor(rnd()*8)}; };   // phrase-bar guess: pure noise
  const out={ch:[], up:0}; let last=0, prevNext=null;
  for(let t=0;t<240000;t+=250){ o.r.bpm=bpmAt(t); (cues||[]).forEach(c=>{ if(t===c) o.cue(t); }); o.washTick(t);
    if(o.wash.idx!==last){ out.ch.push(t); last=o.wash.idx; prevNext=null; }
    if(prevNext!==null && o.wash.next>prevNext+60) out.up++; prevNext=o.wash.next; }
  return out; }
const PH=32*60000/126, A=clock(()=>126);
const gaps=A.ch.slice(1).map((t,i)=>t-A.ch[i]);
ok(A.up===0,'countdown only runs down, even with a noisy phrase guess ('+A.up+' jumps up)');
ok(gaps.length>=12 && gaps.every(g=>Math.abs(g-PH)<=260),'a colour change every 32 beats ('+gaps.length+' changes, '+(PH/1000).toFixed(2)+' s each)');
const DROP=Math.round(100000/(4*60000/126))*(4*60000/126); /* 28n: a real drop lands on a bar line of the kick grid */ const C=clock(()=>126,[Math.round(DROP/250)*250]), after=C.ch.filter(t=>t>DROP+100);
ok(after.length && Math.abs((after[0]-DROP)-PH)<=260,'a drop re-anchors the phrase clock to the drop');
const D=clock(t=>t<120000?126:127), dg=D.ch.slice(1).map((t,i)=>t-D.ch[i]).filter((g,i)=>D.ch[i]>130000);
ok(dg.length && dg.every(g=>Math.abs(g-32*60000/127)<=260),'tempo nudged 126 -> 127: phrases follow the new tempo');
// ---- controller ----
const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx')); fs.copyFileSync(FILE,path.join(d,'artnet-controller.js')); fs.writeFileSync(path.join(d,'settings.json'),JSON.stringify({targetIP:'127.0.0.2'}));
let last=null; const sock=dgram.createSocket({type:'udp4',reuseAddr:true}); sock.on('message',m=>{ if(m.length>=530 && m.toString('latin1',0,7)==='Art-Net' && m.readUInt16LE(14)===0) last=Buffer.from(m.subarray(18)); }); sock.bind(6454,'127.0.0.2');
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'}); const B='http://127.0.0.1:8080';
const post=(u,b)=>fetch(B+u,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)});
const snap=()=>post('/bridgestate',{levels:[0.3,0,0,0],active:[true,false,false,false],hits:[3,0,0,0],recording:true,build:'x',live:{beatMs:480,nextBeatIn:100,pb:1,groove:true,mode:'heavy',slvl:1,kickOn:true,hatsOn:false,washIdx:2,washNextIn:9000,bpm:125}});
const flashes=async T=>(await (await fetch(B+'/liveshow')).json()).log.filter(x=>x.kind==='flash' && x.t>=T);
(async()=>{ await sleep(900);
  let c=await (await fetch(B+'/liveshow')).json(); ok(c.strobe==='drops','default: strobe + laser on drops only');
  await post('/liveshow',{enabled:true,latencyMs:0,laserMode:'drops'});   // 28a: this suite checks the drops-only laser
  let T=Date.now(); for(let i=0;i<8;i++){ await post('/lv',{k:i%2?0.1:0.4}); await snap(); await post('/bridgehit',{strength:1,band:1}); await sleep(120); }
  ok((await flashes(T)).length===0,'drops mode: a heavy groove with kicks fires no strobe');
  T=Date.now(); await post('/livecue',{washIdx:3}); await sleep(300);
  const F=await flashes(T); ok(F.some(x=>x.why==='drop') && F.length>=3,'the drop itself: burst ('+F.length+' flashes)');
  ok(last && last[0]===60,'the drop: laser on (Ch1 = '+(last?last[0]:'-')+')');
  await sleep(2100); ok(last && last[0]===0,'a bar later: laser off (Ch1 = '+(last?last[0]:'-')+')');
  await post('/liveshow',{strobe:'full'}); T=Date.now(); for(let i=0;i<8;i++){ await post('/lv',{k:i%2?0.1:0.4}); await snap(); await sleep(120); }
  ok((await flashes(T)).length>=1,'FULL mode: beat flashes are back');
  await post('/liveshow',{enabled:false,strobe:'drops'});
  await post('/dmx',{bulk:[[0,1,200]]}); await sleep(700); ok(last && last[0]===100,'laser Ch1 never above 100 (asked 200, sent '+(last?last[0]:'-')+')');
  const sh=await (await fetch(B+'/lab/show')).text(); ok(/id="lvb"/.test(sh),'Show tab: strobe level selector (27w)');
  console.log(`${n-f}/${n} passed`); p.kill(); sock.close(); process.exit(f?1:0); })().catch(e=>{ console.log('ERR',e.stack); p.kill(); process.exit(2); });
