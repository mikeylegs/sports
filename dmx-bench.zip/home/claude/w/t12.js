const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2], OLD=process.argv[3], SRC=fs.readFileSync(FILE,'utf8'); const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx'));
fs.copyFileSync(FILE,path.join(d,'artnet-controller.js')); fs.mkdirSync(path.join(d,'logs'));
let fails=0,n=0; const ok=(c,m)=>{n++; if(!c){fails++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const TDJ=(SRC.match(/const TRACK_DETECT_JS = `([\s\S]*?)`;/)||[])[1]; const g={}; new Function('G',TDJ+';G.a=tdAnalyze;')(g);
const sr=44100, BL=60/128, bars=112, N=Math.ceil(bars*4*BL*sr)+sr, a=new Float32Array(N); let seed=3; const rnd=()=>((seed=(seed*16807)%2147483647)/2147483647)*2-1;
const kickOn=bar=>(bar<32)||(bar>=48&&bar<80)||bar===92||bar>=96;
for(let i=0;i<N;i++) a[i]=rnd()*0.004;
for(let b=0;b<bars*4;b++){ const bar=Math.floor(b/4), s0=Math.floor(b*BL*sr);
  if(kickOn(bar)) for(let j=0;j<sr*0.15&&s0+j<N;j++) a[s0+j]+=0.8*Math.sin(2*Math.PI*60*j/sr)*Math.exp(-j/sr/0.05);
  if(b%2===1) for(let j=0;j<sr*0.04&&s0+j<N;j++) a[s0+j]+=0.3*Math.sin(2*Math.PI*2000*j/sr)*Math.exp(-j/sr/0.015);
  const h=Math.floor((b+0.5)*BL*sr); for(let j=0;j<sr*0.03&&h+j<N;j++) a[h+j]+=0.15*Math.sin(2*Math.PI*8000*j/sr+rnd())*Math.exp(-j/sr/0.008);
  if((bar>=40&&bar<48)||(bar>=88&&bar<92)) for(let j=0;j<BL*sr&&s0+j<N;j++) a[s0+j]+=rnd()*0.05*((bar%8)+1)/8; }
const ms=bar=>Math.round(bar*4*BL*1000);
(async()=>{
  const out=await new Promise(r=>g.a([a],sr,[{lo:40,hi:120,sens:1.5},{lo:1000,hi:4000,sens:1.05},{lo:6000,hi:12000,sens:1.3},{lo:12000,hi:16000,sens:1.3}],()=>{},r));
  const ev=[{k:'start',src:'track',track:'Synth A.mp3',t:0}].concat(out.ft.map((t,i)=>({k:'f',e:out.frames.map(f=>f[i]),t})),out.hits).sort((x,y)=>x.t-y.t);
  const marks=[{k:'m',label:'drop',t:ms(48),post:true},{k:'m',label:'breakdown',t:ms(80),post:true},{k:'m',label:'fake',t:ms(92),post:true}];
  const w=(id,e)=>fs.writeFileSync(path.join(d,'logs',id+'.ndjson'),e.map(x=>JSON.stringify(x)).join('\n')+'\n');
  w('track-00000001-000001',ev.concat(marks)); w('bridge-20260926-090000',[{k:'start',src:'bridge',wall:1790000000000,t:0}].concat(ev.slice(1))); w('bridge-20260926-095000',[{k:'start',src:'bridge',t:0},{k:'f',e:[0.1,0,0,0],t:100}]); w('track-00000002-000002',[Object.assign({},ev[0],{track:'Synth B.mp3'})].concat(ev.slice(1)));
  const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'}); await sleep(900); const B='http://127.0.0.1:8080';
  const {JSDOM}=require('jsdom');
  const canvas=v=>{ v.HTMLCanvasElement.prototype.getContext=()=>new Proxy({},{get:(t,k)=>k==='measureText'?()=>({width:0}):(k in t?t[k]:()=>{}),set:(t,k,x)=>{t[k]=x;return true;}}); };
  const html=await (await fetch(B+'/logs/track-00000001-000001.ndjson')).text();
  // 0) the phrase engine moved verbatim: the served viewer still carries the exact analyzeSections source
  if(OLD){ const o=fs.readFileSync(OLD,'utf8'); const i=o.indexOf('function median(a){ if(!a.length) return 0;'), j=o.indexOf('\n}\n',o.indexOf('function analyzeSections(ev){',i))+3;
    ok(html.includes(Function('return `'+o.slice(i,j)+'`')()),'viewer serves the identical phrase engine (moved verbatim)'); }
  const v=new JSDOM(html,{runScripts:'outside-only'}).window; canvas(v); v.fetch=(u,o)=>fetch(B+u,o);
  v.eval([...v.document.querySelectorAll('script')].map(x=>x.textContent).join('\n'));
  for(let i=0;i<50 && !v.eval('TL');i++) await sleep(100);
  console.log('   grid:',v.eval("JSON.stringify({bpm:TL.sec.bpm, n:TL.sec.bars.length, b0:TL.sec.bars.slice(0,3).map(function(b){return [Math.round(b.t),b.pb];}), b40:TL.sec.bars.slice(38,42).map(function(b){return [Math.round(b.t),b.pb];}), segs:TL.sec.segs})"), 'ideal bar40', ms(40), 'bar48', ms(48));
  v.eval(`window.__dbg=(function(){ var K=TL.ev.filter(function(e){return e.k==='h'&&laneOf(e)===0;}); var kb=K.filter(function(e){return e.t>62000&&e.t<88000;}).length, kg=K.filter(function(e){return e.t>30000&&e.t<58000;}).length; var F=TL.ev.filter(function(e){return e.k==='f';}); return JSON.stringify({K:K.length, kickInBreak:kb, kickInGroove:kg, f0:F[300]&&F[300].e, fBreak:F[700]&&F[700].e}); })()`); console.log('   dbg', v.__dbg);
  v.eval(`window.__nb=(function(){ var F=TL.ev.filter(function(e){return e.k==='f';}); var out=[]; for(var t=56000;t<62500;t+=468.75){ var s=F.filter(function(f){return f.t>=t+54&&f.t<t+54+468.75;}); out.push(Math.round(t/468.75)+':'+(s.reduce(function(a,f){return a+f.e[0];},0)/s.length).toFixed(3)); } return out.join(' '); })()`); console.log('   kickLvlByIdealBeat', v.__nb);
  v.eval("eval(phraseTest.toString().replace('return {bpm','window.__B=beats; window.__N=nov; return {bpm')); phraseTest(TL.ev,TL.sec);");
  v.eval(`window.__bb=__B.map(function(b,i){return {i:i,t:b.t,n0:b.n[0]};}).filter(function(b){return b.t>57000&&b.t<62000;}).map(function(b){ var nv=__N.filter(function(x){return x.i===b.i;})[0]; return Math.round(b.t)+':'+b.n0.toFixed(2)+(nv?'/'+nv.d.toFixed(2):''); }).join(' ')`); console.log('   beats', v.__bb);
  const btn=v.document.getElementById('p32btn'); ok(!!btn,'+32 test button');
  if(!btn){ console.log(`${n-fails}/${n} passed`); p.kill(); process.exit(1); }
  const z=v.eval('phraseTest(TL.ev,TL.sec)');
  const at=bar=>z.trans.find(t=>Math.abs(t.t-ms(bar))<=2*BL*1000+1);
  console.log('   info: verdict',z.verdict,'T',z.T,'onP',z.onP,'onH',z.onH,'land',z.legit+'/'+z.landings,'best',z.best,'trans@bars',z.trans.map(t=>+(t.t/(4*BL*1000)).toFixed(1)+':'+t.pos).join(' '));
  ok([32,48,80,96].every(b=>at(b)),'finds the kick out/in transitions at bars 32, 48, 80, 96');
  { const ps=[32,48,80,96].map(b=>at(b)&&at(b).pos); ok(ps.every(x=>x!=null && Math.min(Math.abs(x-ps[0]),32-Math.abs(x-ps[0]))<=1),'…all four at the same phrase position ('+ps.join(',')+'), i.e. 32-beat periodic'); }
  ok(z.S>=4 && z.bestSN/z.S>=0.8,'kick in/out concentrate on one phrase position ('+z.bestSN+'/'+z.S+' at beat '+(z.bestS+1)+'): "'+z.verdict+'"');
  ok(z.marks===3,'marks counted');
  // vacuity: rotate the phrase count by 2 bars -> transitions no longer on phrase starts, offset reported
  const zr=v.eval('(function(){ var s=JSON.parse(JSON.stringify(TL.sec)); s.bars.forEach(function(b){ b.pb=((b.pb-1+2)%8)+1; }); return phraseTest(TL.ev,s); })()');
  ok(zr.bestS===(z.bestS+8)%32 && zr.bestSN===z.bestSN && zr.onPS===0,'vacuity: phrase count rotated 2 bars moves the peak by 8 beats ('+z.bestS+' -> '+zr.bestS+', "'+zr.verdict+'")');
  btn.click(); const o=v.document.getElementById('p32out').innerHTML; ok(/\+32 test:<\/b>/.test(o) && /Landings/.test(o),'viewer shows the result');
  const lk=v.document.querySelector('#p32out a[data-t]'); if(lk){ lk.click(); ok(v.eval('CUR')===+lk.dataset.t,'off-phrase link jumps the playhead'); } else ok(true,'(no off-phrase transitions to jump to)');
  // batch page
  const bp=await (await fetch(B+'/lab/phrasetest')).text(); const bw=new JSDOM(bp,{runScripts:'outside-only'}).window; bw.fetch=(u,o)=>fetch(B+u,o);
  bw.eval([...bw.document.querySelectorAll('script')].map(x=>x.textContent).join('\n'));
  for(let i=0;i<150 && !/All 3 tested/.test(bw.document.getElementById('sum').textContent);i++) await sleep(100);
  const s=bw.document.getElementById('sum').textContent; ok(/All 3 tested \(1 skipped: no beat grid\)/.test(s),'batch runs tracks + recordings, skips the gridless one ('+s.slice(0,70)+')');
  const L=bw.document.getElementById('list').textContent; ok(bw.document.querySelectorAll('.card:not(.sum)').length===4 && /Synth A\.mp3/.test(L) && /bridge-20260926-090000/.test(L),'one card each, tracks named, recordings by file');
  ok(L.indexOf('Synth A')<L.indexOf('Synth B') && L.indexOf('Synth B')<L.indexOf('bridge-20260926-095000') && L.indexOf('bridge-20260926-095000')<L.indexOf('bridge-20260926-090000'),'order: tracks A-Z, then recordings newest first');
  ok(s.includes('('+(3*z.onPS)+'/'+(3*z.S)+')') && s.includes('('+(3*z.onP)+'/'+(3*z.T)+')'),'totals add up across all three');
  ok(/Tracks \(2\): kick in\/out/.test(s) && /Recordings \(1\): kick in\/out/.test(s),'subtotals per source');
  ok(/phrasetest/.test(await (await fetch(B+'/lab/recordings')).text()),'Recordings tab links to it');
  ok(/phrasetest/.test(await (await fetch(B+'/lab/tracks')).text()),'Tracks tab links to it');
  console.log(`${n-fails}/${n} passed`); p.kill(); process.exit(fails?1:0);
})().catch(e=>{console.log('ERR',e.stack); process.exit(2);});
