// 27q: served link_bridge.py (follow-only) + the bridge page's "you closed me" hold
const {spawn,execSync}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2]; const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx')); fs.copyFileSync(FILE,path.join(d,'artnet-controller.js'));
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'}); const B='http://127.0.0.1:8080'; let n=0,f=0; const ok=(c,m)=>{n++; if(!c){f++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const post=(u,b)=>fetch(B+u,{method:'POST',headers:{'Content-Type':'application/json'},body:b===undefined?'':JSON.stringify(b)});
const ctl=async()=>(await fetch(B+'/bridgectl')).json();
(async()=>{ await sleep(800);
  const r=await fetch(B+'/pi/link_bridge.py'); const py=await r.text(); ok(r.status===200 && /http:\/\/127\.0\.0\.1:8080\/linksync/.test(py),'controller serves link_bridge.py with its own address');
  fs.writeFileSync(path.join(d,'lb.py'),py); let out=''; try{ out=execSync('python3 t65.py '+path.join(d,'lb.py')+' 2>&1').toString(); }catch(e){ out=String(e.stdout||''); }
  ok(/6\/6 passed/.test(out),'served file = follow-only version (t65: '+(out.trim().split('\n').pop())+')');
  let c=await ctl(); ok(c.reopen===true,'switch on, nothing closed: supervisor may reopen');
  await post('/bridgectl/closed'); c=await ctl(); ok(c.reopen===false && c.want===true && c.hold===15,'you close the page: no reopen for 15 min (switch still on)');
  await post('/bridgectl/opened'); c=await ctl(); ok(c.reopen===true && c.hold===0,'page opened again (icon): hold cleared');
  await post('/bridgectl/closed'); await post('/bridgectl',{want:false}); await post('/bridgectl',{want:true}); c=await ctl(); ok(c.reopen===true,'flipping the switch ends a hold');
  const page=await (await fetch(B+'/bridge')).text(); ok(/sendBeacon\('\/bridgectl\/closed'/.test(page) && /'\/bridgectl\/opened'/.test(page),'bridge page reports open / close');
  console.log(`${n-f}/${n} passed`); p.kill(); process.exit(f?1:0); })().catch(e=>{ console.log('ERR',e.stack); p.kill(); process.exit(2); });
