// 28i: power lives in the Command Center header (bulb = every plug, hold 1 s; count opens the outlet list)
const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2]; const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx')); fs.copyFileSync(FILE,path.join(d,'artnet-controller.js'));
fs.writeFileSync(path.join(d,'settings.json'),JSON.stringify({targetIP:'127.0.0.2',kasa:[{ip:'127.0.0.9',alias:'Laser Center'},{ip:'127.0.0.8',alias:'Smoke'}]}));
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'}); const B='http://127.0.0.1:8080'; let n=0,f=0; const ok=(c,m)=>{n++; if(!c){f++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{ await sleep(900); const {JSDOM}=require('jsdom'); const html=await (await fetch(B+'/cc')).text();
  const v=new JSDOM(html,{runScripts:'outside-only',url:B+'/cc'}).window; v.fetch=(u,o)=>fetch(B+u,o); v.eval(v.document.querySelector('script:not([data-nl])').textContent);
  const $=id=>v.document.getElementById(id), click=el=>el.dispatchEvent(new v.Event('click',{bubbles:true})); await sleep(1500);
  ok(!!v.document.querySelector('header #kAll') && !!v.document.querySelector('header #kCnt'),'bulb + count sit in the header');
  ok(![...v.document.querySelectorAll('#pLive .lab span')].some(s=>s.textContent==='Power'),'no Power section on the Live page any more');
  ok(/\d+\/2|–/.test($('kCnt').textContent),'count shows plugs on / total ('+$('kCnt').textContent+')');
  ok(!$('kDrop').classList.contains('on'),'outlet list closed by default');
  click($('kCnt')); ok($('kDrop').classList.contains('on') && /Laser|LASER/.test($('pw').textContent),'tap the count: outlet list drops down');
  click($('sNode')); ok(!$('kDrop').classList.contains('on'),'tap elsewhere: it closes');
  $('kAll').dispatchEvent(new v.Event('pointerdown')); await sleep(200); $('kAll').dispatchEvent(new v.Event('pointerup')); await sleep(50);
  ok(/Hold 1 s/.test($('toast').textContent),'a quick tap on the bulb does nothing but explain (it includes the DMX chain)');
  v.close(); console.log(`${n-f}/${n} passed`); p.kill(); process.exit(f?1:0); })().catch(e=>{ console.log('ERR',e.stack); p.kill(); process.exit(2); });
