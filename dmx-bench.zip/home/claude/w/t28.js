// live engine, standalone: feed recordings in (simulated) real time, collect its decisions
const fs=require('fs'); const SRC=fs.readFileSync(process.argv[2]||'artnet-controller.js','utf8');
const get=n=>(SRC.match(new RegExp('const '+n+' = `([\\s\\S]*?)`;'))||[])[1];
const LANE=(SRC.match(/const LANEOF_JS = `([\s\S]*?)`;/)||[])[1];
const G={}; new Function('G',Function('return `'+LANE+'`')()+'\n'+get('SECTIONS_JS')+'\n'+get('LIVE_JS')+'\nG.LE=LiveEngine; G.AS=analyzeSections;')(G);
function run(ev){ const L=new G.LE(), out=[], E=ev.filter(e=>typeof e.t==='number').sort((a,b)=>a.t-b.t), end=E[E.length-1].t; let i=0;
  for(let now=0; now<=end; now+=100){ while(i<E.length && E[i].t<=now) L.push(E[i++]); L.step(now).forEach(o=>{ o.t=now; out.push(o); }); }
  return out; }
module.exports={run,G};
if(require.main===module){
  for(const f of process.argv.slice(3)){ const ev=fs.readFileSync(f,'utf8').trim().split('\n').map(JSON.parse), t0=Date.now(), x=run(ev);
    const k=s=>x.filter(o=>o.ev===s), ms=k('bar').map(o=>o.ms).filter(v=>v!=null).sort((a,b)=>a-b);
    console.log(require('path').basename(f),'->',x.length,'decisions in',((Date.now()-t0)/1000).toFixed(1)+'s | bars',k('bar').length,'| drops',JSON.stringify(k('drop').map(o=>[(o.at/1000).toFixed(1),(o.t/1000).toFixed(1)])),
      '| pred',k('pred').length,'black',k('black').length,'hit',JSON.stringify(k('hit').map(o=>(o.at/1000).toFixed(1))),'miss',JSON.stringify(k('miss').map(o=>(o.at/1000).toFixed(1))),'cancel',k('cancel').length,'| ms med',ms[ms.length>>1],'max',ms[ms.length-1]);
  }
}
