// 28r: drop prediction v2 -- the next drop = last real drop + whole 8-bar phrases (master tempo), armed by colour break or gap
const fs=require('fs'); const SRC=fs.readFileSync(process.argv[2],'utf8'); let n=0,f=0; const ok=(c,m)=>{n++; if(!c){f++; console.log('FAIL',m);} };
const J=k=>(SRC.match(new RegExp('const '+k+' = (?:String\\.raw)?`([\\s\\S]*?)`;'))||[])[1];
const G={}; new Function('G',J('TEMPO_JS')+'\n'+J('SECTIONS_JS')+'\n'+J('LIVE_JS')+'\nG.LE=LiveEngine;')(G);
const P=60000/126, E=new G.LE(); E.r={bpm:126, bars:[{t:0,t1:4*P,pb:1,st:'G'}], src:'kick'}; E.lastBarAt=now=>{ const k=Math.floor(now/(4*P)); return {t:(k-1)*4*P, t1:k*4*P, pb:((k-1)%8)+1, st:'G'}; };
E.push({k:'tp',bpm:126,bt:0,c:2,t:60000}); E.wash={idx:3,cueT:null,next:null};
E.cue(61000,'rd'); ok(E.dropA===61000,'first drop anchors the drop grid'); E.cue(66000,'rd'); ok(E.dropA===61000,'28s: a lone later drop (one detector, off the line) does not re-aim it');
const at=t=>{ E.push({k:'tp',bpm:126,bt:0,c:2,t:t}); const s=E.snap(t); return s?s.dropIn:undefined; };
ok(at(75500)===null,'not armed without a colour break / gap');
E.push({k:'rb',v:1,t:70000}); ok(at(75400)===null,'28s: a breakdown alone no longer arms it (lines inside long breakdowns fired)'); E.look='build'; const d1=at(75500); ok(d1!=null && Math.abs(75500+d1-(61000+32*P))<=2,'breakdown + build: the next drop line = drop + 32 beats ('+(75500+d1)+')'); E.look='groove';
E.push({k:'rb',v:0,t:76000}); E.push({k:'rg',v:1,t:76100}); ok(at(76100)!=null,'the pre-drop gap arms it too');
E.manualNext(76200,5); ok(E.dropA===61000,'NEXT COLOUR does not move the drop grid');
E.push({k:'rg',v:0,t:76300}); E.r.early=true; E.push({k:'rb',v:1,t:76400}); ok(at(76400)===null,'never off the provisional grid');
console.log(`${n-f}/${n} passed`); process.exit(f?1:0);
