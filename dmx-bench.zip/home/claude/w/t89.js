// 28q: master tempo -- tracker accuracy, analyzer 'tp' events, engine beats / provisional grid / NEXT COLOUR snap, Pi page wiring
const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2], SRC=fs.readFileSync(FILE,'utf8'); let n=0,f=0; const ok=(c,m)=>{n++; if(!c){f++; console.log('FAIL',m);} };
const TJ=(SRC.match(/const TEMPO_JS = String\.raw`([\s\S]*?)`;/)||[])[1]; ok(!!TJ,'TEMPO_JS present'); if(!TJ){ console.log(`${n-f}/${n} passed`); process.exit(1); }
const LJ=(SRC.match(/const LIVE_JS = `([\s\S]*?)`;/)||[])[1], SJ=(SRC.match(/const SECTIONS_JS = `([\s\S]*?)`;/)||[])[1]; const G={}; new Function('G',TJ+'\n'+SJ+'\n'+LJ+'\nG.TT=TempoTracker; G.O=TEMPO_OPT; G.LE=LiveEngine;')(G);
// 1) tracker on Dolce's real levels
const L=JSON.parse(fs.readFileSync('/tmp/red/dolce.lv.json')); const tt=new G.TT(G.O); let lockT=null;
for(let k=0;k<L.ticks[0].length && k<60*60;k++){ tt.feed([0,1,2,3,4,5].map(i=>L.ticks[i][k]||0)); if(lockT==null && tt.bpm && Math.abs(tt.bpm-130)/130<0.001) lockT=k/60; }
ok(lockT!==null && lockT<=8,'tracker: Dolce 130.00 BPM within 0.1% after '+(lockT==null?'-':lockT.toFixed(1))+' s');
// 2) engine: tp events drive beats; provisional grid before the section analysis
const E=new G.LE(); for(let t=0;t<9000;t+=100){ E.push({k:'f',e:[0.3,0.1,0.05,0],t:t}); if(t%500===0) E.push({k:'tp',bpm:130,bt:1000,c:2,t:t}); }
for(let t=0;t<9000;t+=460) E.push({k:'h',b:1,s:1,r:2,t:t});
E.lastA=-1e9; E.step(9000); const s=E.snap(9000);
ok(s && Math.abs(s.beatMs-60000/130)<0.2 && s.early===true && s.src==='tempo','provisional grid from the master tempo before the ~30 s analysis ('+(s&&s.beatMs)+' ms, '+(s&&s.src)+')');
const P=60000/130, nb=9000+s.nextBeatIn; ok(Math.abs(((nb-1000)/P)-Math.round((nb-1000)/P))<0.01,'next beat lands on the master tempo\'s beat grid');
// 3) NEXT COLOUR snaps the phrase start to the nearest downbeat
E.manualNext(9000+0.4*P, 7); ok(Math.abs(((E.wash.cueT-1000)/(4*P))-Math.round((E.wash.cueT-1000)/(4*P)))<0.01,'NEXT COLOUR press snaps to the nearest downbeat');
// 4) analyzer writes 'tp' events; Pi page runs the tracker and records them
const re=fs.readFileSync('/tmp/dolce-28q.ndjson','utf8').split('\n').filter(l=>l.indexOf('"k":"tp"')>=0).map(JSON.parse);
ok(re.length>100 && Math.abs(re[re.length-1].bpm-130)<0.15,'Tracks analyzer: '+re.length+' tempo events, ends at '+(re.length?re[re.length-1].bpm:'-'));
ok(/new TempoTracker\(TEMPO_OPT\)/.test(SRC) && /recEvent\(\{k:'tp'/.test(SRC),'Pi page runs the tracker and records it');
console.log(`${n-f}/${n} passed`); process.exit(f?1:0);
