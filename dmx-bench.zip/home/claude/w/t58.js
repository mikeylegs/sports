const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2], TR=['track-15337193-247718','track-39307571-582210','track-37199921-932496','track-52285985-558042','track-65570060-568769','track-96314428-446959'];
const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx')); fs.copyFileSync(FILE,path.join(d,'artnet-controller.js')); fs.mkdirSync(path.join(d,'logs'));
TR.forEach(t=>fs.copyFileSync('/mnt/user-data/uploads/'+t+'.ndjson',path.join(d,'logs',t+'.ndjson')));
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'}); const B='http://127.0.0.1:8080'; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{ await sleep(800); const {JSDOM}=require('jsdom'); const T={fl:0,onK:0,stray:0,kicks:0,cov:0,roll:0};
  await fetch(B+'/liveshow',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({strobe:'full'})});   // 27s: this suite tests the FULL strobe behaviour
  for(const t of TR){ const v=new JSDOM(await (await fetch(B+'/logs/'+t+'.ndjson')).text(),{runScripts:'outside-only',url:B+'/logs/x'}).window;
    v.HTMLCanvasElement.prototype.getContext=()=>new Proxy({},{get:(t,k)=>k==='measureText'?()=>({width:0}):(k in t?t[k]:()=>{}),set:(t,k,x)=>{t[k]=x;return true;}});
    v.fetch=(u,o)=>fetch(B+u,o); v.requestAnimationFrame=()=>0; v.eval([...v.document.querySelectorAll('script')].map(x=>x.textContent).join('\n'));
    for(let i=0;i<50 && !v.eval('TL');i++) await sleep(100); v.eval('ensureLivePlan()'); for(let i=0;i<900 && !v.eval('!!TL.rigLive');i++) await sleep(100);
    const P=JSON.parse(v.eval('JSON.stringify(TL.rigLive)')), H=JSON.parse(v.eval("JSON.stringify(TL.ev.filter(function(e){return e.k==='h';}).map(function(e){return [e.t,e.b];}))"));
    let lk=-1e9; const K0=H.filter(h=>h[1]===1).map(h=>h[0]).sort((a,b)=>a-b).filter(x=>{ if(x-lk<150) return false; lk=x; return true; }), C=H.filter(h=>h[1]===2).map(h=>h[0]);
    const SB=JSON.parse(v.eval('JSON.stringify(TL.sec.bars)')), G=[]; SB.forEach(b=>{ const L=(b.t1-b.t)/4; for(let q=0;q<4;q++) G.push(b.t+q*L); });
    const K=K0.filter(k=>G.some(g=>Math.abs(g-k)<=70));   // on-beat kicks only (a bass note between beats is not a kick)
    const boom=P.boom||[], near=(arr,x,w)=>{ let lo=0,hi=arr.length; while(lo<hi){ const m=(lo+hi)>>1; if(arr[m]<x-w) lo=m+1; else hi=m; } return lo<arr.length && arr[lo]<=x+w; };
    const fl=P.strobe.filter(x=>!boom.some(b=>x>=b-10 && x<=b+300));
    const onK=fl.filter(x=>near(K,x,70)).length, roll=fl.filter(x=>!near(K,x,70) && near(C,x,70)).length, stray=fl.length-onK-roll;
    const cov=K.filter(k=>near(P.strobe,k,70)).length;
    T.fl+=fl.length; T.onK+=onK; T.roll+=roll; T.stray+=stray; T.kicks+=K.length; T.cov+=cov;
    console.log('  '+t.slice(6,14)+': flashes '+fl.length+' · on a kick '+onK+' · on a snare roll '+roll+' · stray '+stray+' · kicks with a flash '+cov+'/'+K.length);
    v.close(); }
  console.log('  ALL: on a kick '+T.onK+'/'+T.fl+' ('+Math.round(T.onK/T.fl*100)+'%) · stray '+T.stray+' · kicks covered '+T.cov+'/'+T.kicks+' ('+Math.round(T.cov/T.kicks*100)+'%)');
  let n=0,f=0; const ok=(c,m)=>{n++; if(!c){f++; console.log('FAIL',m);} };
  ok((T.onK+T.roll)/T.fl>=0.9,'the strobe mimics the kick (or a build roll): '+Math.round((T.onK+T.roll)/T.fl*100)+'% of flashes'); ok(T.cov/T.kicks>=0.8,'>= 80% of kicks get a flash'); ok(T.stray/T.fl<=0.07,'stray flashes (no kick, no roll) '+Math.round(T.stray/T.fl*100)+'%');
  console.log(`${n-f}/${n} passed`); p.kill(); process.exit(f?1:0); })();
