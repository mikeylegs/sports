// 28f: Command Center icon + status chips open a sheet with switches (Pi bridge, Link, show, manual BPM)
const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2]; const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx')); fs.copyFileSync(FILE,path.join(d,'artnet-controller.js'));
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'}); const B='http://127.0.0.1:8080'; let n=0,f=0; const ok=(c,m)=>{n++; if(!c){f++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{ await sleep(900); const {JSDOM}=require('jsdom');
  const ic=await fetch(B+'/icon-cc.png'); const buf=Buffer.from(await ic.arrayBuffer()); ok(ic.status===200 && buf.slice(1,4).toString()==='PNG' && buf.readUInt32BE(16)===180,'/icon-cc.png: 180 px PNG');
  const html=await (await fetch(B+'/cc')).text(); ok(/rel="apple-touch-icon" href="\/icon-cc.png"/.test(html) && /apple-mobile-web-app-title" content="Command"/.test(html),'Command Center uses its own home-screen icon + name');
  const v=new JSDOM(html,{runScripts:'outside-only',url:B+'/cc'}).window; v.fetch=(u,o)=>fetch(B+u,o); v.eval(v.document.querySelector('script:not([data-nl])').textContent);
  const $=id=>v.document.getElementById(id), click=el=>el.dispatchEvent(new v.Event('click',{bubbles:true})); await sleep(900);
  click($('sPi')); await sleep(100); ok($('sheet').classList.contains('on') && $('shc').querySelector('[data-tg="bridge"]').textContent.trim()==='PI BRIDGE','tap PI: its sheet opens (switch labelled PI BRIDGE)');
  click($('shc').querySelector('[data-tg="bridge"]')); await sleep(500); ok((await (await fetch(B+'/bridgectl')).json()).want===false,'switch the Pi bridge page off from the sheet');
  await sleep(400); ok(!$('shc').querySelector('[data-tg="bridge"]').classList.contains('on'),'the switch shows OFF after the next poll');
  click($('shc').querySelector('[data-tg="bridge"]')); await sleep(400); ok((await (await fetch(B+'/bridgectl')).json()).want===true,'and back on');
  click($('shbg')); await sleep(50); ok(!$('sheet').classList.contains('on'),'tap outside closes it');
  click($('sLink')); await sleep(100); click($('shc').querySelector('[data-tg="link"]')); await sleep(500); ok((await (await fetch(B+'/linkctl')).json()).want===false,'LINK sheet: Pi Link reader off');
  $('shMb').value='126'; click($('shMbSet')); await sleep(400); ok((await (await fetch(B+'/liveshow')).json()).manualBpm===126,'LINK sheet: manual BPM');
  click($('shbg')); click($('sShow')); await sleep(100); click($('shc').querySelector('[data-tg="show"]')); await sleep(400); ok((await (await fetch(B+'/liveshow')).json()).enabled===true,'SHOW sheet: show on');
  for(const id of ['sNode','sAud','sGrid']){ click($('shbg')); click($(id)); await sleep(60); ok($('sheet').classList.contains('on') && $('shc').querySelectorAll('.ln').length>=2,id+' sheet shows details'); }
  v.close(); await fetch(B+'/liveshow',{method:'POST',headers:{'Content-Type':'application/json'},body:'{"enabled":false}'});
  console.log(`${n-f}/${n} passed`); p.kill(); process.exit(f?1:0); })().catch(e=>{ console.log('ERR',e.stack); p.kill(); process.exit(2); });
