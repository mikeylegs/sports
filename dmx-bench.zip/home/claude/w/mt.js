// master tempo in stage view: snapshot tempo + beat phase vs true kicks, phrase-change drift
const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2], SUF=process.argv[3]; const TR=[['dare',134.03],['meduza',126],['deceiver',126.98],['vision',130.05],['espresso',126],['dtmf',130],['dolce',130]];
const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx')); fs.copyFileSync(FILE,path.join(d,'artnet-controller.js')); fs.mkdirSync(path.join(d,'logs'));
TR.forEach((t,i)=>fs.copyFileSync('/tmp/'+t[0]+SUF+'.ndjson',path.join(d,'logs','track-9000000'+i+'-000001.ndjson')));
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'}); const B='http://127.0.0.1:8080'; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{ await sleep(800); const {JSDOM}=require('jsdom');
 for(let i=0;i<TR.length;i++){ const [n,bpm]=TR[i]; const truth=t=>n==='dare'?(t<55000?132:(t>85000?134:null)):bpm;
  const v=new JSDOM(await (await fetch(B+'/logs/track-9000000'+i+'-000001.ndjson')).text(),{runScripts:'outside-only',url:B+'/logs/x'}).window;
  v.HTMLCanvasElement.prototype.getContext=()=>new Proxy({},{get:(t,k)=>k==='measureText'?()=>({width:0}):(k in t?t[k]:()=>{}),set:(t,k,x)=>{t[k]=x;return true;}});
  v.fetch=(u,o)=>fetch(B+u,o); v.requestAnimationFrame=()=>0; v.eval([...v.document.querySelectorAll('script')].map(x=>x.textContent).join('\n'));
  for(let j=0;j<50 && !v.eval('TL');j++) await sleep(100); await sleep(150); v.eval('ensureLivePlan()'); for(let j=0;j<900 && !v.eval('!!TL.rigLive');j++) await sleep(100);
  const WN=JSON.parse(v.eval('JSON.stringify(window.WN||[])')), cols=JSON.parse(v.eval('JSON.stringify(TL.rigLive.cols)')); const K=JSON.parse(fs.readFileSync('/tmp/'+n+'Kick.json')).map(x=>x*1000);
  const ws=WN.filter(w=>truth(w[0])!=null), wb=x=>Math.round(100*ws.filter(w=>Math.abs(60000/w[1]-truth(w[0]))/truth(w[0])<=x).length/Math.max(1,ws.length));
  const pe=[]; ws.forEach(w=>{ const tb=w[0]+w[2], P=w[1]; const kk=K.reduce((b,k)=>Math.abs(k-tb)<Math.abs(b-tb)?k:b,1e12); if(Math.abs(kk-tb)<P/3) pe.push(process.env.SIGNED?tb-kk:Math.abs(kk-tb)); }); pe.sort((a,b)=>a-b);
  const ph=cols.filter(c=>c[2]>0); const dr=[]; for(let q=1;q<ph.length;q++){ const T=truth(ph[q][0]); if(!T) continue; const want=32*60000/T, g=ph[q][0]-ph[q-1][0]; if(g>0.75*want && g<1.25*want) dr.push(Math.abs(g-want)); } dr.sort((a,b)=>a-b);
  console.log(n.padEnd(9)+' first grid '+(WN.length?(WN[0][0]/1000).toFixed(1)+'s':'-')+' | tempo within 0.1% '+wb(0.001)+'%  0.5% '+wb(0.005)+'% | next beat vs real kick: median '+(pe.length?pe[pe.length>>1].toFixed(0):'-')+' ms | phrase intervals vs 32 true beats: median '+(dr.length?dr[dr.length>>1].toFixed(0):'-')+' ms, worst '+(dr.length?dr[dr.length-1].toFixed(0):'-')+' ms ('+dr.length+')');
  v.close(); }
 p.kill(); process.exit(0); })();
