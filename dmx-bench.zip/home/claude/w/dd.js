// why each true drop was (not) predicted: at the drop, was the prediction armed, and how far was the line?
const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const TR=[['dare',134.03],['meduza',126],['deceiver',126.98],['vision',130.05],['espresso',126],['dtmf',130],['dolce',130]];
const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx')); fs.copyFileSync(process.argv[2],path.join(d,'artnet-controller.js')); fs.mkdirSync(path.join(d,'logs'));
TR.forEach((t,i)=>fs.copyFileSync('/tmp/'+t[0]+(process.env.SUF||'-28q')+'.ndjson',path.join(d,'logs','track-9000000'+i+'-000001.ndjson')));
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'}); const B='http://127.0.0.1:8080'; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{ await sleep(800); const {JSDOM}=require('jsdom');
 for(let i=0;i<TR.length;i++){ const [n,bpm]=TR[i], beat=60000/bpm;
  const v=new JSDOM(await (await fetch(B+'/logs/track-9000000'+i+'-000001.ndjson')).text(),{runScripts:'outside-only',url:B+'/logs/x'}).window;
  v.HTMLCanvasElement.prototype.getContext=()=>new Proxy({},{get:(t,k)=>k==='measureText'?()=>({width:0}):(k in t?t[k]:()=>{}),set:(t,k,x)=>{t[k]=x;return true;}});
  v.fetch=(u,o)=>fetch(B+u,o); v.requestAnimationFrame=()=>0; v.eval([...v.document.querySelectorAll('script')].map(x=>x.textContent).join('\n'));
  for(let j=0;j<50 && !v.eval('TL');j++) await sleep(100); await sleep(150); v.eval('ensureLivePlan()'); for(let j=0;j<900 && !v.eval('!!TL.rigLive');j++) await sleep(100);
  const WN=JSON.parse(v.eval('JSON.stringify(window.WN||[])')); const K=JSON.parse(fs.readFileSync('/tmp/'+n+'Kick.json')).map(x=>x*1000); const D=K.filter((k,q)=>q>0 && k-K[q-1]>=16*beat && k>5000);
  const RD=JSON.parse(v.eval("JSON.stringify(TL.ev.filter(function(e){return e.k==='rd'||e.k==='rb';}).map(function(e){return [e.k,e.t,e.ago||e.v];}))"));
  const rows=D.map(x=>{ const w=WN.filter(s=>s[0]<=x-50).pop()||[]; const line=w[3]!=null?w[0]+w[3]:null; const rb=RD.filter(r=>r[0]==='rb' && r[1]<=x).pop(); const rd=RD.find(r=>r[0]==='rd' && Math.abs(r[1]-r[2]-x)<300);
    const arm=WN.filter(s=>s[0]>x-3000 && s[0]<=x-50 && s[1]!=null).pop(); return (x/1000).toFixed(1)+': dropA '+(w[5]==null?'-':(w[5]/1000).toFixed(2))+' armed '+(arm?'Y line '+Math.round(arm[3]-x)+'ms':'n')+' brk '+w[2]+' gap '+w[6]+(rd?' rd +'+Math.round(rd[1]-x):' no-rd'); });
  console.log(n.padEnd(9)+rows.join(' | '));
  v.close(); }
 p.kill(); process.exit(0); })();
