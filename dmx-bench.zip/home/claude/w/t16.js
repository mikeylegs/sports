// grid precision on the real fixture (needs /mnt/user-data/uploads/track-52285985-558042.ndjson)
const {execSync}=require('child_process');
const out=execSync('node real.js '+process.argv[2]+' /mnt/user-data/uploads/track-52285985-558042.ndjson v1 2>&1').toString();
let n=0,f=0; const ok=(c,m)=>{n++; if(!c){f++; console.log('FAIL',m);} };
const lock=(out.match(/typically (\d+) ms\)/)||[])[1], ph=(out.match(/beat phase vs full-file: typically (\d+) ms/)||[])[1], ag=(out.match(/count on (\d+)%/)||[])[1];
ok(lock!=null && +lock<=20,'full-file grid locked to the kicks within 20 ms ('+lock+')');
ok(ph!=null && +ph<=20,'live grid within 20 ms of the full-file grid ('+ph+')');
ok(ag!=null && +ag>=75,'live phrase count agrees >=75% ('+ag+')');
{ const d=(out.match(/drops \["([\d.]+)","([\d.]+)"\]/)||[]).slice(1).map(Number); ok(d.length===2 && Math.abs(d[0]-106.7)<=0.3 && Math.abs(d[1]-137.2)<=0.3,'drops unchanged within 0.3 s ('+d+')'); }
console.log(`${n-f}/${n} passed`); process.exit(f?1:0);
