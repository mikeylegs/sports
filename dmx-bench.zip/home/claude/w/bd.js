// build tint + pre-drop breath vs the 19 true drops (stage view). Tint: when did it start before each drop, and was it
// on at the drop? Breath (blackout just before the drop): does it end on the drop kick? False tints: tint far from drops.
const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const TR=[['dare',134.03],['meduza',126],['deceiver',126.98],['vision',130.05],['espresso',126],['dtmf',130],['dolce',130]];
const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx')); fs.copyFileSync(process.argv[2],path.join(d,'artnet-controller.js')); fs.mkdirSync(path.join(d,'logs'));
TR.forEach((t,i)=>fs.copyFileSync('/tmp/'+t[0]+(process.env.SUF||'-28t')+'.ndjson',path.join(d,'logs','track-9000000'+i+'-000001.ndjson')));
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'}); const B='http://127.0.0.1:8080'; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{ await sleep(800); const {JSDOM}=require('jsdom'); const T={n:0,tint:0,breathOk:0,breath:0,falseTint:0,lead:[]};
 for(let i=0;i<TR.length;i++){ const [n,bpm]=TR[i], beat=60000/bpm, bar=4*beat;
  const v=new JSDOM(await (await fetch(B+'/logs/track-9000000'+i+'-000001.ndjson')).text(),{runScripts:'outside-only',url:B+'/logs/x'}).window;
  v.HTMLCanvasElement.prototype.getContext=()=>new Proxy({},{get:(t,k)=>k==='measureText'?()=>({width:0}):(k in t?t[k]:()=>{}),set:(t,k,x)=>{t[k]=x;return true;}});
  v.fetch=(u,o)=>fetch(B+u,o); v.requestAnimationFrame=()=>0; v.eval([...v.document.querySelectorAll('script')].map(x=>x.textContent).join('\n'));
  for(let j=0;j<50 && !v.eval('TL');j++) await sleep(100); await sleep(150); v.eval('ensureLivePlan()'); for(let j=0;j<900 && !v.eval('!!TL.rigLive');j++) await sleep(100);
  const P=JSON.parse(v.eval('JSON.stringify({tint:TL.rigLive.tint,blk:TL.rigLive.blk})')); const K=JSON.parse(fs.readFileSync('/tmp/'+n+'Kick.json')).map(x=>x*1000); const D=K.filter((k,q)=>q>0 && k-K[q-1]>=16*beat && k>5000);
  const on=t=>{ const x=(P.tint||[]).filter(z=>z[0]<=t).pop(); return x && x[1]>0; };
  const rows=D.map(x=>{ T.n++; let st=null; for(let t=x-100;t>x-16*bar;t-=100){ if(on(t)) st=t; else if(st!=null) break; } const lead=st!=null?(x-st)/bar:null; if(lead!=null){ T.tint++; T.lead.push(lead); }
    const br=(P.blk||[]).filter(b=>b[1]>x-2*beat && b[0]<x+beat).pop(); let bs='-'; if(br){ T.breath++; const e=Math.round(br[1]-x); bs=e+'ms'; if(Math.abs(e)<=60) T.breathOk++; }
    return (x/1000).toFixed(1)+': tint '+(lead==null?'none':lead.toFixed(1)+' bars')+' breath end '+bs; });
  // tint segments that end nowhere near a drop = false builds
  let segs=[],s0=null; (P.tint||[]).forEach(z=>{ if(z[1]>0 && s0==null) s0=z[0]; if(z[1]===0 && s0!=null){ segs.push([s0,z[0]]); s0=null; } }); const fz=segs.filter(s=>!D.some(x=>x>=s[0]-bar && x<=s[1]+2*bar)); T.falseTint+=fz.length;
  console.log(n.padEnd(9)+rows.join(' | ')+(fz.length?' | tint with no drop: '+fz.map(s=>(s[0]/1000).toFixed(0)+'-'+(s[1]/1000).toFixed(0)).join(','):''));
  v.close(); }
 T.lead.sort((a,b)=>a-b); console.log('ALL '+T.n+' drops: build tint before '+T.tint+' (median lead '+(T.lead.length?T.lead[T.lead.length>>1].toFixed(1):'-')+' bars) · breath before '+T.breath+', ending within 60 ms of the drop '+T.breathOk+' · tints with no drop '+T.falseTint);
 p.kill(); process.exit(0); })();
