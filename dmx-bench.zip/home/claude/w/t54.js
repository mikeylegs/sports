// 27g north star: builds ramp and explode into the drop (live preview = the rig) + reactive v2 on the beat
const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2], TR=['track-15337193-247718','track-39307571-582210','track-37199921-932496','track-52285985-558042','track-65570060-568769','track-15250173-827976'];
const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx')); fs.copyFileSync(FILE,path.join(d,'artnet-controller.js')); fs.mkdirSync(path.join(d,'logs'));
TR.forEach(t=>fs.copyFileSync('/mnt/user-data/uploads/'+t+'.ndjson',path.join(d,'logs',t+'.ndjson')));
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'});
const B='http://127.0.0.1:8080'; let fails=0,n=0; const ok=(c,m)=>{n++; if(!c){fails++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{ await sleep(800); const {JSDOM}=require('jsdom'); let D=0, ramp=0, blk=0, boom=0, rxOn=0, rxAll=0;
  await fetch(B+'/liveshow',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({strobe:'full'})});   // 27s: this suite tests the FULL strobe behaviour
  for(const t of TR){ const v=new JSDOM(await (await fetch(B+'/logs/'+t+'.ndjson')).text(),{runScripts:'outside-only',url:B+'/logs/x'}).window;
    v.HTMLCanvasElement.prototype.getContext=()=>new Proxy({},{get:(t,k)=>k==='measureText'?()=>({width:0}):(k in t?t[k]:()=>{}),set:(t,k,x)=>{t[k]=x;return true;}});
    v.fetch=(u,o)=>fetch(B+u,o); v.requestAnimationFrame=()=>0; v.eval([...v.document.querySelectorAll('script')].map(x=>x.textContent).join('\n'));
    for(let i=0;i<50 && !v.eval('TL');i++) await sleep(100);
    v.eval('ensureLivePlan()'); for(let i=0;i<900 && !v.eval('!!TL.rigLive');i++) await sleep(100);
    const P=JSON.parse(v.eval('JSON.stringify(TL.rigLive)')), S=JSON.parse(v.eval('JSON.stringify({drops:TL.sec.drops,bars:TL.sec.bars})'));
    const beat=(S.bars[10].t1-S.bars[10].t)/4, bar=4*beat, lines=[];
    S.drops.forEach(dt=>{ const pre=S.bars.filter(b=>b.t>=dt-4*bar-50 && b.t<dt-50); if(pre.length<2 || pre.some(b=>b.st==='G')) return;   // drops that follow a build/break
      D++; const f=P.strobe.filter(x=>x>=dt-4*bar && x<dt-beat), last=f.filter(x=>x>=dt-bar).length, early=f.filter(x=>x<dt-2*bar).length;
      const r=f.length>=6 && last>early/2; if(r) ramp++;
      const b=(P.blk||[]).some(x=>x[0]>=dt-1.6*beat && x[0]<=dt+50); if(b) blk++;
      const bo=(P.boom||[]).some(x=>x>=dt-100 && x<=dt+2*beat); if(bo) boom++;
      lines.push((dt/1000).toFixed(1)+': ramp '+f.length+' (last bar '+last+')'+(b?' · breath':'')+(bo?' · BOOM':'')); });
    // reactive v2: flashes before the first predictive snapshot, on the (hindsight) beat?
    const firstPred=((P.modeT||[]).find(x=>x[1]==='predictive')||[1e9])[0], beats=[]; S.bars.forEach(b=>{ const L=(b.t1-b.t)/4; for(let q=0;q<4;q++) beats.push(b.t+q*L); });
    const rx=P.strobe.filter(x=>x<firstPred && x>beats[0]); rxAll+=rx.length; rxOn+=rx.filter(x=>beats.some(b=>Math.abs(b-x)<=60)).length;
    console.log('  '+t.slice(6,14)+' · '+lines.join(' | ')+' · reactive flashes on the beat '+rx.filter(x=>beats.some(b=>Math.abs(b-x)<=60)).length+'/'+rx.length);
    v.close(); }
  console.log('  ALL: drops after a build '+D+' · ramped '+ramp+' · breath '+blk+' · boom '+boom+' · reactive on-beat '+rxOn+'/'+rxAll);
  console.log('   (roll flashes in the last bar before a drop: '+ramp+'/'+D+' -- 27j: real snare rolls only)'); ok(boom/D>=0.75,'most drops explode ('+boom+'/'+D+')');
  ok(rxAll>=20 && rxOn/rxAll>=0.8,'reactive v2 flashes land on the beat ('+rxOn+'/'+rxAll+')');
  console.log(`${n-fails}/${n} passed`); p.kill(); process.exit(fails?1:0);
})().catch(e=>{ console.log('ERR',e.stack); p.kill(); process.exit(2); });
