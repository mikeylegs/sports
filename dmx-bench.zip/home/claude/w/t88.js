// 28p: the laser chip names a scene only while the routine is driving the laser
const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2]; const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx')); fs.copyFileSync(FILE,path.join(d,'artnet-controller.js'));
fs.writeFileSync(path.join(d,'scenes.json'),JSON.stringify([{id:'a',name:'Particle Sky',channels:[[0,6,100]]},{id:'b',name:'Fan',channels:[[0,6,180]]}]));
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'}); const B='http://127.0.0.1:8080'; let n=0,f=0; const ok=(c,m)=>{n++; if(!c){f++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const post=(u,b)=>fetch(B+u,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)});
const L=480, snap=o=>post('/bridgestate',{levels:[0.3,0,0,0],active:[true,false,false,false],hits:[3,0,0,0],recording:true,build:'x',live:Object.assign({beatMs:L,nextBeatIn:100,pb:3,groove:true,mode:'heavy',slvl:1,kickOn:true,hatsOn:false,washIdx:2,washNextIn:9000,bpm:125},o)});
(async()=>{ await sleep(900); const {JSDOM}=require('jsdom');
  await post('/showcfg',{laser:{scenes:{checked:['a','b'],mode:'sequence',enabled:true,chEnabled:true}}}); await post('/liveshow',{enabled:true,latencyMs:0});
  const v=new JSDOM(await (await fetch(B+'/cc')).text(),{runScripts:'outside-only',url:B+'/cc'}).window; v.fetch=(u,o)=>fetch(B+u,o); v.eval(v.document.querySelector('script:not([data-nl])').textContent);
  const chip=()=>v.document.querySelector('.chip[data-fx="laser"] .s').textContent;
  for(let i=0;i<30;i++){ await post('/lv',{k:i%2?0.15:0.45}); if(i%4===0) await snap({}); await sleep(35); } await sleep(400);
  ok(['PARTICLE SKY','FAN'].indexOf(chip())>=0,'routine driving: chip names the scene ('+chip()+')');
  await post('/liveshow',{laserMode:'off'}); await sleep(500); ok(chip()==='ROUTINE OFF','laser mode OFF, laser dark: "ROUTINE OFF" ('+chip()+')');
  await post('/dmx',{bulk:[[0,1,50]]}); await sleep(500); ok(chip()==='FIRING \u00b7 NOT ROUTINE','something else fires it: no stale scene name ('+chip()+')');
  v.close(); await post('/liveshow',{enabled:false}); console.log(`${n-f}/${n} passed`); p.kill(); process.exit(f?1:0); })().catch(e=>{ console.log('ERR',e.stack); p.kill(); process.exit(2); });
