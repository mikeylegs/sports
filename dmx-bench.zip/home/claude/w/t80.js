// 28g: AUDIO chip per-band meters; a node that never answers ArtPoll reads as normal (grey SENDING, preflight OK)
const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2]; const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx')); fs.copyFileSync(FILE,path.join(d,'artnet-controller.js'));
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'}); const B='http://127.0.0.1:8080'; let n=0,f=0; const ok=(c,m)=>{n++; if(!c){f++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const post=(u,b)=>fetch(B+u,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)});
(async()=>{ await sleep(900); const {JSDOM}=require('jsdom');
  const v=new JSDOM(await (await fetch(B+'/cc')).text(),{runScripts:'outside-only',url:B+'/cc'}).window; v.fetch=(u,o)=>fetch(B+u,o); v.eval(v.document.querySelector('script:not([data-nl])').textContent);
  const $=id=>v.document.getElementById(id);
  for(let i=0;i<8;i++){ await post('/bridgestate',{levels:[0.30,0.05,0.12,0.01],active:[true,false,false,false],hits:[0,0,0,0],recording:true,build:'x'}); await sleep(120); }
  await post('/bridgestate',{levels:[0.30,0.02,0.12,0.005],active:[true,false,false,false],hits:[0,0,0,0],recording:true,build:'x'}); await sleep(600);
  const s=await (await fetch(B+'/ccstate')).json(); ok(s.audio.bands.length===4 && s.audio.bands[0]>0.9 && s.audio.bands[1]<0.6 && s.audio.names.join()==='Kick,Clap,Hats,Air','per-band levels vs each band\'s own peak ('+s.audio.bands.join(', ')+')');
  const bars=[...$('sAud').querySelectorAll('.mt i')].map(b=>parseInt(b.style.height)); ok(bars.length===4 && bars[0]>=14 && bars[1]<bars[0],'AUDIO chip draws 4 meters ('+bars.join('/')+' px)');
  ok($('sNode').querySelector('.v').textContent==='SENDING' && $('sNode').querySelector('.led').className.trim()==='led','node without ArtPoll: grey SENDING, not amber');
  ok(s.pf.find(x=>x.name==='Art-Net node').st==='ok','preflight counts it OK');
  $('sNode').dispatchEvent(new v.Event('click',{bubbles:true})); await sleep(80); ok(/nothing is wrong/.test($('shc').textContent),'NODE sheet explains it');
  v.close(); console.log(`${n-f}/${n} passed`); p.kill(); process.exit(f?1:0); })().catch(e=>{ console.log('ERR',e.stack); p.kill(); process.exit(2); });
