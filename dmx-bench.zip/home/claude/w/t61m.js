const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2]; const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx')); fs.copyFileSync(FILE,path.join(d,'artnet-controller.js')); fs.mkdirSync(path.join(d,'logs'));
fs.copyFileSync('/tmp/track-80355717-523518.ndjson',path.join(d,'logs','track-80355717-523518.ndjson'));
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'}); const B='http://127.0.0.1:8080'; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{ await sleep(800); const {JSDOM}=require('jsdom');
  const v=new JSDOM(await (await fetch(B+'/logs/track-80355717-523518.ndjson')).text(),{runScripts:'outside-only',url:B+'/logs/x'}).window;
  v.HTMLCanvasElement.prototype.getContext=()=>new Proxy({},{get:(t,k)=>k==='measureText'?()=>({width:0}):(k in t?t[k]:()=>{}),set:(t,k,x)=>{t[k]=x;return true;}});
  v.fetch=(u,o)=>fetch(B+u,o); v.requestAnimationFrame=()=>0; v.eval([...v.document.querySelectorAll('script')].map(x=>x.textContent).join('\n'));
  for(let i=0;i<50 && !v.eval('TL');i++) await sleep(100); v.eval('ensureLivePlan()'); for(let i=0;i<900 && !v.eval('!!TL.rigLive');i++) await sleep(100);
  const P=JSON.parse(v.eval('JSON.stringify(TL.rigLive)')), S=JSON.parse(v.eval('JSON.stringify({bars:TL.sec.bars,bpm:TL.sec.bpm,drops:TL.sec.drops,lock:TL.sec.lockMs})'));
  const F=JSON.parse(v.eval("JSON.stringify(TL.ev.filter(function(e){return e.k==='f';}).map(function(f){return [f.t,f.e[0]];}))"));
  const beats=[]; S.bars.forEach(b=>{ const L=(b.t1-b.t)/4; for(let q=0;q<4;q++) beats.push(b.t+q*L); });
  const onB=P.strobe.filter(t=>beats.some(b=>Math.abs(b-t)<=60)).length;
  console.log('bpm',S.bpm,'lock',S.lock&&S.lock.toFixed(0),'drops',S.drops.map(x=>(x/1000).toFixed(1)).join(','),'| flashes',P.strobe.length,'on the grid',onB, '| modes',(P.modeT||[]).map(x=>(x[0]/1000).toFixed(0)+x[1][0]).join(' '));
  let row=[]; for(let a=0;a<240000;a+=15000){ const fl=P.strobe.filter(t=>t>=a&&t<a+15000).length, lv=F.filter(f=>f[0]>=a&&f[0]<a+15000), m=lv.reduce((s,f)=>s+f[1],0)/Math.max(1,lv.length); row.push((a/1000)+'s:'+fl+'fl/kick'+m.toFixed(2)); }
  console.log(row.join('  ')); v.close(); p.kill(); process.exit(0); })();
