// 27w: strobe level 0-4 -- policy, rig API/Show tab, phrase accent, stage view density per level
const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2], SRC=fs.readFileSync(FILE,'utf8'); let n=0,f=0; const ok=(c,m)=>{n++; if(!c){f++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const SJ=(SRC.match(/const SHOW_JS = String\.raw`([\s\S]*?)`;/)||[])[1]; const G={}; try{ new Function('G',SJ+'\nG.p=strobePolicy;')(G); }catch(e){}
ok(typeof G.p==='function','strobePolicy shared by rig + stage view');
if(G.p){ const L=480, P=(lv,why,bars,bib,pk)=>G.p(lv,why,bars*4*L,L,bib,pk);
  ok(P(0,'drop',0,0)===0 && P(0,'beat',0.5,1)===0,'level 0: nothing, not even the drop');
  ok(P(1,'drop',0,0)===1 && P(1,'beat',0.5,3)===1 && P(1,'beat',2.5,0)===0 && P(1,'phrase',20,0)===0,'level 1: drop + the drop bar only');
  ok(P(2,'beat',0.5,3)===1 && P(2,'beat',2.2,0)===0.8 && P(2,'beat',2.2,2)===0.8 && P(2,'beat',2.2,1)===0 && P(2,'beat',5.5,0)===0.6 && P(2,'beat',5.5,2)===0 && P(2,'beat',9,0)===0,'level 2: drop bar full, bars 2-4 on 1 & 3, bars 5-8 on the 1, then quiet');
  ok(P(2,'phrase',20,0)===1 && P(2,'beat',20,0,true)===0,'level 2: phrase accents; peak grooves stay dark');
  ok(P(3,'beat',20,0,true)===0.8 && P(3,'beat',20,2,true)===0 && P(3,'beat',20,0,false)===0,'level 3: the 1 of each bar in a peak groove');
  ok(P(4,'beat',20,3,false)===1,'level 4: everything'); }
const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx')); fs.copyFileSync(FILE,path.join(d,'artnet-controller.js')); fs.mkdirSync(path.join(d,'logs'));
fs.copyFileSync('/tmp/meduza-27v.ndjson',path.join(d,'logs','track-90000001-000001.ndjson'));
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'}); const B='http://127.0.0.1:8080';
const post=(u,b)=>fetch(B+u,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)});
(async()=>{ await sleep(900); const {JSDOM}=require('jsdom');
  let c=await (await fetch(B+'/liveshow')).json(); ok(c.level===2,'default strobe level 2 ('+c.level+')');
  await post('/liveshow',{level:3}); c=await (await fetch(B+'/liveshow')).json(); ok(c.level===3 && c.strobe==='drops','set level 3');
  await post('/liveshow',{strobe:'full'}); c=await (await fetch(B+'/liveshow')).json(); ok(c.level===4,'old FULL switch -> level 4');
  const sh=await (await fetch(B+'/lab/show')).text(); ok(/id="lvb"/.test(sh) && (sh.match(/data-l="/g)||[]).length===5,'Show tab: 0-4 selector');
  // stage view density per level on Tell Me Why
  const cnt={};
  for(const lv of [1,2,3,4]){ await post('/liveshow',{level:lv});
    const v=new JSDOM(await (await fetch(B+'/logs/track-90000001-000001.ndjson')).text(),{runScripts:'outside-only',url:B+'/logs/x'}).window;
    v.HTMLCanvasElement.prototype.getContext=()=>new Proxy({},{get:(t,k)=>k==='measureText'?()=>({width:0}):(k in t?t[k]:()=>{}),set:(t,k,x)=>{t[k]=x;return true;}});
    v.fetch=(u,o)=>fetch(B+u,o); v.requestAnimationFrame=()=>0; v.eval([...v.document.querySelectorAll('script')].map(x=>x.textContent).join('\n'));
    for(let j=0;j<50 && !v.eval('TL');j++) await sleep(100); await sleep(200); v.eval('ensureLivePlan()'); for(let j=0;j<900 && !v.eval('!!TL.rigLive');j++) await sleep(100);
    cnt[lv]=v.eval('TL.rigLive.strobe.length'); v.close(); }
  console.log('   stage view flashes, Tell Me Why: level 1 '+cnt[1]+' · 2 '+cnt[2]+' · 3 '+cnt[3]+' · 4 '+cnt[4]);
  ok(cnt[1]<cnt[2] && cnt[2]<cnt[3] && cnt[3]<cnt[4],'each level adds strobe');
  ok(cnt[2]>=1.8*cnt[1],'level 2 is clearly more than drops-only (the drought)');
  console.log(`${n-f}/${n} passed`); p.kill(); process.exit(f?1:0); })().catch(e=>{ console.log('ERR',e.stack); p.kill(); process.exit(2); });
