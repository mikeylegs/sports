const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2]; const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx'));
fs.copyFileSync(FILE,path.join(d,'artnet-controller.js'));
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'});
const B='http://127.0.0.1:8080'; let fails=0, n=0;
const ok=(c,m)=>{n++; if(!c){fails++; console.log('FAIL',m);} };
const get=u=>fetch(B+u).then(r=>r.text().then(t=>({s:r.status,t})));
function scriptsParse(html,label){ const re=/<script>([\s\S]*?)<\/script>/g; let m,c=0; while((m=re.exec(html))){ c++; try{ new Function(m[1]); }catch(e){ ok(false,label+' script parse: '+e.message); } } return c; }
(async()=>{
  await new Promise(r=>setTimeout(r,800));
  const ed=await get('/');
  ok(/href="\/lab" id="labbtn"/.test(ed.t),'editor Lab button');
  ok(ed.t.indexOf('id="fxbtn"')<ed.t.indexOf('id="labbtn"') && ed.t.indexOf('id="labbtn"')-ed.t.indexOf('id="fxbtn"')<1500,'Lab next to Settings');
  ok(!/det-bridge|det-link|linkLeadMs|bbands/.test(ed.t),'Settings bridge/link sections gone');
  ok(/href="\/lab"[^>]*>Audio Lab &rarr;/.test(ed.t),'Settings Audio Lab link');
  ok(/det-fixtures/.test(ed.t)&&/det-scenes/.test(ed.t)&&/det-power/.test(ed.t),'Settings keeps F/S/P');
  scriptsParse(ed.t,'editor');
  const tabs={'/lab':'Live','/lab/mark':'Mark','/lab/recordings':'Recordings','/lab/link':'Link'};
  for(const u in tabs){ const r=await get(u); ok(r.s===200,u+' 200');
    ok(new RegExp('<a href="'+u.replace(/\//g,'\\/')+'" class="on">'+tabs[u]+'<').test(r.t),u+' active tab');
    ok(/<a href="\/">&larr; Editor<\/a><h1>Audio Lab/.test(r.t),u+' back to editor');
    ok(!/href="\/#bridge"|href="\/tune"|href="\/mark"|>Mark page</.test(r.t),u+' no old nav links');
    if(u!=='/lab/recordings') ok(scriptsParse(r.t,u)>=1,u+' has script'); }
  for(const u of ['/tune','/mark','/logs']) ok((await get(u)).s===200,u+' alias still 200');
  const lk=(await get('/lab/link')).t; ok(/id="linkLeadMs"/.test(lk)&&/id="linkEnabled"/.test(lk),'link controls on Link tab');
  fs.mkdirSync(path.join(d,'logs'),{recursive:true}); fs.writeFileSync(path.join(d,'logs','bridge-20260925-120000.ndjson'),'{"k":"start","t":0}\n');
  const v=await get('/logs/bridge-20260925-120000.ndjson'); ok(/<a class="back" href="\/lab\/recordings">/.test(v.t),'viewer back -> Lab');
  const {JSDOM}=require('jsdom'); const html=(await get('/lab')).t; const posts=[];
  const cfg=JSON.parse((await get('/bridgeconfig')).t);
  const dom=new JSDOM(html,{runScripts:'outside-only'}); const w=dom.window;
  w.fetch=(u,o)=>{ if(o&&o.method==='POST') posts.push({u,b:JSON.parse(o.body)}); const body=u==='/bridgeconfig'?cfg:(u==='/health'?{build:'x',node:{}}:{stale:true}); return Promise.resolve({json:()=>Promise.resolve(JSON.parse(JSON.stringify(body)))}); };
  w.setInterval=()=>0; const s=[...w.document.querySelectorAll('script')].map(x=>x.textContent).join('\n'); w.eval(s);
  await new Promise(r=>setTimeout(r,50));
  ok(w.document.querySelectorAll('details.adv').length===4,'4 Advanced blocks');
  const lo=w.document.getElementById('lo1'); ok(lo && +lo.value===cfg.bands[1].lo,'lo1 prefilled');
  if(lo){ lo.value='1100'; lo.dispatchEvent(new w.Event('input')); }
  await new Promise(r=>setTimeout(r,400));
  const last=posts.filter(p=>p.u==='/bridgeconfig').pop(); ok(last && last.b.bands[1].lo===1100,'Hz edit saved via /bridgeconfig');
  if(last){ await fetch(B+'/bridgeconfig',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(last.b)}); ok(JSON.parse((await get('/bridgeconfig')).t).bands[1].lo===1100,'server stored lo'); }
  console.log(`${n-fails}/${n} passed`); p.kill(); process.exit(fails?1:0);
})().catch(e=>{console.log('ERR',e.message); p.kill(); process.exit(2);});
