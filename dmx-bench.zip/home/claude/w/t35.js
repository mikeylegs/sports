const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2]; const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx'));
fs.copyFileSync(FILE,path.join(d,'artnet-controller.js')); fs.mkdirSync(path.join(d,'logs')); fs.mkdirSync(path.join(d,'tracks'));
fs.copyFileSync('/mnt/user-data/uploads/track-52285985-558042.ndjson',path.join(d,'logs','track-52285985-558042.ndjson'));
fs.writeFileSync(path.join(d,'tracks','Supermode - Tell Me Why (Meduza Remix).m4a'),Buffer.alloc(100));
fs.writeFileSync(path.join(d,'logs','bridge-20260926-120000.ndjson'),fs.readFileSync('/mnt/user-data/uploads/track-52285985-558042.ndjson','utf8').replace('"src":"track"','"src":"bridge"'));
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'});
const B='http://127.0.0.1:8080'; let fails=0,n=0; const ok=(c,m)=>{n++; if(!c){fails++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const open=async(nm)=>{ const {JSDOM}=require('jsdom'); const v=new JSDOM(await (await fetch(B+'/logs/'+nm)).text(),{runScripts:'outside-only',url:B+'/logs/x'}).window; let strokes=0;
  v.HTMLCanvasElement.prototype.getContext=()=>new Proxy({},{get:(t,k)=>k==='measureText'?()=>({width:0}):k==='stroke'?()=>{strokes++;}:(k in t?t[k]:()=>{}),set:(t,k,x)=>{t[k]=x;return true;}});
  v.fetch=(u,o)=>fetch(B+u,o); v.requestAnimationFrame=()=>0; v.localStorage.setItem('artnetRigMode2','full'); v.eval([...v.document.querySelectorAll('script')].map(x=>x.textContent).join('\n'));
  for(let i=0;i<50 && !v.eval('TL');i++) await sleep(100); v.__s=()=>strokes; return v; };
(async()=>{ await sleep(800);
  const v=await open('track-52285985-558042.ndjson'), $=id=>v.document.getElementById(id);
  const b=$('stagebtn'); ok(!!b,'Stage view button'); if(!b){ console.log(`${n-fails}/${n} passed`); p.kill(); process.exit(1); }
  b.click(); ok($('stage').style.display==='block','opens full screen');
  const R=v.eval('TL.rig'), hit=R.hits.find(h=>h.ok), blk=R.blk.find(x=>Math.abs(x[1]-hit.t)<400), gb=R.bars.find(x=>x.look==='groove' && x.t>hit.t+4000);
  const P=t=>JSON.parse(v.eval('JSON.stringify(stagePaint('+t+').beams)'));
  const sg=R.laz.find(x=>x.t>=gb.t && x.t<gb.t1) || R.laz.find(x=>x.t>hit.t+4000); let s0=v.__s(); P(sg.t+20); const beamsG=v.__s()-s0;   // 26ag: sample ON a laser stab
  ok(beamsG>=5 && parseFloat($('stL').style.opacity)>0.5 && $('stL').style.background.includes(gb.rgb.join(', ')),'groove: both PARs glow in the palette colour, laser fans ('+beamsG+' beams)');
  ok($('stR').style.background===$('stL').style.background,'left and right PAR in step');
  P(hit.t+20); ok($('stStrobe').style.opacity==='1' && $('stFix').style.background==='rgb(255, 255, 255)' && /255, 255, 255/.test($('stL').style.background),'drop hit: whole screen flashes, strobe fixture lit, PARs white');
  ok($('stFog').style.opacity==='1','fog on the drop');
  s0=v.__s(); P((blk[0]+blk[1])/2); ok($('stL').style.opacity==='0' && $('stStrobe').style.opacity==='0' && v.__s()===s0 && /blackout/.test($('stLook').textContent),'blackout beat: everything dark, laser off');
  const bb=R.bars.find(x=>x.look==='break'); if(bb){ s0=v.__s(); P(bb.t+50); const beamsB=v.__s()-s0; ok(beamsB<beamsG && parseFloat($('stL').style.opacity)<0.4,'break: dim blue, sparse laser ('+beamsB+' beams)'); }
  $('stClose').click(); ok($('stage').style.display==='none','closes');
  v.close();
  const w=await open('bridge-20260926-120000.ndjson'); w.document.getElementById('stagebtn').click(); ok(w.document.getElementById('stage').style.display!=='block' && /No audio/.test(w.document.getElementById('stagemsg').textContent),'no audio: says so, stays closed'); w.close();
  console.log(`${n-fails}/${n} passed`); p.kill(); process.exit(fails?1:0);
})().catch(e=>{ console.log('ERR',e.stack); p.kill(); process.exit(2); });
