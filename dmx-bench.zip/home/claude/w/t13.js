const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2]; const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx'));
fs.copyFileSync(FILE,path.join(d,'artnet-controller.js'));
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'});
const B='http://127.0.0.1:8080'; let fails=0,n=0; const ok=(c,m)=>{n++; if(!c){fails++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const done=()=>{ console.log(`${n-fails}/${n} passed`); p.kill(); process.exit(fails?1:0); };
(async()=>{ await sleep(800); const {JSDOM}=require('jsdom');
  // --- Pi bridge page with a fake mic
  const bw=new JSDOM(await (await fetch(B+'/bridge')).text(),{runScripts:'outside-only',url:B+'/bridge'}).window;
  const ended=[]; const track={label:'USB Audio CODEC', readyState:'live', muted:false, addEventListener:(e,f)=>{ if(e==='ended') ended.push(f); }};
  const stream={getAudioTracks:()=>[track], getTracks:()=>[track]};
  const node=()=>({connect(){}, disconnect(){}, frequency:{value:0}, type:'', fftSize:1024, getFloatTimeDomainData(a){ a.fill(0); }});
  bw.AudioContext=function(){ this.sampleRate=48000; this.state='running'; this.createMediaStreamSource=node; this.createBiquadFilter=node; this.createAnalyser=node; this.close=()=>{}; this.resume=()=>Promise.resolve(); };
  Object.defineProperty(bw.navigator,'mediaDevices',{value:{getUserMedia:()=>Promise.resolve(stream)}});
  bw.requestAnimationFrame=f=>setTimeout(()=>f(Date.now()),16); bw.fetch=(u,o)=>fetch(B+u,o);
  bw.eval([...bw.document.querySelectorAll('script')].map(x=>x.textContent).join('\n'));
  await sleep(1800);
  let s=await (await fetch(B+'/bridgestate')).json(); const m=s.mon||{};
  ok(!!s.mon,'bridge sends a monitor snapshot');
  if(!s.mon){ done(); return; }
  ok(m.mic.label==='USB Audio CODEC' && m.mic.sr===48000 && m.mic.state==='live' && m.mic.ctx==='running','mic label / 48 kHz / live / running');
  ok(m.tps>20,'detector tick rate reported ('+m.tps+'/s)');
  ok(/Listening/.test(m.status) && !m.rec.on,'status listening, not recording');
  bw.eval('startSession()'); await sleep(1600);
  s=await (await fetch(B+'/bridgestate')).json();
  ok(s.mon.rec.on && /^bridge-\d{8}-\d{6}$/.test(s.mon.rec.id) && s.mon.rec.events>0 && s.mon.rec.dur>=1000,'recording: id, duration, events ('+s.mon.rec.events+')');
  ok(s.mon.log.ok>=1 && s.mon.log.fail===0,'event uploads counted ('+s.mon.log.ok+' ok)');
  ok(fs.existsSync(path.join(d,'logs',s.mon.rec.id+'.ndjson')),'the recording file the monitor links to exists');
  // --- Live tab renders it
  const lw=new JSDOM(await (await fetch(B+'/lab')).text(),{runScripts:'outside-only'}).window; lw.fetch=(u,o)=>fetch(B+u,o);
  lw.eval([...lw.document.querySelectorAll('script')].map(x=>x.textContent).join('\n')); await sleep(700);
  const t=lw.document.getElementById('pimon').textContent, a=lw.document.querySelector('#pimon a');
  ok(/USB Audio CODEC · 48\.0 kHz · live/.test(t) && /ticks\/s/.test(t),'Live: mic + detector rows');
  ok(a && a.getAttribute('href')==='/logs/'+s.mon.rec.id+'.ndjson','Live: recording links to its file');
  ok(/events \d+ ok \/ 0 failed/.test(t) && /Last error.*none/.test(t),'Live: uploads + no errors');
  // mic unplugged
  ended.forEach(f=>f()); await sleep(700);
  s=await (await fetch(B+'/bridgestate')).json(); ok(s.mon.reconnects===1 && /Mic lost/.test(s.mon.err),'mic loss: reconnect counted, error kept');
  await sleep(500); const t2=lw.document.getElementById('pimon'); ok(t2.querySelector('.mrow.m-bad') && /Mic lost/.test(t2.textContent),'Live: flags it red');
  bw.close();
  // old Pi build (no mon) -> explains
  await fetch(B+'/bridgestate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({levels:[0,0,0,0],build:'2026-09-25c'})}); await sleep(600);
  ok(/older build/.test(lw.document.getElementById('pimon').textContent),'Live: older Pi build explained');
  lw.close(); done();
})().catch(e=>{ console.log('ERR',e.message); p.kill(); process.exit(2); });
