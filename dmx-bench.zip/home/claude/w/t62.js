// 27l Link simulator on the rig: manual BPM answers /linksync when djay's Link is silent; real Link wins
const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2]; const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx')); fs.copyFileSync(FILE,path.join(d,'artnet-controller.js'));
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'}); const B='http://127.0.0.1:8080'; let fails=0,n=0; const ok=(c,m)=>{n++; if(!c){fails++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const post=(u,b)=>fetch(B+u,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)});
(async()=>{ await sleep(800);
  let j=await (await fetch(B+'/linksync')).json(); ok(j.stale===true,'no Link, no manual BPM: stale');
  let r=await post('/liveshow',{manualBpm:134}); ok(r.status===200,'set manual BPM');
  j=await (await fetch(B+'/linksync')).json(); ok(j.stale===false && j.manual===true && j.bpm===134 && j.beatNow>=0,'Link simulator answers at 134 BPM');
  const b1=j.beatNow; await sleep(448); j=await (await fetch(B+'/linksync')).json(); ok(Math.abs(j.beatNow-b1-1)<0.15,'its beat advances at the set tempo ('+(j.beatNow-b1).toFixed(2)+' beats in 448 ms)');
  await post('/linksync',{bpm:128,beat:10,phase:2,playing:true}); j=await (await fetch(B+'/linksync')).json(); ok(j.bpm===128 && !j.manual,'real djay Link wins over the manual BPM');
  const s=await (await fetch(B+'/liveshow')).json(); ok(s.manualBpm===134 && s.linkLive===true,'Show tab status: manual BPM kept, Link live');
  ok((await post('/liveshow',{manualBpm:500})).status===400,'bad BPM rejected'); await post('/liveshow',{manualBpm:null});
  const sh=await (await fetch(B+'/lab/show')).text(); ok(/id="mbpm"/.test(sh),'Show tab has the Manual BPM field');
  console.log(`${n-fails}/${n} passed`); p.kill(); process.exit(fails?1:0); })().catch(e=>{ console.log('ERR',e.stack); p.kill(); process.exit(2); });
