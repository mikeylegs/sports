const fs=require('fs'); const {G}=require('./t28.js');
const file='/mnt/user-data/uploads/track-96314428-446959.ndjson', ev=fs.readFileSync(file,'utf8').trim().split('\n').map(JSON.parse);
const K=ev.filter(e=>e.k==='h'&&e.b===1).map(e=>e.t).sort((a,b)=>a-b); let last=-1e9; const KD=K.filter(t=>{ if(t-last<150) return false; last=t; return true; });
const full=G.AS(ev), beats=[]; full.bars.forEach(b=>{ const L=(b.t1-b.t)/4; for(let q=0;q<4;q++) beats.push(b.t+q*L); });
const nearK=t=>{ let best=1e9; for(const k of KD){ const d=k-t; if(Math.abs(d)<Math.abs(best)) best=d; if(k>t+500) break; } return best; };
const fe=beats.filter(b=>b>60000).map(nearK).filter(d=>Math.abs(d)<150).map(Math.abs).sort((a,b)=>a-b);
console.log('hindsight grid vs kick hits: n',fe.length,'median',fe[fe.length>>1],'p90',fe[Math.floor(fe.length*0.9)], 'lockMs', full.lockMs);
const E=ev.filter(e=>e.k==='f'||e.k==='h').sort((a,b)=>a.t-b.t), L=new G.LE(); let i=0; const le=[];
for(let now=0; now<=E[E.length-1].t; now+=100){ while(i<E.length && E[i].t<=now) L.push(E[i++]); L.step(now); if(now%300===0){ const s=L.snap(now); if(s && s.groove){ const d=nearK(now+s.nextBeatIn); if(Math.abs(d)<150) le.push(Math.abs(d)); } } }
le.sort((a,b)=>a-b); console.log('live predicted beat vs kick hits: n',le.length,'median',le[le.length>>1],'p90',le[Math.floor(le.length*0.9)]);
{ const L2=new G.LE(); let j=0; const rows=[]; const near=t=>{ let lo=0,hi=beats.length-1; while(lo<hi){ const m=(lo+hi)>>1; if(beats[m]<t) lo=m+1; else hi=m; } const a=beats[lo]-t, b2=lo?beats[lo-1]-t:1e9; return Math.abs(a)<Math.abs(b2)?-a:-b2; };
  for(let now=0; now<=E[E.length-1].t; now+=100){ while(j<E.length && E[j].t<=now) L2.push(E[j++]); L2.step(now); if(now%3000===0){ const s=L2.snap(now); if(s && s.groove) rows.push((now/1000).toFixed(0)+':'+Math.round(near(now+s.nextBeatIn))+'/'+s.beatMs.toFixed(0)+'/e'+s.edge); } }
  console.log('signed live-vs-hindsight error (s:ms/beatMs/edgeKicks):',rows.join(' ')); console.log('hindsight beatMs', ((full.bars[40].t1-full.bars[40].t)/4).toFixed(1)); }
