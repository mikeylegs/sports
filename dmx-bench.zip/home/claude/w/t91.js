// 28t: the master tempo through DJ transitions (synthetic blends / rides / cut built from the real tracks, /tmp/mix)
const fs=require('fs'); const SRC=fs.readFileSync(process.argv[2],'utf8'); const TJ=(SRC.match(/const TEMPO_JS = String\.raw`([\s\S]*?)`;/)||[])[1];
let n=0,f=0; const ok=(c,m)=>{n++; if(!c){f++; console.log('FAIL',m);} }; const G={}; new Function('G',TJ+'\nG.TT=TempoTracker; G.O=TEMPO_OPT;')(G);
function run(nm){ const L=JSON.parse(fs.readFileSync('/tmp/mix/'+nm+'.lv.json')), TL=JSON.parse(fs.readFileSync('/tmp/mix/'+nm+'.truth.json')); const truth=t=>{ let b=TL[0][1]; TL.forEach(x=>{ if(x[0]<=t) b=x[1]; }); return b; };
  const tt=new G.TT(G.O), ev=[]; for(let k=0;k<L.ticks[0].length;k++){ tt.feed([0,1,2,3,4,5].map(i=>L.ticks[i][k]||0)); if(k%30===0 && tt.bpm) ev.push([k*1000/60,tt.bpm]); }
  const w=p=>ev.filter(e=>Math.abs(e[1]-truth(e[0]))/truth(e[0])<=p).length/ev.length; return {ev,truth,w}; }
const A=run('s1_blend_same'); ok(A.w(0.005)>=0.95,'beatmatched blend: stays on tempo ('+Math.round(A.w(0.005)*100)+'% within 0.5%)');
const B=run('s2_ride_up'); ok(B.w(0.01)>=0.95,'pitch ride 126 -> 130: follows within 1% '+Math.round(B.w(0.01)*100)+'% of the time');
const C=run('s3_cut'); const rec=(C.ev.find(e=>e[0]>=45000 && C.ev.filter(z=>z[0]>=e[0] && z[0]<e[0]+10000).every(z=>Math.abs(z[1]-134)/134<=0.005))||[1e9])[0]-45000;
ok(rec<=9000,'hard cut 127 -> 134: back on tempo in '+(rec/1000).toFixed(1)+' s');
const D=run('s4_blend_ride'); ok(D.w(0.01)>=0.95,'blend into a pushed track, then ride it home: within 1% '+Math.round(D.w(0.01)*100)+'% of the time');
console.log(`${n-f}/${n} passed`); process.exit(f?1:0);
