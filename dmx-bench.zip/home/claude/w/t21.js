const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2], SRC=fs.readFileSync(FILE,'utf8'); const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx'));
fs.copyFileSync(FILE,path.join(d,'artnet-controller.js'));
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'});
const B='http://127.0.0.1:8080'; let fails=0,n=0; const ok=(c,m)=>{n++; if(!c){fails++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const done=()=>{ console.log(`${n-fails}/${n} passed`); p.kill(); process.exit(fails?1:0); };
(async()=>{ await sleep(800); const {JSDOM}=require('jsdom');
  const html=await (await fetch(B+'/bridge')).text();
  const bw=new JSDOM(html,{runScripts:'outside-only',url:B+'/bridge'}).window;
  // 1) the worklet processor itself (pulled from the served page), run in node
  let code=null; bw.eval('0'); const m=html.match(/var DMX_WL=\[([\s\S]*?)\]\.join/); ok(!!m,'worklet source in the page');
  if(!m){ done(); return; }
  code=Function('return ['+m[1]+'].join("\\n")')();
  const reg={}; const posts=[]; class AWP{ constructor(){ this.port={postMessage:x=>posts.push(x), onmessage:null}; } }
  new Function('AudioWorkletProcessor','registerProcessor','sampleRate',code)(AWP,(n,c)=>{reg[n]=c;},48000);
  ok(!!reg['dmx-bands'],'registers dmx-bands');
  const P=new reg['dmx-bands'](); P.port.onmessage({data:{bands:[{lo:40,hi:120},{lo:1000,hi:4000},{lo:6000,hi:12000},{lo:12000,hi:16000}]}});
  const sr=48000; let t=0; for(let blk=0;blk<375;blk++){ const a=new Float32Array(128); for(let i=0;i<128;i++,t++) a[i]=0.5*Math.sin(2*Math.PI*70*t/sr); P.process([[a]]); }   // 1 s of 70 Hz
  ok(posts.length>=59 && posts.length<=61,'~60 level posts per second ('+posts.length+')');
  const last=posts[posts.length-1].lv; ok(last[0]>0.3 && last[0]<0.6 && last[1]<0.01 && last[3]<0.001,'70 Hz lands in the kick band only ('+last.map(x=>x.toFixed(4)).join(',')+')');
  // same numbers as the offline twin (same coefficients + window)
  const TDJ=(SRC.match(/const TRACK_DETECT_JS = `([\s\S]*?)`;/)||[])[1]; const g={}; new Function('G',TDJ+';G.c=tdCoefs;')(g);
  const H=g.c(true,40,sr), L=g.c(false,120,sr); let h=[0,0,0,0], l=[0,0,0,0], ring=[]; for(let i=0;i<sr;i++){ const x=0.5*Math.sin(2*Math.PI*70*i/sr);
    const y=H[0]*x+H[1]*h[0]+H[2]*h[1]-H[3]*h[2]-H[4]*h[3]; h=[x,h[0],y,h[2]]; const z=L[0]*y+L[1]*l[0]+L[2]*l[1]-L[3]*l[2]-L[4]*l[3]; l=[y,l[0],z,l[2]]; ring.push(z*z); }
  const ref=Math.sqrt(ring.slice(-1024).reduce((a,b)=>a+b,0)/1024), wl2=posts.find((x,i)=>i===posts.length-1).lv[0];
  ok(Math.abs(ref-wl2)/ref<0.03,'matches the offline detector math ('+ref.toFixed(4)+' vs '+wl2.toFixed(4)+')');
  // 2) page wiring with a fake mic + fake AudioWorklet
  const track={label:'USB Audio CODEC', readyState:'live', muted:false, addEventListener(){}}, stream={getAudioTracks:()=>[track], getTracks:()=>[track]};
  const node=()=>({connect(){}, disconnect(){}, frequency:{value:0}, gain:{value:1}, type:'', fftSize:1024, getFloatTimeDomainData(a){ a.fill(0); }});
  let WN=null; bw.AudioWorkletNode=function(ctx,name){ WN=this; this.name=name; this.port={postMessage:x=>{this.cfg=x;}, onmessage:null}; this.connect=()=>{}; };
  bw.AudioContext=function(){ this.sampleRate=48000; this.state='running'; this.destination={}; this.createMediaStreamSource=node; this.createBiquadFilter=node; this.createAnalyser=node; this.createGain=node; this.audioWorklet={addModule:()=>Promise.resolve()}; this.close=()=>{}; };
  bw.URL.createObjectURL=()=>'blob:x';
  Object.defineProperty(bw.navigator,'mediaDevices',{value:{getUserMedia:()=>Promise.resolve(stream)}});
  let rafN=0; bw.requestAnimationFrame=f=>{ rafN++; setTimeout(()=>f(0),16); return rafN; }; bw.fetch=(u,o)=>fetch(B+u,o);
  bw.eval(bw.document.querySelector('script:not([data-nl])').textContent);
  await sleep(300);
  ok(WN && WN.name==='dmx-bands' && WN.cfg && WN.cfg.bands.length===6 && WN.cfg.bands[4].lo===30 && WN.cfg.bands[5].lo===250,'worklet node created + given the 4 bands + 2 hidden colour bands (27u)');
  ok(bw.eval('USE_WL') && bw.eval('MON.engine')==='worklet','engine = worklet');
  const r0=rafN; await sleep(200); ok(rafN-r0<=1,'rAF loop stops once the worklet runs ('+(rafN-r0)+')');
  Object.defineProperty(bw.document,'hidden',{get:()=>true});   // window minimised: messages still drive detection
  const t0=bw.eval('MON.ticks'); for(let i=0;i<30;i++) WN.port.onmessage({data:{lv:[0.2,0.01,0.01,0.001]}});
  ok(bw.eval('MON.ticks')-t0===30,'worklet messages drive tick while hidden');
  { const m=(bw.document.getElementById('lvl0').style.clipPath||'').match(/inset\(0 ([\d.]+)% 0 0\)/), w=m?100-parseFloat(m[1]):0; ok(w>75 && w<=80,'kick meter follows worklet level ('+w+'%)'); }
  // config change reaches the worklet
  await fetch(B+'/bridgeconfig').then(r=>r.json()).then(c=>{ c.bands[0].lo=45; return fetch(B+'/bridgeconfig',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(c)}); });
  bw.eval('pullCfg()'); await sleep(300); ok(WN.cfg.bands[0].lo===45,'band change forwarded to the worklet');
  await sleep(700); const s=await (await fetch(B+'/bridgestate')).json(); ok(s.mon && s.mon.engine==='worklet' && s.mon.hidden===true,'monitor reports worklet + hidden');
  // 3) console: Link panel
  await fetch(B+'/linksync',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({bpm:126.5,beat:10.25,phase:0.25,playing:true})});
  await sleep(400); ok(/126\.5/.test(bw.document.getElementById('lbpm').textContent) && /live/.test(bw.document.getElementById('lst').textContent),'Link panel shows BPM live ('+bw.document.getElementById('lbpm').textContent+')');
  ok(bw.document.querySelectorAll('#lbeats i.on').length===1,'one beat lit');
  ok(/USB Audio CODEC/.test(bw.document.getElementById('inp').textContent) && /worklet/.test(bw.document.getElementById('inp').textContent),'input line: mic + engine');
  // 4) Live tab: hidden + worklet is not an error
  const feed=setInterval(()=>WN.port.onmessage({data:{lv:[0.2,0.01,0.01,0.001]}}),16); await sleep(1300);
  const lw=new JSDOM(await (await fetch(B+'/lab')).text(),{runScripts:'outside-only',url:B+'/lab'}).window; lw.fetch=(u,o)=>fetch(B+u,o);
  lw.eval([...lw.document.querySelectorAll('script')].map(x=>x.textContent).join('\n')); await sleep(700);
  const det=[...lw.document.querySelectorAll('#pimon .mrow')].find(r=>/Detector/.test(r.textContent));
  ok(det && /worklet/.test(det.textContent) && !det.classList.contains('m-bad'),'Live: hidden + worklet not flagged ('+(det&&det.className+' | '+det.textContent)+')');
  clearInterval(feed); bw.close(); lw.close(); done();
})().catch(e=>{ console.log('ERR',e.stack); p.kill(); process.exit(2); });
