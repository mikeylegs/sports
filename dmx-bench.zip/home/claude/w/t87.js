// 28o: PAR brightness slider (5-100 %, live while dragging) + 10/25/50/100 presets
const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2]; const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx')); fs.copyFileSync(FILE,path.join(d,'artnet-controller.js'));
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'}); const B='http://127.0.0.1:8080'; let n=0,f=0; const ok=(c,m)=>{n++; if(!c){f++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const cfg=async()=>(await (await fetch(B+'/liveshow')).json()).parMax;
(async()=>{ await sleep(900); const {JSDOM}=require('jsdom');
  const v=new JSDOM(await (await fetch(B+'/cc')).text(),{runScripts:'outside-only',url:B+'/cc'}).window; v.fetch=(u,o)=>fetch(B+u,o); v.eval(v.document.querySelector('script:not([data-nl])').textContent);
  const $=id=>v.document.getElementById(id); await sleep(800);
  ok($('pmS') && $('pmS').min==='5' && $('pmS').max==='100' && $('pmV').textContent==='100%','slider 5-100 %, showing 100%');
  for(const x of [80,60,40,20]){ $('pmS').value=String(x); $('pmS').dispatchEvent(new v.Event('input')); await sleep(60); }
  await sleep(300); ok(await cfg()<=40,'dragging sends as you go ('+(await cfg())+'% mid-drag)');
  $('pmS').value='15'; $('pmS').dispatchEvent(new v.Event('change')); await sleep(400); ok(await cfg()===15 && $('pmV').textContent==='15%','release: 15% stored');
  v.document.querySelector('[data-pm="10"]').dispatchEvent(new v.Event('click',{bubbles:true})); await sleep(700); ok(await cfg()===10 && $('pmS').value==='10','preset 10% (slider follows)');
  const r=await fetch(B+'/liveshow',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({parMax:5})}); ok(r.status===200 && await cfg()===5,'5% allowed');
  await fetch(B+'/liveshow',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({parMax:2})}); ok(await cfg()===5,'below 5% ignored');
  v.close(); console.log(`${n-f}/${n} passed`); p.kill(); process.exit(f?1:0); })().catch(e=>{ console.log('ERR',e.stack); p.kill(); process.exit(2); });
