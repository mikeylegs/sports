const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2], SRC=fs.readFileSync(FILE,'utf8'); const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx'));
fs.copyFileSync(FILE,path.join(d,'artnet-controller.js')); fs.mkdirSync(path.join(d,'logs'));
let fails=0,n=0; const ok=(c,m)=>{n++; if(!c){fails++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const TDJ=(SRC.match(/const TRACK_DETECT_JS = `([\s\S]*?)`;/)||[])[1]; const g={}; new Function('G',TDJ+';G.a=tdAnalyze;')(g);
// 128 BPM: groove 0-31, break 32-47 (riser), DROP 48-79, break 80-91, 1-bar fake kick 92, out 93-95, DROP 96-111
const sr=44100, BL=60/128, bars=112, N=Math.ceil(bars*4*BL*sr)+sr, a=new Float32Array(N); let seed=3; const rnd=()=>((seed=(seed*16807)%2147483647)/2147483647)*2-1;
const kickOn=bar=>(bar<32)||(bar>=48&&bar<80)||bar===92||bar>=96;
for(let i=0;i<N;i++) a[i]=rnd()*0.004;
for(let b=0;b<bars*4;b++){ const bar=Math.floor(b/4), s0=Math.floor(b*BL*sr);
  if(kickOn(bar)) for(let j=0;j<sr*0.15&&s0+j<N;j++) a[s0+j]+=0.8*Math.sin(2*Math.PI*60*j/sr)*Math.exp(-j/sr/0.05);
  if(b%2===1) for(let j=0;j<sr*0.04&&s0+j<N;j++) a[s0+j]+=0.3*Math.sin(2*Math.PI*2000*j/sr)*Math.exp(-j/sr/0.015);
  const h=Math.floor((b+0.5)*BL*sr); for(let j=0;j<sr*0.03&&h+j<N;j++) a[h+j]+=0.15*Math.sin(2*Math.PI*8000*j/sr+rnd())*Math.exp(-j/sr/0.008);
  if((bar>=40&&bar<48)||(bar>=88&&bar<92)) for(let j=0;j<BL*sr&&s0+j<N;j++) a[s0+j]+=rnd()*0.05*((bar%8)+1)/8; }   // risers
(async()=>{
  const cfg={bands:[{lo:40,hi:120,sens:1.5},{lo:1000,hi:4000,sens:1.05},{lo:6000,hi:12000,sens:1.3},{lo:12000,hi:16000,sens:1.3}]};
  const out=await new Promise(r=>g.a([a],sr,cfg.bands,()=>{},r));
  const ev=[{k:'start',src:'bridge',t:0}].concat(out.ft.map((t,i)=>({k:'f',e:out.frames.map(f=>f[i]),t})),out.hits).sort((x,y)=>x.t-y.t);
  const ms=bar=>Math.round(bar*4*BL*1000);
  fs.writeFileSync(path.join(d,'logs','bridge-20260926-100000.ndjson'),ev.concat([{k:'m',label:'drop',t:ms(48),post:true},{k:'m',label:'drop',t:ms(96),post:true},{k:'m',label:'drop',t:ms(20),post:true}]).map(e=>JSON.stringify(e)).join('\n')+'\n');
  const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'}); await sleep(800); const B='http://127.0.0.1:8080';
  const {JSDOM}=require('jsdom'); const html=await (await fetch(B+'/logs/bridge-20260926-100000.ndjson')).text();
  const v=new JSDOM(html,{runScripts:'outside-only',url:B+'/logs/x'}).window;
  v.HTMLCanvasElement.prototype.getContext=()=>new Proxy({},{get:(t,k)=>k==='measureText'?()=>({width:0}):(k in t?t[k]:()=>{}),set:(t,k,x)=>{t[k]=x;return true;}});
  v.fetch=(u,o)=>fetch(B+u,o);
  v.eval([...v.document.querySelectorAll('script')].map(x=>x.textContent).join('\n'));
  for(let i=0;i<50 && !v.eval('TL');i++) await sleep(100);
  ok(v.eval('!!(TL&&TL.sec)'),'full-file phrase view present');
  const sel=v.document.getElementById('engsel'); ok(!!sel && sel.value==='v1','engine toggle, default v1');
  if(!sel){ console.log(`${n-fails}/${n} passed`); p.kill(); process.exit(1); }
  const v1=v.eval('JSON.stringify({d:TL.sec.drops, f:TL.sec.fakes, bars:TL.sec.bars.map(function(b){return [b.t,b.pb];})})'), V1=JSON.parse(v1);
  const pbAt=(bars,t)=>{ const b=bars.find(x=>Math.abs(x[0]-t)<1); return b?b[1]:null; };
  ok(V1.d.length===2 && V1.d.every(t=>pbAt(V1.bars,t)===1),'v1 on the synthetic: both drops on phrase starts now that the grid is right ('+V1.d.map(t=>pbAt(V1.bars,t)).join(',')+')');
  sel.value='v2'; sel.dispatchEvent(new v.Event('change')); await sleep(300);
  const V2=JSON.parse(v.eval('JSON.stringify({e:TL.sec.engine, d:TL.sec.drops, b:TL.sec.builds, bars:TL.sec.bars.map(function(b){return [b.t,b.pb,b.st];}), s:TL.sec.summary})'));
  ok(V2.e==='v2' && /phrase-first/.test(V2.s),'v2 active after toggle');
  ok(v.localStorage.getItem('artnetEngine')==='v2','choice remembered');
  ok(V2.d.length===2 && V2.d.every(t=>{ const p=pbAt(V2.bars,t); return p===1||p===5; }),'v2: 2 drops, each on a phrase (or half-phrase) start ('+V2.d.map(t=>pbAt(V2.bars,t)).join(',')+')');
  ok(!V2.d.some(t=>Math.abs(t-ms(92))<ms(3)),'v2: the 1-bar fake @92 is not a drop');
  ok(V2.d.every(t=>V1.d.some(u=>Math.abs(u-t)<=ms(1)+50)),'v2 drops sit within a bar of v1 drops (v1 '+V1.d.map(x=>(x/ms(1)).toFixed(2))+' v2 '+V2.d.map(x=>(x/ms(1)).toFixed(2))+')');
  { const byPhrase={}; V2.bars.forEach(b=>{ }); let same=true, cur=null, st=null; V2.bars.forEach(b=>{ if(b[1]===1||b[1]===5){ st=b[2]; } else if(st!==null && b[2]!==st) same=false; }); ok(same,'one colour per phrase/half'); }
  ok(/Vs your marks:<\/b> drops 2\/3/.test(V2.s),'v2 scored vs marks ('+(V2.s.match(/drops \d\/\d/)||[''])[0]+')');
  v.document.getElementById('czbtn').click(); for(let i=0;i<600 && !v.eval('TL.cz');i++) await sleep(100);
  const z=v.eval('TL.cz'); ok(!!z && /Causal replay/.test(v.document.getElementById('czout').innerHTML),'causal replay runs on v2');
  console.log('   v2 causal:',JSON.stringify(z.marks.map(x=>({lat:x.lat,pred:x.pred}))),'false calls',z.calls.filter(c=>c.fresh&&!c.marked).length);
  console.log(`${n-fails}/${n} passed`); p.kill(); process.exit(fails?1:0);
})().catch(e=>{console.log('ERR',e.stack); process.exit(2);});
