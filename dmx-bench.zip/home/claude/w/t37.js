const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2]; const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx'));
fs.copyFileSync(FILE,path.join(d,'artnet-controller.js')); fs.mkdirSync(path.join(d,'logs'));
fs.copyFileSync('/mnt/user-data/uploads/track-52285985-558042.ndjson',path.join(d,'logs','track-52285985-558042.ndjson'));
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'});
const B='http://127.0.0.1:8080'; let fails=0,n=0; const ok=(c,m)=>{n++; if(!c){fails++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{ await sleep(800); const {JSDOM}=require('jsdom');
  const v=new JSDOM(await (await fetch(B+'/logs/track-52285985-558042.ndjson')).text(),{runScripts:'outside-only',url:B+'/logs/x'}).window;
  v.HTMLCanvasElement.prototype.getContext=()=>new Proxy({},{get:(t,k)=>k==='measureText'?()=>({width:0}):(k in t?t[k]:()=>{}),set:(t,k,x)=>{t[k]=x;return true;}});
  v.fetch=(u,o)=>fetch(B+u,o); v.requestAnimationFrame=()=>0; v.localStorage.setItem('artnetRigMode2','full'); v.eval([...v.document.querySelectorAll('script')].map(x=>x.textContent).join('\n'));
  for(let i=0;i<50 && !v.eval('TL');i++) await sleep(100);
  const R=JSON.parse(v.eval('JSON.stringify({laz:TL.rig.laz, bars:TL.rig.bars, hits:TL.rig.hits})'));
  ok(R.laz && R.laz.length>20,'stabs planned ('+(R.laz||[]).length+')'); if(!R.laz){ console.log(`${n-fails}/${n} passed`); p.kill(); process.exit(1); }
  const grooveBars=R.bars.filter(b=>b.look==='groove'), grooveMs=grooveBars.reduce((a,b)=>a+(b.t1-b.t),0);
  const inGroove=R.laz.filter(s=>grooveBars.some(b=>s.t>=b.t&&s.t<b.t1)), onMs=inGroove.reduce((a,s)=>a+s.dur,0);
  console.log('   groove on-time',Math.round(onMs/grooveMs*100)+'%', 'stabs',R.laz.length); ok(onMs/grooveMs<0.25,'groove: laser on only '+Math.round(onMs/grooveMs*100)+'% of the time (was always on)');
  const st=t=>JSON.parse(v.eval('JSON.stringify(rigState('+t+'))'));
  const gb=grooveBars[Math.floor(grooveBars.length/2)], mid=gb.t+(gb.t1-gb.t)*0.125+200; const between=R.laz.find(s=>s.t>gb.t && s.t<gb.t1);
  ok(st(between?between.t+between.dur+30:mid).laser===0,'groove between stabs: laser off');
  ok(between && st(between.t+20).laser===1 && st(between.t+20).stab,'during a stab: laser on, as a stab');
  const drop=R.hits.find(h=>h.ok); const ds=R.laz.filter(s=>s.t>=drop.t-1 && s.t<drop.t+2000 && s.wide); ok(ds.length>=4,'drop: a wide stab on every beat of the first bar ('+ds.length+')');
  const br=R.bars.find(b=>b.look==='break'); ok(br && st(br.t+300).laser>0 && !st(br.t+300).stab,'break: dim scan kept');
  // stage view draws a stab (static fan) and nothing between stabs in a groove
  v.document.body.insertAdjacentHTML('beforeend','<canvas id="stLaserT"></canvas>'); 
  const n1=v.eval('stageLaser(rigState('+(between.t+20)+'),'+(between.t+20)+')'), n0=v.eval('stageLaser(rigState('+(between.t+between.dur+30)+'),'+(between.t+between.dur+30)+')');
  ok(n1>0 && n0===0,'stage view: fan on the stab ('+n1+' beams), dark between');
  v.close(); console.log(`${n-fails}/${n} passed`); p.kill(); process.exit(fails?1:0);
})().catch(e=>{ console.log('ERR',e.stack); p.kill(); process.exit(2); });
