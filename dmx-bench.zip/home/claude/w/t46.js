// fog button: one resting spot on every page = Performance's, and never visible before it's placed
const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2]; const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx'));
fs.copyFileSync(FILE,path.join(d,'artnet-controller.js')); fs.mkdirSync(path.join(d,'logs'));
fs.copyFileSync('/mnt/user-data/uploads/track-52285985-558042.ndjson',path.join(d,'logs','track-52285985-558042.ndjson'));
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'});
const B='http://127.0.0.1:8080'; let fails=0,n=0; const ok=(c,m)=>{n++; if(!c){fails++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{ await sleep(800); const {JSDOM}=require('jsdom'); let shared=null;
  async function open(u,store,vhEarly){ const w=new JSDOM(await (await fetch(B+u)).text(),{runScripts:'outside-only',url:B+'/',pretendToBeVisual:true}).window;
    Object.defineProperty(w,'innerWidth',{value:390,configurable:true}); Object.defineProperty(w,'innerHeight',{value:vhEarly||844,configurable:true,writable:true});
    Object.defineProperty(w.HTMLElement.prototype,'offsetHeight',{configurable:true,get(){ return this.id==='mtrig'?76:0; }}); Object.defineProperty(w.HTMLElement.prototype,'offsetWidth',{configurable:true,get(){ return this.id==='mtrig'?76:0; }});
    if(store) Object.entries(store).forEach(([k,v])=>w.localStorage.setItem(k,v));
    w.HTMLCanvasElement.prototype.getContext=()=>new Proxy({},{get:(t,k)=>k==='measureText'?()=>({width:0}):(k in t?t[k]:()=>{}),set:(t,k,x)=>{t[k]=x;return true;}});
    w.fetch=(url,o)=>fetch(B+url,o); w.requestAnimationFrame=f=>setTimeout(()=>f(0),5); if(!w.PointerEvent) w.PointerEvent=w.MouseEvent;
    if(u==='/perform'){ const qsa=w.document.querySelectorAll.bind(w.document); w.document.querySelectorAll=function(sel){ if(sel==='#grid .pad:not(.kill)') return [0,1,2,3,4,5,6,7].map(i=>({getBoundingClientRect:()=>({top:i<4?200:360,bottom:i<4?300:460})})); return qsa(sel); }; }   // 2 rows of scene pads (this test server has no scenes)
    const html=w.document.documentElement.outerHTML; ok(/\.mtrig:not\(\.placed\)\{visibility:hidden\}/.test(html),u+': hidden until placed (no jump on load)');
    [...w.document.querySelectorAll('script')].forEach(s=>{ try{ w.eval(s.textContent); }catch(e){} });
    const early=parseFloat(w.document.getElementById('mtrig').style.top), placedEarly=w.document.getElementById('mtrig').classList.contains('placed');
    if(vhEarly) Object.defineProperty(w,'innerHeight',{value:844,configurable:true});   // the viewport settles after parsing
    await sleep(250);
    const b=w.document.getElementById('mtrig'); return {w,b,early,placedEarly,top:parseFloat(b.style.top), left:parseFloat(b.style.left), placed:b.classList.contains('placed')}; }
  const P=await open('/perform'); shared=P.w.localStorage.getItem('artnetFogDockFrac');
  ok(P.placed && Math.abs(P.top-(330-38))<1 && P.left===390-22,'Performance: docked right between pad rows 1 and 2 (top '+P.top+'), placed');
  ok(shared && Math.abs(+shared-292/768)<0.001,'Performance remembers its spot ('+shared+')'); P.w.close();
  for(const u of ['/','/lab','/lab/show','/logs/track-52285985-558042.ndjson','/react']){ const r=await open(u,{artnetFogDockFrac:shared});
    ok(r.placed && Math.abs(r.top-P.top)<1 && r.left===P.left, u+': exactly the Performance spot (top '+r.top+', left '+r.left+')'); r.w.close(); }
  for(const u of ['/','/react']){ const r=await open(u,{artnetFogDockFrac:shared},700);
    ok(!r.placedEarly && r.placed && Math.abs(r.top-P.top)<1,u+': viewport still settling while parsing (700 -> 844): re-placed after load at the Performance spot (early '+r.early+' -> '+r.top+'), hidden until then'); r.w.close(); }
  const F=await open('/lab'); ok(Math.abs(F.top-(844-76)/2)<1,'no Performance visit yet: centred ('+F.top+')'); F.w.close();
  console.log(`${n-fails}/${n} passed`); p.kill(); process.exit(fails?1:0);
})().catch(e=>{ console.log('ERR',e.stack); p.kill(); process.exit(2); });
