// 28m: PI BRIDGE off -> idle at once; network meter (Pi round trip + level-stream gaps) in the PI sheet
const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os'), dgram=require('dgram');
const FILE=process.argv[2]; const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx')); fs.copyFileSync(FILE,path.join(d,'artnet-controller.js'));
fs.writeFileSync(path.join(d,'settings.json'),JSON.stringify({targetIP:'127.0.0.2'}));
let last=null; const sock=dgram.createSocket({type:'udp4',reuseAddr:true}); sock.on('message',m=>{ if(m.length>=530 && m.toString('latin1',0,7)==='Art-Net' && m.readUInt16LE(14)===0) last=Buffer.from(m.subarray(18)); }); sock.bind(6454,'127.0.0.2');
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'}); const B='http://127.0.0.1:8080'; let n=0,f=0; const ok=(c,m)=>{n++; if(!c){f++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const post=(u,b)=>fetch(B+u,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)}); const ch=c=>last?last[c-1]:-1;
const snap={levels:[0.4,0,0,0],active:[true,false,false,false],hits:[1,0,0,0],recording:true,build:'x',net:{p50:11.2,p95:38.4,max:171},live:{beatMs:480,nextBeatIn:100,pb:3,groove:true,mode:'heavy',slvl:1,kickOn:true,hatsOn:false,washIdx:2,washNextIn:9000,bpm:125}};
(async()=>{ await sleep(900); await post('/liveshow',{enabled:true,idleGlow:'off'});
  for(let i=0;i<60;i++){ await post('/lv',{k:0.5}); if(i%6===0) await post('/bridgestate',snap); await sleep(i===40?320:30); }
  ok(ch(88)>100,'music: PAR pumping');
  const s=await (await fetch(B+'/ccstate')).json(); ok(s.net && s.net.rtt && s.net.rtt.p50===11 && s.net.gapMax>=300 && s.net.late>=1,'network meter: Pi round trip '+JSON.stringify(s.net&&s.net.rtt)+', stream gaps p95 '+(s.net&&s.net.gapP95)+' ms, longest '+(s.net&&s.net.gapMax)+' ms');
  const T=Date.now(); await post('/bridgectl',{want:false}); let dark=null; while(Date.now()-T<2000){ if(ch(88)===0){ dark=Date.now()-T; break; } await post('/lv',{k:0.5}); await sleep(20); }
  ok(dark!==null && dark<=250,'PI BRIDGE off: PARs dark in '+(dark==null?'>2000':dark)+' ms, even with a straggling level post');
  await post('/bridgectl',{want:true}); for(let i=0;i<20;i++){ await post('/lv',{k:0.5}); if(i%5===0) await post('/bridgestate',snap); await sleep(30); } await sleep(1200); for(let i=0;i<10;i++){ await post('/lv',{k:0.5}); await sleep(30); }
  ok(ch(88)>100,'back on: the show picks up again');
  const html=await (await fetch(B+'/cc')).text(); ok(/Level stream gaps/.test(html) && /Round trip Pi/.test(html),'PI sheet shows the network meter');
  await post('/liveshow',{enabled:false}); console.log(`${n-f}/${n} passed`); p.kill(); sock.close(); process.exit(f?1:0); })().catch(e=>{ console.log('ERR',e.stack); p.kill(); process.exit(2); });
