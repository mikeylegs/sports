const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2], TR=['track-15337193-247718','track-39307571-582210','track-37199921-932496','track-52285985-558042','track-65570060-568769','track-15250173-827976'];
const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx')); fs.copyFileSync(FILE,path.join(d,'artnet-controller.js')); fs.mkdirSync(path.join(d,'logs'));
TR.forEach(t=>fs.copyFileSync('/mnt/user-data/uploads/'+t+'.ndjson',path.join(d,'logs',t+'.ndjson')));
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'}); const B='http://127.0.0.1:8080'; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{ await sleep(800); const {JSDOM}=require('jsdom');
  for(const t of TR){ const v=new JSDOM(await (await fetch(B+'/logs/'+t+'.ndjson')).text(),{runScripts:'outside-only',url:B+'/logs/x'}).window;
    v.HTMLCanvasElement.prototype.getContext=()=>new Proxy({},{get:(t,k)=>k==='measureText'?()=>({width:0}):(k in t?t[k]:()=>{}),set:(t,k,x)=>{t[k]=x;return true;}});
    v.fetch=(u,o)=>fetch(B+u,o); v.requestAnimationFrame=()=>0; v.eval([...v.document.querySelectorAll('script')].map(x=>x.textContent).join('\n'));
    for(let i=0;i<50 && !v.eval('TL');i++) await sleep(100); v.eval('ensureLivePlan()'); for(let i=0;i<900 && !v.eval('!!TL.rigLive');i++) await sleep(100);
    const P=JSON.parse(v.eval('JSON.stringify(TL.rigLive)')), drops=JSON.parse(v.eval('JSON.stringify(TL.sec.drops)'));
    const bl=(P.blk||[]).map(b=>b[0]); console.log('   rise/bars at breaths:',(P.blk||[]).map(b=>(b[0]/1000).toFixed(0)+':'+b[2]+'/'+b[3]).join(' ')), real=bl.filter(b=>drops.some(dd=>Math.abs(dd-b)<2500)), fake=bl.filter(b=>!drops.some(dd=>Math.abs(dd-b)<2500));
    console.log(t.slice(6,14),'breaths',bl.length,'before a real drop',real.length,'false',fake.length,':',fake.map(x=>(x/1000).toFixed(0)).join(','));
    v.close(); }
  p.kill(); process.exit(0); })();
