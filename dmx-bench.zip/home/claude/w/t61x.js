// 27l on Dare's REAL audio (re-analyzed here): kicks detected, grid tempo, and the live-preview strobe vs the kicks read
// from the waveform -- with and without the Known BPM (Link simulator)
const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2], TRK=process.argv[3]; const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx')); fs.copyFileSync(FILE,path.join(d,'artnet-controller.js')); fs.mkdirSync(path.join(d,'logs'));
fs.copyFileSync(TRK,path.join(d,'logs','track-80355717-523518.ndjson'));
const K=JSON.parse(fs.readFileSync('/tmp/dareKick.json','utf8')).map(x=>x*1000);   // 27n: TRUE kicks, from Dare's separated drum stem (MDX-Net) -- the earlier reference was the off-beat bass
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'}); const B='http://127.0.0.1:8080'; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
let n=0,f=0; const ok=(c,m)=>{n++; if(!c){f++; console.log('FAIL',m);} }; const res={};
(async()=>{ await sleep(800); const {JSDOM}=require('jsdom');
  for(const bpm of [0,134.03]){
    const v=new JSDOM(await (await fetch(B+'/logs/track-80355717-523518.ndjson')).text(),{runScripts:'outside-only',url:B+'/logs/x'}).window;
    v.HTMLCanvasElement.prototype.getContext=()=>new Proxy({},{get:(t,k)=>k==='measureText'?()=>({width:0}):(k in t?t[k]:()=>{}),set:(t,k,x)=>{t[k]=x;return true;}});
    if(bpm) v.localStorage.setItem('artnetBpm:track-80355717-523518.ndjson',String(bpm));
    v.fetch=(u,o)=>fetch(B+u,o); v.requestAnimationFrame=()=>0; v.eval([...v.document.querySelectorAll('script')].map(x=>x.textContent).join('\n'));
    for(let i=0;i<50 && !v.eval('TL');i++) await sleep(100); v.eval('ensureLivePlan()'); for(let i=0;i<900 && !v.eval('!!TL.rigLive');i++) await sleep(100);
    const TLc=JSON.parse(v.eval("JSON.stringify(TL.ev.filter(function(e){return e.k==='h'&&e.b===2;}).map(function(e){return e.t;}))"));
    const S=JSON.parse(v.eval('JSON.stringify({bpm:TL.sec.bpm,src:TL.sec.src,lock:TL.sec.lockMs})')), P=JSON.parse(v.eval('JSON.stringify(TL.rigLive)'));
    const near=(arr,x,w)=>arr.some(y=>Math.abs(y-x)<=w);
    const grooveK=K;   // every true kick
    const cov=grooveK.filter(k=>near(P.strobe,k,80)).length, fl=P.strobe.filter(t=>!(P.boom||[]).some(b=>t>=b-10&&t<=b+300)), onK=fl.filter(t=>near(K,t,80)).length;
    res[bpm]={cov:cov/grooveK.length, prec:onK/fl.length};
    const miss=fl.filter(t=>!near(K,t,80)), seg={}; miss.forEach(t=>{ const s=Math.floor(t/20000)*20; seg[s]=(seg[s]||0)+1; });
    console.log('     flashes not on a kick, per 20 s:',JSON.stringify(seg), '| of them within 80 ms of a band-2 (clap/snare) hit:', miss.filter(t=>TLc.some(c=>Math.abs(c-t)<=80)).length);
    console.log('   '+(bpm?'Known BPM '+bpm:'kick-tracked')+': grid '+S.bpm+' BPM ('+S.src+(S.lock!=null?', lock '+Math.round(S.lock)+' ms':'')+') · true kicks with a flash '+cov+'/'+grooveK.length+' · flashes on a kick '+onK+'/'+fl.length);
    v.close(); }
  ok(res[134.03].prec>=0.7,'known BPM: >= 70% of flashes on a real kick ('+Math.round(res[134.03].prec*100)+'%)');
  ok(res[134.03].cov>=0.55,'known BPM: >= 55% of the real kicks get a flash ('+Math.round(res[134.03].cov*100)+'%)');
  ok(res[0].cov>=0.3,'no BPM: the new detector alone still covers >= 30% ('+Math.round(res[0].cov*100)+'%)');
  console.log(`${n-f}/${n} passed`); p.kill(); process.exit(f?1:0); })().catch(e=>{ console.log('ERR',e.stack); p.kill(); process.exit(2); });
