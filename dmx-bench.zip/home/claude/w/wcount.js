const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx')); fs.copyFileSync(process.argv[2],path.join(d,'artnet-controller.js')); fs.mkdirSync(path.join(d,'logs'));
const trk=process.argv.slice(3); trk.forEach((f,i)=>fs.copyFileSync(f,path.join(d,'logs','track-9000000'+i+'-000001.ndjson')));
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'}); const B='http://127.0.0.1:8080'; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{ await sleep(800); const {JSDOM}=require('jsdom');
 for(let i=0;i<trk.length;i++){ const nm='track-9000000'+i+'-000001.ndjson';
  const v=new JSDOM(await (await fetch(B+'/logs/'+nm)).text(),{runScripts:'outside-only',url:B+'/logs/x'}).window;
  v.HTMLCanvasElement.prototype.getContext=()=>new Proxy({},{get:(t,k)=>k==='measureText'?()=>({width:0}):(k in t?t[k]:()=>{}),set:(t,k,x)=>{t[k]=x;return true;}});
  v.fetch=(u,o)=>fetch(B+u,o); v.requestAnimationFrame=()=>0; v.eval([...v.document.querySelectorAll('script')].map(x=>x.textContent).join('\n'));
  for(let j=0;j<50 && !v.eval('TL');j++) await sleep(100); v.eval('ensureLivePlan()'); for(let j=0;j<900 && !v.eval('!!TL.rigLive');j++) await sleep(100);
  const P=JSON.parse(v.eval('JSON.stringify({cols:TL.rigLive.cols,bpm:TL.sec.bpm,dur:TL.dur})'));
  const gaps=P.cols.slice(1).map((c,k)=>((c[0]-P.cols[k][0])/1000).toFixed(1));
  if(process.env.DBG2) console.log('   CUEL',v.eval('JSON.stringify((window.CUEL||[]).filter(function(x){ return x[1]>58000 && x[1]<64000; }))')); if(process.env.DBG) console.log('   cols',JSON.stringify(P.cols.map(c=>[+(c[0]/1000).toFixed(1),c[1],Math.round(c[2])])));
  console.log(path.basename(trk[i]).slice(0,22),'bpm',P.bpm,'dur',(P.dur/1000|0)+'s','colour changes',P.cols.length,'| gaps (s):',gaps.join(' '),'| 8 bars =',(8*4*60/P.bpm).toFixed(1)+'s');
  v.close(); }
 p.kill(); process.exit(0); })();
