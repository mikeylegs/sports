// 28b: idle glow OFF / DIM / WARM (what the PARs do with no music), checked on the wire
const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os'), dgram=require('dgram');
const FILE=process.argv[2]; const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx')); fs.copyFileSync(FILE,path.join(d,'artnet-controller.js'));
fs.writeFileSync(path.join(d,'settings.json'),JSON.stringify({targetIP:'127.0.0.2'}));
let last=null; const sock=dgram.createSocket({type:'udp4',reuseAddr:true}); sock.on('message',m=>{ if(m.length>=530 && m.toString('latin1',0,7)==='Art-Net' && m.readUInt16LE(14)===0) last=Buffer.from(m.subarray(18)); }); sock.bind(6454,'127.0.0.2');
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore',env:Object.assign({},process.env,{DMX_IDLE_MS:'1500'})}); const B='http://127.0.0.1:8080'; let n=0,f=0; const ok=(c,m)=>{n++; if(!c){f++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const post=(u,b)=>fetch(B+u,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)}); const ch=c=>last?last[c-1]:-1;
(async()=>{ await sleep(900);
  let c=await (await fetch(B+'/liveshow')).json(); ok(c.idleGlow==='off','default idle glow: OFF');
  await post('/dmx',{bulk:[[0,88,200],[0,95,200]]}); await post('/liveshow',{enabled:true}); await sleep(3500);
  let s=await (await fetch(B+'/ccstate')).json(); ok(s.show.idle===true && ch(88)===0 && ch(95)===0,'no music, OFF: PARs fully dark (dims '+ch(88)+'/'+ch(95)+')');
  await post('/liveshow',{idleGlow:'warm'}); await sleep(600); ok(ch(88)===60 && ch(82)===255 && ch(83)===110,'WARM: amber glow at 60, straight away');
  await post('/liveshow',{idleGlow:'dim'}); await sleep(600); ok(ch(88)===25 && ch(95)===25,'DIM: 25');
  await post('/liveshow',{idleGlow:'off'}); await sleep(600); ok(ch(88)===0,'back to OFF');
  const html=await (await fetch(B+'/cc')).text(); ok((html.match(/data-ig="/g)||[]).length===3,'Command Center Setup: OFF / DIM / WARM');
  await post('/liveshow',{enabled:false}); console.log(`${n-f}/${n} passed`); p.kill(); sock.close(); process.exit(f?1:0); })().catch(e=>{ console.log('ERR',e.stack); p.kill(); process.exit(2); });
