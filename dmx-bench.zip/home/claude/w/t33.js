const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2]; const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx'));
fs.copyFileSync(FILE,path.join(d,'artnet-controller.js')); fs.mkdirSync(path.join(d,'logs'));
fs.copyFileSync('/mnt/user-data/uploads/track-52285985-558042.ndjson',path.join(d,'logs','track-52285985-558042.ndjson'));
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'});
const B='http://127.0.0.1:8080'; let fails=0,n=0; const ok=(c,m)=>{n++; if(!c){fails++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{ await sleep(800); const {JSDOM}=require('jsdom');
  const html=await (await fetch(B+'/logs/track-52285985-558042.ndjson')).text();
  ok(/maximum-scale=1,user-scalable=no/.test(html) && /touch-action:pan-x pan-y" id="tlscroll"/.test(html),'viewer: page pinch-zoom off, timeline takes pinches');
  const v=new JSDOM(html,{runScripts:'outside-only',url:B+'/logs/x'}).window;
  v.HTMLCanvasElement.prototype.getContext=()=>new Proxy({},{get:(t,k)=>k==='measureText'?()=>({width:0}):(k in t?t[k]:()=>{}),set:(t,k,x)=>{t[k]=x;return true;}});
  v.fetch=(u,o)=>fetch(B+u,o); v.requestAnimationFrame=f=>{ f(0); return 1; }; v.eval([...v.document.querySelectorAll('script')].map(x=>x.textContent).join('\n'));
  for(let i=0;i<50 && !v.eval('TL');i++) await sleep(100);
  const sc=v.document.getElementById('tlscroll'), W0=v.eval('TL.W');
  const touch=(type,xs)=>{ const e=new v.Event(type,{cancelable:true,bubbles:true}); Object.defineProperty(e,'touches',{value:xs.map(x=>({clientX:x,clientY:100}))}); sc.dispatchEvent(e); return e; };
  const ge=new v.Event('gesturestart',{cancelable:true}); v.document.dispatchEvent(ge); ok(ge.defaultPrevented,'iOS page-zoom gesture blocked');
  const s=touch('touchstart',[120,220]); ok(s.defaultPrevented,'two-finger touch on the timeline is ours');
  const m=touch('touchmove',[70,270]); touch('touchend',[]);   // fingers 100 -> 200 px apart: 2x zoom
  const W1=v.eval('TL.W'); ok(Math.abs(W1/W0-2)<0.05 && m.defaultPrevented,'pinch out 2x -> timeline twice as wide ('+W0+' -> '+W1+')');
  const tc=171.4*170/340; const tAfter=(sc.scrollLeft+170)/W1*171.4; ok(Math.abs(tAfter-tc)<1.5,'the moment under the fingers stays put ('+tc.toFixed(1)+' s vs '+tAfter.toFixed(1)+' s)');
  ok(v.document.getElementById('zoom').value==='c' && /≈\d+ (s|min)/.test(v.document.getElementById('zoomc').textContent),'Zoom picker shows the pinched span ('+v.document.getElementById('zoomc').textContent+')');
  touch('touchstart',[100,300]); touch('touchmove',[190,210]); touch('touchend',[]);   // pinch in hard -> back to fit
  ok(v.eval('TL.W')===W0 && /Fit/.test(v.document.getElementById('zoomc').textContent),'pinch in -> Fit');
  const z=v.document.getElementById('zoom'); z.value='20'; z.dispatchEvent(new v.Event('change')); ok(v.eval('ZC')===null && v.eval('TL.W')>W0*5,'picker still works after a pinch');
  // 26z: deep zoom on a 10-minute file: canvas stays screen-sized, work stays bounded
  v.close(); { const L=fs.readFileSync('/mnt/user-data/uploads/track-14276734-704099.ndjson'); fs.writeFileSync(path.join(d,'logs','track-14276734-704099.ndjson'),L); }
  const w=new JSDOM(await (await fetch(B+'/logs/track-14276734-704099.ndjson')).text(),{runScripts:'outside-only',url:B+'/logs/x'}).window; let rects=0;
  w.HTMLCanvasElement.prototype.getContext=()=>new Proxy({},{get:(t,k)=>k==='measureText'?()=>({width:0}):k==='fillRect'?()=>{rects++;}:(k in t?t[k]:()=>{}),set:(t,k,x)=>{t[k]=x;return true;}});
  w.fetch=(u,o)=>fetch(B+u,o); w.requestAnimationFrame=f=>{ f(0); return 1; }; w.eval([...w.document.querySelectorAll('script')].map(x=>x.textContent).join('\n'));
  for(let i=0;i<50 && !w.eval('TL');i++) await sleep(100);
  const sc2=w.document.getElementById('tlscroll'), cv=w.document.getElementById('tl');
  const t2=(type,xs)=>{ const e=new w.Event(type,{cancelable:true,bubbles:true}); Object.defineProperty(e,'touches',{value:xs.map(x=>({clientX:x,clientY:100}))}); sc2.dispatchEvent(e); };
  t2('touchstart',[160,180]); rects=0; const t0=Date.now(); for(let k=1;k<=100;k++) t2('touchmove',[160-k*8,180+k*8]); const dt=(Date.now()-t0)/100; t2('touchend',[]);
  const W=w.eval('TL.W'); console.log('   max zoom: W',W,'| canvas css width',cv.style.width,'| draw',dt.toFixed(1),'ms/step (JS only) | fillRects per step',Math.round(rects/100));
  ok(W>16000 && cv.style.width==='340px' && w.document.getElementById('tlspace').style.width===W+'px','zoomed past the old 16000 px cap; canvas stays screen-sized, spacer carries the width');
  ok(Math.abs(w.eval('ZC')-8)<0.5,'pinch reaches the 8 s floor without resetting ('+w.eval('ZC').toFixed(1)+' s)');
  ok(rects/100<20000,'work per step bounded to the visible slice');
  { let texts=[]; w.HTMLCanvasElement.prototype.getContext=()=>new Proxy({},{get:(t,k)=>k==='measureText'?()=>({width:0}):k==='fillText'?(s,x,y)=>texts.push([s,x]):(k in t?t[k]:()=>{}),set:(t,k,x)=>{t[k]=x;return true;}});
    w.eval('draw()'); const nums=texts.filter(x=>/^[1-8]$/.test(x[0])); ok(nums.length>=2 && nums.every(x=>x[1]>=w.eval('VX0')-50 && x[1]<=w.eval('VX1')+50),'deep zoom: bar numbers (1-8 in the phrase) drawn in view ('+nums.map(x=>x[0]).join(',')+')');
    texts=[]; const zs=w.document.getElementById('zoom'); zs.value='0'; zs.dispatchEvent(new w.Event('change')); ok(!texts.some(x=>/^[1-8]$/.test(x[0])),'Fit: no grid clutter'); zs.value='c'; w.eval('ZC=8; draw()'); }
  sc2.scrollLeft=5000; w.eval('draw()'); const r=sc2.getBoundingClientRect(); const ce=new w.MouseEvent('click',{clientX:r.left+100,bubbles:true}); cv.dispatchEvent(ce);
  ok(Math.abs(w.eval('CUR')-(5100/W*w.eval('TL.dur')))<2,'tap maps through the scroll offset ('+(w.eval('CUR')/1000).toFixed(2)+' s)');
  w.close(); console.log(`${n-fails}/${n} passed`); p.kill(); process.exit(fails?1:0);
})().catch(e=>{ console.log('ERR',e.stack); p.kill(); process.exit(2); });
