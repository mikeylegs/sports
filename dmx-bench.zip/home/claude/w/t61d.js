// 27l on Dare's REAL audio (re-analyzed here): kicks detected, grid tempo, and the live-preview strobe vs the kicks read
// from the waveform -- with and without the Known BPM (Link simulator)
const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2], TRK=process.argv[3]; const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx')); fs.copyFileSync(FILE,path.join(d,'artnet-controller.js')); fs.mkdirSync(path.join(d,'logs'));
fs.copyFileSync(TRK,path.join(d,'logs','track-80355717-523518.ndjson'));
const K=JSON.parse(fs.readFileSync('/tmp/dareOn.json','utf8')).map(x=>x*1000);   // audible kick onsets (50% rise of the kick-band envelope, 6 ms resolution)
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'}); const B='http://127.0.0.1:8080'; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
let n=0,f=0; const ok=(c,m)=>{n++; if(!c){f++; console.log('FAIL',m);} }; const res={};
(async()=>{ await sleep(800); const {JSDOM}=require('jsdom');
  for(const bpm of [0,134.03]){
    const v=new JSDOM(await (await fetch(B+'/logs/track-80355717-523518.ndjson')).text(),{runScripts:'outside-only',url:B+'/logs/x'}).window;
    v.HTMLCanvasElement.prototype.getContext=()=>new Proxy({},{get:(t,k)=>k==='measureText'?()=>({width:0}):(k in t?t[k]:()=>{}),set:(t,k,x)=>{t[k]=x;return true;}});
    if(bpm) v.localStorage.setItem('artnetBpm:track-80355717-523518.ndjson',String(bpm));
    v.fetch=(u,o)=>fetch(B+u,o); v.requestAnimationFrame=()=>0; v.eval([...v.document.querySelectorAll('script')].map(x=>x.textContent).join('\n'));
    for(let i=0;i<50 && !v.eval('TL');i++) await sleep(100); v.eval('ensureLivePlan()'); for(let i=0;i<900 && !v.eval('!!TL.rigLive');i++) await sleep(100);
    const S=JSON.parse(v.eval('JSON.stringify({bpm:TL.sec.bpm,src:TL.sec.src,lock:TL.sec.lockMs})')), P=JSON.parse(v.eval('JSON.stringify(TL.rigLive)'));
    const near=(arr,x,w)=>arr.some(y=>Math.abs(y-x)<=w);
    const grooveK=K.filter(k=>k>82000 && k<236000);   // the main grooves
    const cov=grooveK.filter(k=>near(P.strobe,k,80)).length, fl=P.strobe.filter(t=>t>82000 && t<236000), onK=fl.filter(t=>near(K,t,80)).length;
    res[bpm]={cov:cov/grooveK.length, prec:onK/fl.length};
    const dd=fl.map(x=>{ let b=1e9; K.forEach(k=>{ if(Math.abs(k-x)<Math.abs(b)) b=k-x; }); return b; }).filter(x=>Math.abs(x)<400).sort((a,b)=>a-b);
    console.log('     kick - flash ms: p10 '+Math.round(dd[Math.floor(dd.length*.1)])+' p25 '+Math.round(dd[Math.floor(dd.length*.25)])+' p50 '+Math.round(dd[dd.length>>1])+' p75 '+Math.round(dd[Math.floor(dd.length*.75)])+' p90 '+Math.round(dd[Math.floor(dd.length*.9)]));
    console.log('   '+(bpm?'Known BPM '+bpm:'kick-tracked')+': grid '+S.bpm+' BPM ('+S.src+(S.lock!=null?', lock '+Math.round(S.lock)+' ms':'')+') · kicks 1:22-3:56 with a flash '+cov+'/'+grooveK.length+' · flashes on a kick '+onK+'/'+fl.length);
    v.close(); }
  ok(res[134.03].cov>=0.8 && res[134.03].prec>=0.8,'with the known BPM the strobe follows Dare\'s kicks (>= 80% both ways)');
  console.log(`${n-f}/${n} passed`); p.kill(); process.exit(f?1:0); })().catch(e=>{ console.log('ERR',e.stack); p.kill(); process.exit(2); });
