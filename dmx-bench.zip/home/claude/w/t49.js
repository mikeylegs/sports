// autonomy: idle when the music stops, fog guard, strobe rate cap, preflight, Pi setup kills old supervisors
const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2]; const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx'));
fs.copyFileSync(FILE,path.join(d,'artnet-controller.js')); fs.writeFileSync(path.join(d,'settings.json'),JSON.stringify({targetIP:'127.0.0.1'}));
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore',env:Object.assign({},process.env,{DMX_IDLE_MS:'1500',DMX_FOG_MAX_MS:'2000'})});
const B='http://127.0.0.1:8080'; let fails=0,n=0; const ok=(c,m)=>{n++; if(!c){fails++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const post=(u,b)=>fetch(B+u,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)});
const log=async()=>(await (await fetch(B+'/liveshow')).json()).log;
(async()=>{ await sleep(800);
  await fetch(B+'/liveshow',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({strobe:'full'})});   // 27s: this suite tests the FULL strobe behaviour
  let r=await fetch(B+'/preflight'); ok(r.status===200,'/preflight'); if(r.status!==200){ console.log(`${n-fails}/${n} passed`); p.kill(); process.exit(1); }
  let pf=(await r.json()).checks, g=nm=>pf.find(c=>c.name===nm)||{};
  ok(g('Pi bridge page').st==='bad' && g('Latency').st==='warn' && /calibrate/.test(g('Latency').msg) && g('Live show').msg==='OFF' && g('Safety').st==='info','preflight before anything: Pi silent, latency default, show off');
  await post('/bridgestate',{levels:[0.02,0,0,0],active:[true,false,false,false],hits:[1,0,0,0],recording:true,build:'x'});
  pf=(await (await fetch(B+'/preflight')).json()).checks; ok(g('Pi bridge page').st==='ok' && g('Music').st==='ok' && g('Input level').st==='warn' && /raise the LOC80 gain/.test(g('Input level').msg),'quiet input flagged: raise the gain ('+g('Input level').msg+')');
  await post('/bridgestate',{levels:[0.3,0,0,0],active:[true,false,false,false],hits:[2,0,0,0],recording:true,build:'x'});
  pf=(await (await fetch(B+'/preflight')).json()).checks; ok(g('Input level').st==='ok','healthy input ok ('+g('Input level').msg+')');
  // idle
  await post('/liveshow',{enabled:true}); await sleep(4200); let L=await log();   // 27e: idle only once the Pi's last 'music' report is > 3 s old
  ok(L.some(x=>x.kind==='idle'),'show ON, no music: goes idle (strobe + fog off, warm dim PARs)');
  pf=(await (await fetch(B+'/preflight')).json()).checks; ok(/idle/.test(g('Live show').msg),'preflight shows idle');
  await post('/bridgestate',{levels:[0.3,0,0,0],active:[true,false,false,false],hits:[3,0,0,0],recording:true,build:'x',live:{beatMs:480,nextBeatIn:300,pb:1,groove:true,mode:'heavy',slvl:1,kickOn:true,hatsOn:false,washIdx:2,washNextIn:null,bpm:125}});
  await sleep(200); L=await log(); ok(L.some(x=>x.kind==='wash' && x.why==='sync' && x.idx===2),'music back: the wash comes back at once');
  // strobe cap: a 210 ms beat would flash ~4.8/s
  for(let i=0;i<8;i++){ await post('/lv',{k:i%2?0.15:0.4}); await sleep(30); }   // 27j+: the strobe needs the bass playing
  const T0=Date.now(); for(let i=0;i<6;i++){ await post('/lv',{k:i%2?0.15:0.4}); await post('/bridgestate',{levels:[0.3,0,0,0],active:[true,false,false,false],hits:[3,0,0,0],recording:true,build:'x',live:{beatMs:210,nextBeatIn:100,pb:1,groove:true,mode:'heavy',slvl:1,kickOn:true,hatsOn:false,washIdx:2,washNextIn:null,bpm:285}}); await sleep(250); }
  L=(await log()).filter(x=>x.kind==='flash' && x.t>=T0).map(x=>x.t); const gaps=L.slice(1).map((t,i)=>t-L[i]);
  ok(L.length>=3 && gaps.every(x=>x>=245),'strobe never faster than 4/s ('+L.length+' flashes, min gap '+Math.min(...gaps)+' ms)');
  // fog guard
  await post('/liveshow',{enabled:false}); await post('/dmx',{bulk:[[0,64,255],[0,81,255]]}); await sleep(4600); L=await log();   // watchdog ticks 1 s: first sighting + 2 s limit + next tick
  ok(L.some(x=>x.kind==='fog cut'),'fog held past the limit is cut ('+L.slice(-4).map(x=>x.kind+(x.why?':'+x.why:'')).join(', ')+')');
  // Pi setup: every old supervisor stopped
  const sh=await (await fetch(B+'/pi/setup.sh')).text(); ok(/pkill -f "\$BIN\/dmx-linkd"/.test(sh),'Pi setup stops every older supervisor');
  const show=await (await fetch(B+'/lab/show')).text(); ok(/id="pf"/.test(show) && /\/preflight/.test(show),'Show tab shows the preflight');
  console.log(`${n-fails}/${n} passed`); p.kill(); process.exit(fails?1:0);
})().catch(e=>{ console.log('ERR',e.stack); p.kill(); process.exit(2); });
