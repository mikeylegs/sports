// 27f confidence: when the live show goes BOLD (hard colour cut on a phrase change), is it right?
const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2], TR=['track-52285985-558042','track-15337193-247718','track-12342465-086980','track-37199921-932496','track-39307571-582210','track-65570060-568769'];
const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx')); fs.copyFileSync(FILE,path.join(d,'artnet-controller.js')); fs.mkdirSync(path.join(d,'logs'));
TR.forEach(t=>fs.copyFileSync('/mnt/user-data/uploads/'+t+'.ndjson',path.join(d,'logs',t+'.ndjson')));
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'});
const B='http://127.0.0.1:8080'; let fails=0,n=0; const ok=(c,m)=>{n++; if(!c){fails++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{ await sleep(800); const {JSDOM}=require('jsdom'); let allB=0, allBok=0, allH=0, allHok=0;
  for(const t of TR){ const v=new JSDOM(await (await fetch(B+'/logs/'+t+'.ndjson')).text(),{runScripts:'outside-only',url:B+'/logs/x'}).window;
    v.HTMLCanvasElement.prototype.getContext=()=>new Proxy({},{get:(t,k)=>k==='measureText'?()=>({width:0}):(k in t?t[k]:()=>{}),set:(t,k,x)=>{t[k]=x;return true;}});
    v.fetch=(u,o)=>fetch(B+u,o); v.requestAnimationFrame=()=>0; v.eval([...v.document.querySelectorAll('script')].map(x=>x.textContent).join('\n'));
    for(let i=0;i<50 && !v.eval('TL');i++) await sleep(100);
    v.eval('ensureLivePlan()'); for(let i=0;i<900 && !v.eval('!!TL.rigLive');i++) await sleep(100);
    const P=JSON.parse(v.eval('JSON.stringify(TL.rigLive)')), SB=JSON.parse(v.eval('JSON.stringify(TL.sec.bars)'));
    const ps=SB.filter(b=>b.pb===1).map(b=>b.t), beat=(SB[10].t1-SB[10].t)/4, cues=P.hits.map(h=>h.t);
    const ch=P.cols.slice(1).filter(c=>!cues.some(q=>Math.abs(q-c[0])<2500)), bold=ch.filter(c=>!c[2]), soft=ch.filter(c=>c[2]);
    const right=c=>ps.some(s=>Math.abs(s-c[0])<=beat), bOk=bold.filter(right).length;
    const pred=P.confT, bt=pred.filter(x=>x[1]>=0.6).length/Math.max(1,pred.length);
    allB+=bold.length; allBok+=bOk; allH+=ch.length; allHok+=ch.filter(right).length;
    console.log('  '+t.slice(6,14)+': bold '+Math.round(bt*100)+'% of the predictive time · bold phrase cuts right '+bOk+'/'+bold.length+' · soft drifts '+soft.length);
    v.close(); }
  console.log('  ALL: bold cuts on a hindsight phrase start '+allBok+'/'+allB+' ('+Math.round(allBok/Math.max(1,allB)*100)+'%) vs every non-cue change '+allHok+'/'+allH+' ('+Math.round(allHok/Math.max(1,allH)*100)+'%)');
  ok(allB>=20 && allBok/allB>=0.85,'when the show goes bold it is right >= 85% of the time');
  console.log(`${n-fails}/${n} passed`); p.kill(); process.exit(fails?1:0);
})().catch(e=>{ console.log('ERR',e.stack); p.kill(); process.exit(2); });
