const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2]; const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx'));
fs.copyFileSync(FILE,path.join(d,'artnet-controller.js')); fs.mkdirSync(path.join(d,'logs')); fs.mkdirSync(path.join(d,'tracks'));
fs.copyFileSync('/mnt/user-data/uploads/track-52285985-558042.ndjson',path.join(d,'logs','track-52285985-558042.ndjson')); fs.writeFileSync(path.join(d,'tracks','a.mp3'),Buffer.alloc(10));
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'});
const B='http://127.0.0.1:8080'; let fails=0,n=0; const ok=(c,m)=>{n++; if(!c){fails++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{ await sleep(800);
  for(const [u,nm] of [['/icon-dmx.png','controller'],['/icon-bridge.png','bridge'],['/apple-touch-icon.png','default']]){
    const r=await fetch(B+u), b=Buffer.from(await r.arrayBuffer()); const w=b.readUInt32BE(16), h=b.readUInt32BE(20);
    ok(r.status===200 && r.headers.get('content-type')==='image/png' && b.slice(1,4).toString()==='PNG' && w===180 && h===180, nm+' icon: 180x180 PNG'); }
  const a=Buffer.from(await (await fetch(B+'/icon-dmx.png')).arrayBuffer()), c=Buffer.from(await (await fetch(B+'/icon-bridge.png')).arrayBuffer()); ok(!a.equals(c),'two different icons');
  const pages={'/':'dmx','/perform':'dmx','/react':'dmx','/calibrate':'dmx','/lab':'dmx','/lab/show':'dmx','/lab/tracks':'dmx','/lab/track?f=a.mp3':'dmx','/lab/recordings':'dmx','/lab/mark':'dmx','/lab/link':'dmx','/lab/phrasetest':'dmx','/logs/track-52285985-558042.ndjson':'dmx','/console':'bridge','/bridge':'bridge'};
  for(const u in pages){ const r=await fetch(B+u); if(r.status!==200){ ok(false,u+' '+r.status); continue; } const h=await r.text(); const m=h.match(/rel="apple-touch-icon" href="\/icon-(\w+)\.png"/g)||[];
    ok(m.length===1 && m[0].includes('icon-'+pages[u]+'.png'), u+': home-screen icon = '+pages[u]); }
  console.log(`${n-fails}/${n} passed`); p.kill(); process.exit(fails?1:0);
})().catch(e=>{ console.log('ERR',e.stack); p.kill(); process.exit(2); });
