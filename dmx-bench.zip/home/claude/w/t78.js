// 28d: no loupes -- every page blocks the long-press loupe / callout / selection, except in inputs
const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2]; const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx')); fs.copyFileSync(FILE,path.join(d,'artnet-controller.js'));
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'}); const B='http://127.0.0.1:8080'; let n=0,f=0; const ok=(c,m)=>{n++; if(!c){f++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{ await sleep(900); const {JSDOM}=require('jsdom');
  const pages=['/','/cc','/console','/bridge','/lab','/lab/show','/lab/tracks','/react','/perform'];
  for(const u of pages){ const r=await fetch(B+u); const h=await r.text(); ok(r.status===200 && /-webkit-touch-callout:none/.test(h) && /selectstart/.test(h),u+': no-loupe CSS + handlers'); }
  const v=new JSDOM(await (await fetch(B+'/cc')).text(),{runScripts:'outside-only',url:B+'/cc'}).window; v.fetch=()=>new Promise(()=>{});
  [...v.document.querySelectorAll('script')].forEach(s=>{ try{ v.eval(s.textContent); }catch(e){} });
  const cm=new v.Event('contextmenu',{bubbles:true,cancelable:true}); v.document.getElementById('bDrop').dispatchEvent(cm); ok(cm.defaultPrevented,'long-press menu blocked on a button');
  const cm2=new v.Event('contextmenu',{bubbles:true,cancelable:true}); v.document.getElementById('mb').dispatchEvent(cm2); ok(!cm2.defaultPrevented,'inputs still allow it (cursor placement)');
  // 28e: double-tap-and-hold on a fixture chip
  const chip=v.document.querySelector('.chip[data-fx="strobe"]'); let clicks=0; chip.addEventListener('click',()=>clicks++);
  const tev=(k)=>{ const e=new v.Event(k,{bubbles:true,cancelable:true}); chip.dispatchEvent(e); return e; };
  let e1=tev('touchstart'); tev('touchend'); ok(!e1.defaultPrevented,'a single tap is left to the browser (normal click, scrolling still works)');
  let e2=tev('touchstart'); ok(e2.defaultPrevented,'2nd touch within 450 ms: native gesture cancelled (no loupe)');
  await sleep(600); const e3=tev('touchend'); ok(e3.defaultPrevented && clicks===0,'held past 450 ms: no click (it was a hold)');
  await sleep(500); tev('touchstart'); tev('touchend'); const e4=tev('touchstart'); tev('touchend'); ok(e4.defaultPrevented && clicks===1,'quick double tap: the 2nd tap is re-issued as a click');
  v.close(); console.log(`${n-f}/${n} passed`); p.kill(); process.exit(f?1:0); })().catch(e=>{ console.log('ERR',e.stack); p.kill(); process.exit(2); });
