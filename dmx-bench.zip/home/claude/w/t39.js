// live-engine confirmation fallback on the real fixtures (run t28's engine in simulated real time)
const {run}=require('./t28.js'); const fs=require('fs'); let n=0,f=0; const ok=(c,m)=>{n++; if(!c){f++; console.log('FAIL',m);} };
const L=p=>fs.readFileSync('/mnt/user-data/uploads/'+p+'.ndjson','utf8').trim().split('\n').map(JSON.parse);
const hits=p=>run(L(p)).filter(o=>o.ev==='hit').map(o=>o.at/1000), near=(h,t)=>h.some(x=>Math.abs(x-t)<=1);
const H={rizz:hits('track-15250173-827976'), anti:hits('track-17812045-121758'), dec:hits('track-15337193-247718'), lady:hits('track-65570060-568769'), com:hits('track-12342465-086980'), cl:hits('track-45538816-686165')};
ok(near(H.rizz,76.8) && near(H.rizz,288.0),'Rizz: first drop (before the phrase count settles) + 4:48 after a mid-phrase break ('+H.rizz+')');
ok(near(H.anti,61.0),'Anti-Hero: 1:01 after the long break ('+H.anti+')');
ok(near(H.dec,215.5),'Deceiver: 3:35 after the 10-bar break ('+H.dec+')');
ok(near(H.lady,263.0),'Lady: 4:23 after the 2-bar break ('+H.lady+')');
ok(near(H.com,199.6),'Call On Me: the 53-bars-later drop ('+H.com+')');
ok(!near(H.com,159.0) && !near(H.com,185.2) && !near(H.cl,46.9),'no fallback hits on light kick returns (Call On Me 2:39/3:05, Cutting Loose 0:47)');
ok(Object.values(H).every(h=>h.every((x,i)=>!i || x-h[i-1]>1)),'never two hits on the same drop');
console.log(`${n-f}/${n} passed`); process.exit(f?1:0);
