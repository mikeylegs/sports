// 27u: RGB-waveform drop detector (RedDetector) + the engine's use of it
const fs=require('fs'); const SRC=fs.readFileSync(process.argv[2],'utf8'); let n=0,f=0; const ok=(c,m)=>{n++; if(!c){f++; console.log('FAIL',m);} };
const RJ=(SRC.match(/const RED_JS = String\.raw`([\s\S]*?)`;/)||[])[1]; ok(!!RJ,'RED_JS present'); if(!RJ){ console.log(`${n-f}/${n} passed`); process.exit(1); }
const LJ=(SRC.match(/const LIVE_JS = `([\s\S]*?)`;/)||[])[1]; const G={}; new Function('G',RJ+'\n'+LJ+'\nG.RD=RedDetector; G.LE=LiveEngine; G.RB=RED_BANDS;')(G);
ok(G.RB.length===2 && G.RB[0].lo===30 && G.RB[1].hi===1000,'hidden colour bands: sub 30-100, low-mid 250-1000');
const groove=[0.5,0.1,0.05,0.02,0.6,0.15], brk=[0.08,0.3,0.2,0.1,0.1,0.35];   // [punch,1-4k,6-12k,12-16k,sub,lowmid]
function run(seq){ const d=new G.RD(), out=[], done=new Set(); let t=0; seq.forEach(([dur,lv,kicks])=>{ const end=t+dur; for(;t<end;t+=1000/60){ (kicks||[]).forEach(k=>{ if(t>=k && !done.has(k)){ done.add(k); d.kick(t); } }); const o=d.feed(t,lv); if(o) out.push(Object.assign({t:Math.round(t)},o)); } }); return out; }
let A=run([[60000,groove],[10000,brk],[5000,groove,[70000]]]);
const dr=A.filter(o=>o.ev==='drop');
ok(A.some(o=>o.ev==='break') ,'breakdown colour -> break state');
ok(dr.length===1 && Math.abs(dr[0].at-70000)<=20 && dr[0].t-dr[0].at>=110 && dr[0].t-dr[0].at<=140,'kick + red after a break = one drop, at the kick, decided ~120 ms later ('+(dr[0]?dr[0].at+' / +'+(dr[0].t-dr[0].at)+' ms':'none')+')');
const build=[0.25,0.25,0.15,0.08,0.3,0.25], hush=[0.02,0.12,0.1,0.06,0.02,0.1];
A=run([[60000,groove],[8500,build],[1500,hush],[5000,groove,[70000]]]); const gd=A.filter(o=>o.ev==='drop');
ok(gd.length===1 && gd[0].t-gd[0].at<=50,'27v gap trigger (Dolce): build that keeps its colour, ~1 bar near-colourless, kick + red = a drop, decided in ~30 ms ('+(gd[0]?'+'+(gd[0].t-gd[0].at)+' ms':'none')+')');
A=run([[60000,groove],[8500,groove],[1500,hush],[5000,groove,[70000]]]); ok(!A.some(o=>o.ev==='drop'),'a short quiet moment inside a groove (no build before it): no drop');
A=run([[60000,groove],[10000,brk],[5000,brk,[70000]]]); ok(!A.some(o=>o.ev==='drop'),'a kick that doesn\'t turn it red: no drop');
A=run([[75000,groove,[30000,50000,70000]]]); ok(!A.some(o=>o.ev==='drop'),'kicks in a groove: no drop');
A=run([[60000,groove],[10000,brk],[5000,groove,[70000,70500]]]); ok(A.filter(o=>o.ev==='drop').length===1,'one drop per drop (next kick ignored)');
// the engine
const E=Object.create(G.LE.prototype); E.wash={idx:0,cueT:null,next:null}; E.ev=[]; E.r={bpm:128,bars:[{t:0,t1:1875,pb:1,st:'G'}]}; E.lastBarAt=()=>({t:60000,t1:61875,pb:1,st:'G'});
E.push({k:'rb',v:1,t:69000}); ok(E.redBrk===true,'engine: rb event = breakdown');
E.push({k:'rd',ago:120,t:70120}); const out=E.step(70200)||[]; ok(out.some(o=>o.ev==='hit' && o.at===70000),'engine: rd event -> a drop hit at the kick (the Pi then sends /livecue)');
ok(E.wash.cueT===70000 && E.wash.idx===1,'engine: the drop re-anchors the phrase clock + new colour');
console.log(`${n-f}/${n} passed`); process.exit(f?1:0);
