// 27t: the 1 of the drop on the prediction, one bar of bass-following strobe after, bass-back drops
const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2]; const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx')); fs.copyFileSync(FILE,path.join(d,'artnet-controller.js'));
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'}); const B='http://127.0.0.1:8080'; let n=0,f=0; const ok=(c,m)=>{n++; if(!c){f++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const post=(u,b)=>fetch(B+u,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)});
const L=480; const snap=(o)=>post('/bridgestate',{levels:[0.3,0,0,0],active:[true,false,false,false],hits:[3,0,0,0],recording:true,build:'x',live:Object.assign({beatMs:L,nextBeatIn:100,pb:8,groove:true,mode:'heavy',slvl:1,kickOn:true,hatsOn:false,washIdx:2,washNextIn:9000,bpm:125},o)});
const log=async T=>(await (await fetch(B+'/liveshow')).json()).log.filter(x=>x.t>=T);
(async()=>{ await sleep(900); await post('/liveshow',{enabled:true,latencyMs:0,strobe:'drops'});
  // 1) a build predicting the drop 300 ms out
  for(let i=0;i<6;i++){ await post('/lv',{k:0.2}); await sleep(30); }
  const T0=Date.now(); await snap({build:true,groove:false,nextPhraseIn:300,nextBeatIn:300}); await sleep(360); await post('/livecue',{washIdx:3}); await sleep(260);
  let lg=await log(T0); const d1=lg.find(x=>x.kind==='flash' && x.why==='drop');
  ok(d1 && d1.t-T0>=300 && d1.t-T0<=700,'nothing fires early on a prediction; the confirmation fires the 1 ('+(d1?(d1.t-T0)+' ms':'none')+')');
  lg=await log(T0);
  ok(lg.filter(x=>x.kind==='flash' && x.why==='drop').length===1 && lg.filter(x=>x.why==='boom').length===3,'the confirmation adds the burst, not a second 1');
  // 2) the bar after the drop: beats follow the bass (kick playing), level scales with the bass
  const T1=Date.now(); for(let i=0;i<5;i++){ await post('/lv',{k:i%2?0.1:0.4}); await post('/bridgehit',{strength:1,band:1}); await snap({build:false,nextBeatIn:120}); await sleep(200); }
  lg=await log(T1); const beats=lg.filter(x=>x.kind==='flash' && (x.why==='beat'||x.why==='catch'));
  ok(beats.length>=2,'the bar after the drop: the strobe follows the kick ('+beats.length+' beats)');
  await sleep(1300); const T2=Date.now(); for(let i=0;i<6;i++){ await post('/lv',{k:i%2?0.1:0.4}); await post('/bridgehit',{strength:1,band:1}); await snap({build:false,nextBeatIn:120}); await sleep(200); }
  ok((await log(T2)).filter(x=>x.kind==='flash').length===0,'after that bar: back to PARs + Govee only');
  // 3) bass comes back after a break (no prediction): the drop fires on that kick
  for(let i=0;i<8;i++){ await post('/lv',{k:0.6}); await sleep(30); }   // a loud groove sets the peak
  const tb=Date.now(); while(Date.now()-tb<16*L+400){ await post('/lv',{k:0.08}); await sleep(90); }   // 4+ bars of break
  const T3=Date.now(); await post('/bridgehit',{strength:1,band:1}); await post('/lv',{k:0.6}); await sleep(300); lg=await log(T3);
  const bb=lg.find(x=>x.kind==='flash' && x.why==='drop');
  ok(bb && bb.t-T3<=80 && lg.some(x=>x.kind==='drop'),'bass back after a break: the drop fires on that kick ('+(bb?(bb.t-T3)+' ms':'none')+')');
  await post('/liveshow',{enabled:false});
  console.log(`${n-f}/${n} passed`); p.kill(); process.exit(f?1:0); })().catch(e=>{ console.log('ERR',e.stack); p.kill(); process.exit(2); });
