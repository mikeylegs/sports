// 27k: the strobe mimics the bass LEVEL too (sustained sub-bass, few kick hits) + share falls back to a download
const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2]; const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx'));
fs.copyFileSync(FILE,path.join(d,'artnet-controller.js')); fs.mkdirSync(path.join(d,'logs')); fs.writeFileSync(path.join(d,'settings.json'),JSON.stringify({targetIP:'127.0.0.1'}));
// Deceiver with every kick hit after 0:30 removed -- the 'Dare' situation (bass plainly there, detector silent)
const ev=fs.readFileSync('/mnt/user-data/uploads/track-15337193-247718.ndjson','utf8').trim().split('\n').filter(l=>{ const e=JSON.parse(l); return !(e.k==='h' && e.b===1 && e.t>30000); });
fs.writeFileSync(path.join(d,'logs','track-99999999-000001.ndjson'),ev.join('\n')+'\n');
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'});
const B='http://127.0.0.1:8080'; let fails=0,n=0; const ok=(c,m)=>{n++; if(!c){fails++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const post=(u,b)=>fetch(B+u,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)});
const snap=()=>post('/bridgestate',{levels:[0.3,0,0,0],active:[true,false,false,false],hits:[1,0,0,0],recording:true,build:'x',live:{beatMs:480,nextBeatIn:200,pb:3,groove:true,mode:'heavy',slvl:1,kickOn:true,hatsOn:false,washIdx:2,washNextIn:null,bpm:125}});
(async()=>{ await sleep(800); const {JSDOM}=require('jsdom');
  await fetch(B+'/liveshow',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({strobe:'full'})});   // 27s: this suite tests the FULL strobe behaviour
  await post('/liveshow',{enabled:true,latencyMs:0});
  for(let i=0;i<10;i++){ await post('/lv',{k:i%4<2?0.4:0.15}); await sleep(33); }
  let T0=Date.now(); await snap(); for(let i=0;i<30;i++){ await post('/lv',{k:i%4<2?0.4:0.15}); await sleep(33); }   // a pumping bass line
  let L=(await (await fetch(B+'/liveshow')).json()).log.filter(x=>x.kind==='flash' && x.t>=T0);
  ok(L.length>=2,'bass level up, no kick hits: the strobe still fires on the beats ('+L.length+')');
  for(let i=0;i<50;i++){ await post('/lv',{k:0.004}); await sleep(33); }
  T0=Date.now(); await snap(); for(let i=0;i<30;i++){ await post('/lv',{k:0.004}); await sleep(33); }
  L=(await (await fetch(B+'/liveshow')).json()).log.filter(x=>x.kind==='flash' && x.t>=T0);
  ok(L.length===0,'bass gone: no strobe ('+L.length+')');
  await post('/liveshow',{enabled:false});
  // preview on the hit-starved file
  const v=new JSDOM(await (await fetch(B+'/logs/track-99999999-000001.ndjson')).text(),{runScripts:'outside-only',url:B+'/logs/x'}).window;
  v.HTMLCanvasElement.prototype.getContext=()=>new Proxy({},{get:(t,k)=>k==='measureText'?()=>({width:0}):(k in t?t[k]:()=>{}),set:(t,k,x)=>{t[k]=x;return true;}});
  v.fetch=(u,o)=>fetch(B+u,o); v.requestAnimationFrame=()=>0; v.eval([...v.document.querySelectorAll('script')].map(x=>x.textContent).join('\n'));
  for(let i=0;i<50 && !v.eval('TL');i++) await sleep(100);
  v.eval('ensureLivePlan()'); for(let i=0;i<900 && !v.eval('!!TL.rigLive');i++) await sleep(100);
  const P=JSON.parse(v.eval('JSON.stringify(TL.rigLive.strobe)')), inGroove=P.filter(t=>t>=100000 && t<130000).length, inBreak=P.filter(t=>t>=181000 && t<205000).length;
  ok(inGroove>=40,'preview: groove 1:40-2:10 flashes from the bass level ('+inGroove+')');
  ok(inBreak<=inGroove/3,'preview: the long breakdown (a faint kick, ~20% of the drop level) stays mostly dark ('+inBreak+')');
  // share -> download fallback
  let clicked=null; v.HTMLAnchorElement.prototype.click=function(){ clicked=this.download; }; v.URL.createObjectURL=()=>'blob:x'; v.URL.revokeObjectURL=()=>{};
  v.navigator.canShare=()=>true; v.navigator.share=()=>Promise.reject(Object.assign(new Error('Permission denied'),{name:'NotAllowedError'}));
  for(let i=0;i<30 && !v.eval('typeof file!=="undefined" && file');i++) await sleep(100);
  v.document.getElementById('share').click(); await sleep(100);
  ok(clicked && /ndjson$/.test(clicked) && /downloaded/.test(v.document.body.textContent),'share blocked (work PC): downloads the file instead ('+clicked+')');
  v.close(); console.log(`${n-fails}/${n} passed`); p.kill(); process.exit(fails?1:0);
})().catch(e=>{ console.log('ERR',e.stack); p.kill(); process.exit(2); });
