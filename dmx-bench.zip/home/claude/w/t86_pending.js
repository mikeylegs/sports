// 28n: phrase clock locked to the grid's bars -- a tempo reading that's off doesn't make phrase changes drift late
const fs=require('fs'); const SRC=fs.readFileSync(process.argv[2],'utf8'); let n=0,f=0; const ok=(c,m)=>{n++; if(!c){f++; console.log('FAIL',m);} };
const LJ=(SRC.match(/const LIVE_JS = `([\s\S]*?)`;/)||[])[1]; const G={}; new Function('G',LJ+'\nG.LE=LiveEngine;')(G);
function run(trueBpm, readBpm){ const BAR=4*60000/trueBpm, o=Object.create(G.LE.prototype); o.wash={idx:0,cueT:0,next:null}; o.r={bpm:readBpm};
  o.lastBarAt=now=>{ const k=Math.floor(now/BAR); return {t:(k-1)*BAR, t1:k*BAR, pb:((k-1)%8)+1}; };   // the grid's bar lines sit on the real kicks
  const ch=[]; let last=0; for(let t=100;t<200000;t+=50){ o.washTick(t); if(o.wash.idx!==last){ ch.push(t); last=o.wash.idx; } }
  const err=ch.map((t,i)=>{ const want=Math.round(t/(8*BAR))*8*BAR; return Math.abs(t-want); }); return {ch, worst:Math.max(...err), BAR}; }
const A=run(134,134), B=run(134,132), C=run(126,127.5);
console.log('   right tempo: '+A.ch.length+' changes, worst '+A.worst.toFixed(0)+' ms off the 8-bar line | reading 132 for 134: worst '+B.worst.toFixed(0)+' ms | 127.5 for 126: worst '+C.worst.toFixed(0)+' ms');
ok(A.ch.length>=12 && A.worst<=60,'right tempo: every change on the 8-bar line');
ok(B.worst<=60,'tempo read 1.5% slow (132 for 134): still on the line after '+B.ch.length+' phrases (no drift)');
ok(C.worst<=60,'tempo read 1.2% fast: same');
console.log(`${n-f}/${n} passed`); process.exit(f?1:0);
