// 28k: Pi stops listening (bridge off) -> the show goes idle within seconds; PARs don't freeze at their last level
const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os'), dgram=require('dgram');
const FILE=process.argv[2]; const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx')); fs.copyFileSync(FILE,path.join(d,'artnet-controller.js'));
fs.writeFileSync(path.join(d,'settings.json'),JSON.stringify({targetIP:'127.0.0.2'}));
let last=null; const sock=dgram.createSocket({type:'udp4',reuseAddr:true}); sock.on('message',m=>{ if(m.length>=530 && m.toString('latin1',0,7)==='Art-Net' && m.readUInt16LE(14)===0) last=Buffer.from(m.subarray(18)); }); sock.bind(6454,'127.0.0.2');
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'}); const B='http://127.0.0.1:8080'; let n=0,f=0; const ok=(c,m)=>{n++; if(!c){f++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const post=(u,b)=>fetch(B+u,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)}); const ch=c=>last?last[c-1]:-1;
(async()=>{ await sleep(900); await post('/liveshow',{enabled:true,idleGlow:'off'});
  for(let i=0;i<40;i++){ await post('/lv',{k:0.5}); if(i%5===0) await post('/bridgestate',{levels:[0.4,0,0,0],active:[true,false,false,false],hits:[1,0,0,0],recording:true,build:'x',live:{beatMs:480,nextBeatIn:100,pb:3,groove:true,mode:'heavy',slvl:1,kickOn:true,hatsOn:false,washIdx:2,washNextIn:9000,bpm:125}}); await sleep(30); }
  ok(ch(88)>100,'music: PAR pumping ('+ch(88)+')');
  const T=Date.now(); let dark=null; while(Date.now()-T<9000){ await sleep(250); if(ch(88)===0 && dark===null) dark=Date.now()-T; }   // the Pi goes quiet (bridge off)
  ok(dark!==null && dark<=5000,'Pi stops listening: PARs dark after '+(dark===null?'>9 s':(dark/1000).toFixed(1)+' s')+' (was 30 s)');
  const L=(await (await fetch(B+'/liveshow')).json()).log.find(x=>x.kind==='idle'); ok(L && /stopped listening/.test(L.why||''),'logged why');
  await post('/liveshow',{idleGlow:'warm'}); await sleep(500); ok(ch(88)===60,'movie mode: idle glow WARM applies');
  // 28m: switching the Pi bridge off -> dark straight away, even while the Pi is still streaming
  await post('/liveshow',{idleGlow:'off'}); for(let i=0;i<20;i++){ await post('/lv',{k:0.5}); if(i%5===0) await post('/bridgestate',{levels:[0.4,0,0,0],active:[true,false,false,false],hits:[1,0,0,0],recording:true,build:'x',live:{beatMs:480,nextBeatIn:100,pb:3,groove:true,mode:'heavy',slvl:1,kickOn:true,hatsOn:false,washIdx:2,washNextIn:9000,bpm:125}}); await sleep(30); }
  ok(ch(88)>100,'music back: PAR pumping ('+ch(88)+')');
  const T2=Date.now(); await post('/bridgectl',{want:false}); let dk=null; while(Date.now()-T2<3000){ await post('/lv',{k:0.5}); await sleep(40); if(ch(88)===0 && dk===null){ dk=Date.now()-T2; break; } }
  ok(dk!==null && dk<=500,'PI BRIDGE off: PARs dark in '+(dk===null?'>3 s':dk+' ms')+' (the Pi still streaming doesn\'t hold them up)');
  await post('/bridgectl',{want:true});
  await post('/liveshow',{enabled:false}); console.log(`${n-f}/${n} passed`); p.kill(); sock.close(); process.exit(f?1:0); })().catch(e=>{ console.log('ERR',e.stack); p.kill(); process.exit(2); });
