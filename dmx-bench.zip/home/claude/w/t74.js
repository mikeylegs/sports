// 27y: the rig now receives dropIn (predicted drop, 27u) and bib (beat in bar, 27w) from the Pi's snapshots
const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2]; const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx')); fs.copyFileSync(FILE,path.join(d,'artnet-controller.js'));
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'}); const B='http://127.0.0.1:8080'; let n=0,f=0; const ok=(c,m)=>{n++; if(!c){f++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const post=(u,b)=>fetch(B+u,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)});
const L=480; const snap=o=>post('/bridgestate',{levels:[0.3,0,0,0],active:[true,false,false,false],hits:[3,0,0,0],recording:true,build:'x',live:Object.assign({beatMs:L,nextBeatIn:100,pb:3,groove:true,mode:'heavy',slvl:1,kickOn:true,hatsOn:false,washIdx:2,washNextIn:9000,bpm:125},o)});
const log=async T=>(await (await fetch(B+'/liveshow')).json()).log.filter(x=>x.t>=T);
(async()=>{ await sleep(900); await post('/liveshow',{enabled:true,latencyMs:0,level:2});
  for(let i=0;i<6;i++){ await post('/lv',{k:i%2?0.1:0.4}); await sleep(30); }
  // predicted drop armed by the Pi (dropIn) -> the 1 fires on the line, with no kick yet
  let T=Date.now(); await snap({groove:false,dropIn:300,nextBeatIn:300,bib:0}); await sleep(420);
  let lg=await log(T), d1=lg.find(x=>x.kind==='flash' && x.why==='drop'); ok(d1 && Math.abs(d1.t-T-300)<=45,'predicted drop (dropIn) fires the 1 on the line ('+(d1?(d1.t-T)+' ms':'none')+')');
  // strobe tail: after the drop bar, bars 2-4 flash only on beats 1 and 3 (bib 0 / 2)
  await sleep(4*L+200); const T2=Date.now(), seen=[];
  for(let b=0;b<6;b++){ const bib=b%4; await post('/lv',{k:0.4}); await post('/bridgehit',{strength:1,band:1}); await snap({bib:bib,nextBeatIn:60}); await sleep(L); seen.push(bib); }
  const tl=(await log(T2)).filter(x=>x.kind==='flash' && x.why==='beat');
  ok(tl.length>=2 && tl.length<=4,'tail: beats 1 & 3 only ('+tl.length+' of 6 beats flashed)');
  await post('/liveshow',{enabled:false}); console.log(`${n-f}/${n} passed`); p.kill(); process.exit(f?1:0); })().catch(e=>{ console.log('ERR',e.stack); p.kill(); process.exit(2); });
