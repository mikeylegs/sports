const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2]; const SRC=fs.readFileSync(FILE,'utf8'); const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx'));
fs.copyFileSync(FILE,path.join(d,'artnet-controller.js'));
fs.mkdirSync(path.join(d,'tracks')); fs.writeFileSync(path.join(d,'tracks','Test Track.mp3'),Buffer.alloc(50000,7));
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'});
const B='http://127.0.0.1:8080'; let fails=0, n=0; const ok=(c,m)=>{n++; if(!c){fails++; console.log('FAIL',m);} };
const get=(u,h)=>fetch(B+u,{headers:h||{}}).then(r=>r.text().then(t=>({s:r.status,t,h:r.headers})));
const post=(u,b,raw)=>fetch(B+u,{method:'POST',headers:{'Content-Type':'application/json'},body:raw?b:JSON.stringify(b)}).then(r=>r.status);
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
// synthetic house track: 128 BPM, groove / 16-bar breakdown (no kick) / drop
function synth(sr,secs){ const N=sr*secs, a=new Float32Array(N), bl=60/128; let seed=1; const rnd=()=>((seed=(seed*16807)%2147483647)/2147483647)*2-1;
  for(let i=0;i<N;i++) a[i]=rnd()*0.01;
  for(let b=0; b*bl<secs; b++){ const bar=Math.floor(b/4), s0=Math.floor(b*bl*sr); const brk=bar>=32&&bar<48;
    if(!brk) for(let j=0;j<sr*0.15&&s0+j<N;j++) a[s0+j]+=0.8*Math.sin(2*Math.PI*60*j/sr)*Math.exp(-j/sr/0.05);
    if(b%2===1) for(let j=0;j<sr*0.04&&s0+j<N;j++) a[s0+j]+=0.3*Math.sin(2*Math.PI*2000*j/sr)*Math.exp(-j/sr/0.015);
    const h=Math.floor((b+0.5)*bl*sr); for(let j=0;j<sr*0.03&&h+j<N;j++) a[h+j]+=0.15*Math.sin(2*Math.PI*8000*j/sr+rnd())*Math.exp(-j/sr/0.008); }
  return a; }
(async()=>{
  await sleep(800);
  const TDJ=(SRC.match(/const TRACK_DETECT_JS = `([\s\S]*?)`;/)||[])[1]; ok(!!TDJ,'detector source found'); if(!TDJ){ console.log(`${n-fails}/${n} passed (no detector)`); p.kill(); process.exit(1); }
  const cfg=JSON.parse((await get('/bridgeconfig')).t);
  // 1) detector on the synthetic track
  const sr=44100, secs=150, sig=synth(sr,secs); const g={}; new Function('G',TDJ+';G.a=tdAnalyze;G.e=tdEvents;')(g);
  const run=(bands)=>new Promise(r=>g.a([sig],sr,bands,()=>{},r));
  const out=await run(cfg.bands);
  const kicks=out.hits.filter(h=>h.b===1), kb=kicks.filter(h=>h.t>32*4*468.75+2000 && h.t<48*4*468.75-500).length;
  ok(Math.abs(out.ft.length-secs*10)<=3,'~10 frames/s ('+out.ft.length+')');
  ok(out.frames.every(f=>f.length===out.ft.length),'4 bands aligned');
  const BL=60000/128, grooveB=[...Array(320).keys()].filter(b=>{ const bar=Math.floor(b/4); return !(bar>=32&&bar<48) && b>=2; });
  const covered=grooveB.filter(b=>kicks.some(h=>h.t>=b*BL && h.t<=b*BL+60)).length/grooveB.length;
  const gk=kicks.filter(h=>!(h.t>=128*BL && h.t<192*BL)), onBeat=gk.filter(h=>((h.t%BL)+BL)%BL<=160).length/gk.length;
  ok(covered>=0.97,'a kick hit within 60ms of '+Math.round(covered*100)+'% of groove beats');
  ok(onBeat>=0.97,Math.round(onBeat*100)+'% of groove kick hits sit on a beat (+160ms)');
  new Function('G',TDJ+';G.c=tdCoefs;')(g); const mag=(c,f)=>{ const w=2*Math.PI*f/sr, re=x=>Math.cos(-x*w), im=x=>Math.sin(-x*w);
    const nr=c[0]+c[1]*re(1)+c[2]*re(2), ni=c[1]*im(1)+c[2]*im(2), dr=1+c[3]*re(1)+c[4]*re(2), di=c[3]*im(1)+c[4]*im(2); return Math.hypot(nr,ni)/Math.hypot(dr,di); };
  const pk=Math.pow(10,1/20); ok(Math.abs(mag(g.c(false,120,sr),120)-pk)<0.01 && Math.abs(mag(g.c(true,40,sr),40)-pk)<0.01,'biquads = WebAudio default (Q=1 dB: |H(f0)|=1.122)');
  ok(mag(g.c(false,120,sr),20)>0.99 && mag(g.c(true,40,sr),15000)>0.99 && mag(g.c(false,120,sr),2400)<0.01,'LP/HP passbands + stopband sane');
  const quiet=await run(cfg.bands.map(b=>Object.assign({},b,{sens:50}))); ok(quiet.hits.length===0,'vacuity: sens 50 -> 0 hits');
  const kickLvl=o=>Math.max(...o.frames[0]), tone=f=>{ const a=new Float32Array(sr*3); for(let i=0;i<a.length;i++) a[i]=0.5*Math.sin(2*Math.PI*f*i/sr); return a; };
  const lv=async f=>{ const o=await new Promise(r=>g.a([tone(f)],sr,cfg.bands,()=>{},r)); return kickLvl(o); };
  const l60=await lv(190), l5k=await lv(5000); ok(l60>0.2 && l5k<l60/30,'band-1 (kick punch, 100-250 Hz since 27o) passes 190Hz, rejects 5kHz ('+l60.toFixed(3)+' vs '+l5k.toFixed(4)+')');
  // 2) analyzer page end-to-end in jsdom (decode stubbed with the synthetic track)
  const list=await get('/lab/tracks'); ok(/Test Track\.mp3/.test(list.t) && /\/lab\/track\?f=Test%20Track\.mp3/.test(list.t),'Tracks lists mp3 -> analyze');
  ok(/<a href="\/lab\/tracks" class="on">Tracks</.test(list.t),'Tracks tab active');
  ok((await get('/lab/track?f=..%2Fartnet-controller.js')).s===404,'analyze rejects traversal');
  ok((await get('/tracks/..%2Fartnet-controller.js')).s===400,'/tracks rejects traversal');
  const rg=await fetch(B+'/tracks/Test%20Track.mp3',{headers:{Range:'bytes=100-199'}}); ok(rg.status===206 && (await rg.arrayBuffer()).byteLength===100,'mp3 Range 206');
  const {JSDOM}=require('jsdom'); const ap=(await get('/lab/track?f=Test%20Track.mp3')).t;
  const dom=new JSDOM(ap,{runScripts:'outside-only',url:B+'/lab/track?f=x'}); const w=dom.window; let replaced=null;
  w.fetch=(u,o)=>fetch(B+u,o); w.__rep=u=>{replaced=u;};
  w.AudioContext=function(){ this.decodeAudioData=(buf,res)=>{ res({numberOfChannels:1,sampleRate:sr,duration:secs,getChannelData:()=>sig}); }; this.close=()=>{}; };
  w.eval([...w.document.querySelectorAll('script')].map(x=>x.textContent).join('\n').replace('location.replace(','window.__rep('));
  for(let i=0;i<200 && !replaced;i++) await sleep(100);
  const m=ap.match(/ID="(track-\d{8}-\d{6})"/); const ID=m&&m[1];
  ok(replaced==='/logs/'+ID+'.ndjson','analyzer saved + opened viewer ('+replaced+' / '+w.document.getElementById('st').textContent+')');
  const txt=(await get('/logs/raw/'+ID+'.ndjson')).t, ev=txt.trim().split('\n').map(JSON.parse);
  ok(ev[0].k==='start'&&ev[0].src==='track'&&ev[0].track==='Test Track.mp3'&&ev[1].k==='a'&&ev[1].t===0,'recording header + audio t0');
  ok(ev.filter(e=>e.k==='f').length===out.ft.length && ev.filter(e=>e.k==='h').length===out.hits.length,'saved frames/hits = detector output');
  ok(ev.every((e,i)=>i<2||!ev[i-1].t||e.t>=ev[i-1].t),'time-ordered');
  // 3) phrase view on the saved file (viewer's own analyzeSections)
  const vw=(await get('/logs/'+ID+'.ndjson')).t;
  ok(/src="\/tracks\/Test%20Track\.mp3"/.test(vw),'viewer plays the mp3');
  ok(/href="\/lab\/tracks">&larr; Audio Lab/.test(vw),'viewer back -> Tracks');
  ok(/data-l="fake"/.test(vw) && !/data-l="other"/.test(vw),'track mark set: Fake, no Other');
  ok(!(await get('/lab/recordings')).t.includes(ID),'track analyses not in Recordings');
  // 4) viewer in jsdom: mark snaps to grid, nudge + delete persist, score re-renders
  const vd=new JSDOM(vw,{runScripts:'outside-only',url:B+'/logs/'+ID+'.ndjson'}); const v=vd.window;
  v.HTMLCanvasElement.prototype.getContext=()=>new Proxy({},{get:(t,k)=>k==='measureText'?(()=>({width:0})):(k in t?t[k]:()=>{}),set:(t,k,val)=>{t[k]=val;return true;}});
  v.fetch=(u,o)=>fetch(B+u,o); v.navigator.clipboard={writeText:()=>Promise.resolve()};
  v.eval([...v.document.querySelectorAll('script')].map(x=>x.textContent).join('\n'));
  for(let i=0;i<50 && !v.eval('TL'); i++) await sleep(100);
  ok(v.eval('!!(TL && TL.sec && TL.sec.bars.length)'),'phrase view has a beat grid');
  ok(Math.abs(v.eval('TL.sec.bpm')-128)<=1,'grid tempo ~128 ('+v.eval('TL.sec&&TL.sec.bpm')+')');
  const b0=v.eval('TL.sec.bars[20].t'), L=v.eval('(TL.sec.bars[20].t1-TL.sec.bars[20].t)/4');
  v.eval('CUR='+(b0+L+0.3*L)); v.document.querySelector('.mk[data-l="drop"]').click(); await sleep(300);
  const dm=()=>fs.readFileSync(path.join(d,'logs',ID+'.ndjson'),'utf8').trim().split('\n').map(JSON.parse).filter(e=>e.k==='m');
  ok(dm().length===1 && Math.abs(dm()[0].t-(b0+L))<=1,'drop mark snapped to beat ('+(dm()[0]&&dm()[0].t)+' vs '+Math.round(b0+L)+')');
  ok(v.eval('!!SEL') && v.document.getElementById('nudge').style.display==='flex','new mark selected, nudge shown');
  ok(/drops 0\/1|drops 1\/1/.test(v.document.getElementById('tlstats').innerHTML),'score re-rendered with the mark');
  v.document.querySelector('.nb[data-d="1"]').click(); await sleep(300);
  ok(Math.abs(dm()[0].t-(b0+2*L))<=1,'+beat persisted ('+dm()[0].t+')');
  v.document.querySelector('.nb[data-d="-4"]').click(); await sleep(300);
  ok(Math.abs(dm()[0].t-(b0+2*L-4*L))<=2,'-bar persisted ('+dm()[0].t+')');
  v.document.querySelector('.nb[data-d="x"]').click(); await sleep(300);
  ok(dm().length===0 && !v.eval('SEL'),'delete persisted');
  // 5) server edge cases
  fs.writeFileSync(path.join(d,'logs','bridge-20260925-130000.ndjson'),'{"k":"start","t":0}\n{"k":"m","label":"drop","age":300,"t":5300}\n');
  ok(await post('/logmarkedit',{file:'bridge-20260925-130000.ndjson',label:'drop',t:4000,to:1})===400,'vacuity: wrong t -> 400');
  ok(await post('/logmarkedit',{file:'bridge-20260925-130000.ndjson',label:'drop',t:5000,to:6000})===200,'live mark (age) matched by shown time');
  ok(/"t":6000,"post":true/.test(fs.readFileSync(path.join(d,'logs','bridge-20260925-130000.ndjson'),'utf8')),'live mark rewritten, age dropped');
  ok(await post('/tracklog?id=track-00000000-000000','{"k":"start","src":"track","track":"Test Track.mp3"}\n',true)===400,'tracklog id mismatch -> 400');
  ok(await post('/logmark',{file:'bridge-20260925-130000.ndjson',t:10,label:'fake'})===200,'fake accepted by /logmark');
  console.log(`${n-fails}/${n} passed`); p.kill(); process.exit(fails?1:0);
})().catch(e=>{console.log('ERR',e.stack); p.kill(); process.exit(2);});
