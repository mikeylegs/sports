// 28h: solo never survives a restart; mutes do, and preflight flags them
const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2]; const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx')); fs.copyFileSync(FILE,path.join(d,'artnet-controller.js'));
let n=0,f=0; const ok=(c,m)=>{n++; if(!c){f++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms)); const B='http://127.0.0.1:8080';
const post=(u,b)=>fetch(B+u,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)});
const boot=async()=>{ const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'}); await sleep(900); return p; };
(async()=>{ let p=await boot();
  let pf=(await (await fetch(B+'/ccstate')).json()).pf.find(x=>x.name==='Fixtures'); ok(pf && pf.st==='ok' && /all live/.test(pf.msg),'preflight: fixtures all live');
  await post('/showcfg',{mutes:{fog:true},solo:'par1'}); pf=(await (await fetch(B+'/ccstate')).json()).pf.find(x=>x.name==='Fixtures'); ok(pf.st==='warn' && /SOLO par1/.test(pf.msg),'preflight flags a solo');
  p.kill(); await sleep(400); p=await boot();
  const c=await (await fetch(B+'/showcfg')).json(); ok(c.solo===null && c.mutes.fog===true,'after a restart: solo gone, the fog mute kept');
  pf=(await (await fetch(B+'/ccstate')).json()).pf.find(x=>x.name==='Fixtures'); ok(pf.st==='warn' && /muted: fog/.test(pf.msg),'preflight: muted: fog');
  p.kill(); console.log(`${n-f}/${n} passed`); process.exit(f?1:0); })().catch(e=>{ console.log('ERR',e.stack); process.exit(2); });
