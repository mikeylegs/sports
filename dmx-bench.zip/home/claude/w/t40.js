// live-show snapshots from the Pi engine, fed in simulated real time: predicted beats vs the hindsight grid, groove latch, wash cycle
const fs=require('fs'); const {G}=require('./t28.js'); let n=0,f=0; const ok=(c,m)=>{n++; if(!c){f++; console.log('FAIL',m);} };
function sim(file){ const ev=fs.readFileSync(file,'utf8').trim().split('\n').map(JSON.parse), E=ev.filter(e=>e.k==='f'||e.k==='h').sort((a,b)=>a.t-b.t), L=new G.LE(), snaps=[], cues=[]; let i=0;
  for(let now=0; now<=E[E.length-1].t; now+=100){ while(i<E.length && E[i].t<=now) L.push(E[i++]); L.step(now).forEach(o=>{ if(o.ev==='hit') cues.push({at:o.at,t:now,idx:L.wash.idx}); }); if(now%300===0){ const s=L.snap(now); if(s) snaps.push(Object.assign({now},s)); } }
  const full=G.AS(ev); return {snaps,cues,full,ev}; }
for(const [nm,file] of [['Meduza','/mnt/user-data/uploads/track-52285985-558042.ndjson'],['Deceiver','/mnt/user-data/uploads/track-15337193-247718.ndjson'],['Odd Mob','/mnt/user-data/uploads/track-96314428-446959.ndjson']]){
  const {snaps,cues,full}=sim(file), beats=[]; full.bars.forEach(b=>{ const L=(b.t1-b.t)/4; for(let q=0;q<4;q++) beats.push(b.t+q*L); });
  const near=t=>{ let lo=0,hi=beats.length-1; while(lo<hi){ const m=(lo+hi)>>1; if(beats[m]<t) lo=m+1; else hi=m; } return Math.min(Math.abs(beats[lo]-t), lo?Math.abs(beats[lo-1]-t):1e9); };
  const gs=snaps.filter(s=>s.groove), errs=gs.map(s=>near(s.now+s.nextBeatIn)).sort((a,b)=>a-b), med=errs[errs.length>>1], p90=errs[Math.floor(errs.length*0.9)];
  const modes={}; gs.forEach(s=>modes[s.mode]=(modes[s.mode]||0)+1); const washMax=Math.max(...snaps.map(s=>s.washIdx));
  console.log('  '+nm+': snapshots',snaps.length,'| groove',gs.length,'| predicted-beat error vs hindsight grid: median',Math.round(med),'ms, p90',Math.round(p90),'ms | modes',JSON.stringify(modes),'| wash changes',washMax,'| cues',cues.map(c=>(c.at/1000).toFixed(1)).join(','));
  if(nm!=='Odd Mob') ok(med<=20,nm+': the next beat predicted within 20 ms (median) of the hindsight grid');   // Odd Mob: known limit, sparse kick hits -> live tempo drifts early on
  ok(gs.every(s=>s.nextBeatIn>=0 && s.nextBeatIn<=s.beatMs+1),nm+': nextBeatIn always within one beat');
  ok(washMax>=6,nm+': wash moves on through the track');
  ok(cues.every(c=>snaps.some(s=>s.now>c.t && s.washIdx>=c.idx)),nm+': every drop hit advances the wash');
}
console.log(`${n-f}/${n} passed`); process.exit(f?1:0);
