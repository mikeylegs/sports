const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2]; const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx'));
fs.copyFileSync(FILE,path.join(d,'artnet-controller.js')); fs.mkdirSync(path.join(d,'logs')); fs.mkdirSync(path.join(d,'tracks'));
fs.writeFileSync(path.join(d,'tracks','a.mp3'),Buffer.alloc(10)); fs.writeFileSync(path.join(d,'logs','bridge-20260926-120000.ndjson'),'{"k":"start","t":0}\n');
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'}); let fails=0,n=0; const ok=(c,m)=>{n++; if(!c){fails++; console.log('FAIL',m);} };
(async()=>{ await new Promise(r=>setTimeout(r,800)); const {JSDOM}=require('jsdom');
  for(const u of ['/lab','/lab/mark','/lab/tracks','/lab/track?f=a.mp3','/lab/recordings','/lab/link','/logs/bridge-20260926-120000.ndjson']){
    const h=await (await fetch('http://127.0.0.1:8080'+u)).text(), w=new JSDOM(h).window;
    const rules=[...w.document.styleSheets].flatMap(s=>[...s.cssRules]).filter(r=>r.selectorText==='html' && r.style.touchAction==='manipulation');
    ok(rules.length>=1,u+' html{touch-action:manipulation}'); }
  console.log(`${n-fails}/${n} passed`); p.kill(); process.exit(fails?1:0); })();
