const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2], SRC=fs.readFileSync(FILE,'utf8'); const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx'));
fs.copyFileSync(FILE,path.join(d,'artnet-controller.js')); fs.mkdirSync(path.join(d,'logs'));
let fails=0,n=0; const ok=(c,m)=>{n++; if(!c){fails++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const TDJ=(SRC.match(/const TRACK_DETECT_JS = `([\s\S]*?)`;/)||[])[1]; const g={}; new Function('G',TDJ+';G.a=tdAnalyze;')(g);
// 128 BPM: groove 0-31, break 32-47 (riser), DROP 48-79, break 80-91, 1-bar fake kick 92, out 93-95, DROP 96-111
const sr=44100, BL=60/128, bars=112, N=Math.ceil(bars*4*BL*sr)+sr, a=new Float32Array(N); let seed=3; const rnd=()=>((seed=(seed*16807)%2147483647)/2147483647)*2-1;
const kickOn=bar=>(bar<32)||(bar>=48&&bar<80)||bar===92||bar>=96;
for(let i=0;i<N;i++) a[i]=rnd()*0.004;
for(let b=0;b<bars*4;b++){ const bar=Math.floor(b/4), s0=Math.floor(b*BL*sr);
  if(kickOn(bar)) for(let j=0;j<sr*0.15&&s0+j<N;j++) a[s0+j]+=0.8*Math.sin(2*Math.PI*60*j/sr)*Math.exp(-j/sr/0.05);
  if(b%2===1) for(let j=0;j<sr*0.04&&s0+j<N;j++) a[s0+j]+=0.3*Math.sin(2*Math.PI*2000*j/sr)*Math.exp(-j/sr/0.015);
  const h=Math.floor((b+0.5)*BL*sr); for(let j=0;j<sr*0.03&&h+j<N;j++) a[h+j]+=0.15*Math.sin(2*Math.PI*8000*j/sr+rnd())*Math.exp(-j/sr/0.008);
  if((bar>=40&&bar<48)||(bar>=88&&bar<92)) for(let j=0;j<BL*sr&&s0+j<N;j++) a[s0+j]+=rnd()*0.05*((bar%8)+1)/8; }   // risers
(async()=>{
  const cfg={bands:[{lo:40,hi:120,sens:1.5},{lo:1000,hi:4000,sens:1.05},{lo:6000,hi:12000,sens:1.3},{lo:12000,hi:16000,sens:1.3}]};
  const out=await new Promise(r=>g.a([a],sr,cfg.bands,()=>{},r));
  const ev=[{k:'start',src:'bridge',t:0}].concat(out.ft.map((t,i)=>({k:'f',e:out.frames.map(f=>f[i]),t})),out.hits).sort((x,y)=>x.t-y.t);
  const ms=bar=>Math.round(bar*4*BL*1000);
  fs.writeFileSync(path.join(d,'logs','bridge-20260926-100000.ndjson'),ev.concat([{k:'m',label:'drop',t:ms(48),post:true},{k:'m',label:'drop',t:ms(96),post:true},{k:'m',label:'drop',t:ms(20),post:true}]).map(e=>JSON.stringify(e)).join('\n')+'\n');
  const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'}); await sleep(800); const B='http://127.0.0.1:8080';
  const {JSDOM}=require('jsdom'); const html=await (await fetch(B+'/logs/bridge-20260926-100000.ndjson')).text();
  const v=new JSDOM(html,{runScripts:'outside-only'}).window;
  v.HTMLCanvasElement.prototype.getContext=()=>new Proxy({},{get:(t,k)=>k==='measureText'?()=>({width:0}):(k in t?t[k]:()=>{}),set:(t,k,x)=>{t[k]=x;return true;}});
  v.fetch=(u,o)=>fetch(B+u,o);
  v.eval([...v.document.querySelectorAll('script')].map(x=>x.textContent).join('\n'));
  for(let i=0;i<50 && !v.eval('TL');i++) await sleep(100);
  ok(v.eval('!!(TL&&TL.sec)'),'full-file phrase view present');
  const btn=v.document.getElementById('czbtn'); ok(!!btn,'Causal replay button');
  if(!btn){ console.log(`${n-fails}/${n} passed`); p.kill(); process.exit(1); }
  const seen=[]; v.eval('var __AS=analyzeSections;'); v.__rec=x=>seen.push(x);
  v.eval('analyzeSections=function(ev){ var m=0, mk=false; ev.forEach(function(e){ if(e.t>m) m=e.t; if(e.k==="m") mk=true; }); __rec({max:m, mk:mk}); return __AS(ev); };');
  btn.click(); for(let i=0;i<600 && !v.eval('TL.cz');i++) await sleep(100);
  const z=v.eval('TL.cz'); ok(!!z,'replay finished');
  ok(seen.length===z.T.length && seen.every((s,i)=>s.max<=z.T[i]+0.5),'no future data at any step ('+seen.length+' steps)');
  ok(seen.every(s=>!s.mk),'marks never fed to the tracker');
  const mk=t=>z.marks.find(x=>Math.abs(x.m-ms(t))<2);
  console.log('   info:',JSON.stringify(z.marks.map(x=>({bar:Math.round(x.m/ (4*BL*1000)),lat:x.lat,pred:x.pred}))), 'lock', z.lock, 'agree', z.agree.toFixed(2), 'calls', JSON.stringify(z.calls.map(c=>({bar:+(c.d/(4*BL*1000)).toFixed(2),atBar:+(c.at/(4*BL*1000)).toFixed(2),fresh:c.fresh,final:c.final,fake:c.fakeLater}))));
  ok(mk(48).lat!=null && mk(48).lat>=3.99,'drop @48 confirmed live, at/after the 4-beat floor ('+mk(48).lat+')');
  ok(mk(96).lat!=null && mk(96).lat>=3.99,'drop @96 confirmed live ('+mk(96).lat+')');
  ok(mk(20).lat===null,'vacuity: a mark mid-groove is never confirmed');
  v.eval("window.__D=TL.cz.lane.map(function(g){ return g.pbOk?1:0; }).join('')"); console.log('   pbOk per bar:',v.__D);
  v.eval("window.__E=(function(){ var FB=TL.sec.bars, r=__AS(TL.ev.filter(function(e){return e.k!=='m' && e.t<=FB[70].t1;})); var lb=r.bars[r.bars.length-1], fb=FB.filter(function(b){return Math.abs(b.t-lb.t)<300;})[0]; return JSON.stringify({bpmC:r.bpm, lbT:lb.t, lbPb:lb.pb, fbT:fb&&fb.t, fbPb:fb&&fb.pb, finBpm:TL.sec.bpm}); })()"); console.log('   bar70:',v.__E);
  { const L=z.lane.slice(50,88), ag=L.filter(g=>g.pbOk).length/L.length; ok(ag>=0.9,'live grid agrees with the full view between the first drop and the fake ('+Math.round(ag*100)+'%)'); }
  ok(z.calls.some(c=>c.fresh&&!c.final&&c.fakeLater&&Math.abs(c.d-ms(92))<ms(1)),'fake at bar 92 shows up as a live false call, later read as fake');
  ok(v.document.getElementById('czout').innerHTML.includes('Your drops confirmed live: 2/3'),'summary scores the marks');
  v.eval('TL.cz=null; rerender()'); for(let i=0;i<600 && !v.eval('TL.cz');i++) await sleep(100); ok(v.eval('!!TL.cz') && !/Marks changed/.test(v.document.getElementById('czout').innerHTML),'marks changed: the replay re-runs by itself (no stale notice)');
  console.log(`${n-fails}/${n} passed`); p.kill(); process.exit(fails?1:0);
})().catch(e=>{console.log('ERR',e.stack); process.exit(2);});
