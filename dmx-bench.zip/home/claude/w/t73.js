// 27y: Command Center (/cc) end to end in jsdom, with Art-Net captured on the wire
const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os'), dgram=require('dgram');
const FILE=process.argv[2]; const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx')); fs.copyFileSync(FILE,path.join(d,'artnet-controller.js'));
fs.writeFileSync(path.join(d,'settings.json'),JSON.stringify({targetIP:'127.0.0.2',kasa:[{ip:'127.0.0.9',childId:null,alias:'Govee strip'},{ip:'127.0.0.8',childId:'01',alias:'Fog plug'}]}));
let last=null; const sock=dgram.createSocket({type:'udp4',reuseAddr:true}); sock.on('message',m=>{ if(m.length>=530 && m.toString('latin1',0,7)==='Art-Net' && m.readUInt16LE(14)===0) last=Buffer.from(m.subarray(18)); }); sock.bind(6454,'127.0.0.2');
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'}); const B='http://127.0.0.1:8080'; let n=0,f=0; const ok=(c,m)=>{n++; if(!c){f++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const post=(u,b)=>fetch(B+u,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)}); const ch=c=>last?last[c-1]:-1;
const snap=o=>post('/bridgestate',{levels:[0.3,0.1,0,0],active:[true,false,false,false],hits:[3,0,0,0],recording:true,build:'x',live:Object.assign({beatMs:480,nextBeatIn:120,pb:5,groove:true,mode:'heavy',slvl:1,kickOn:true,hatsOn:false,washIdx:2,washNextIn:9000,bpm:125,src:'kick',bib:0},o)});
(async()=>{ await sleep(900); const {JSDOM}=require('jsdom');
  const r=await fetch(B+'/cc'); const html=await r.text(); ok(r.status===200 && /COMMAND CENTER/.test(html) && html.indexOf('__BUILD__')<0,'GET /cc serves the page with the build stamped');
  ok(/grid-template-columns:repeat\(3,minmax\(0,1fr\)\)/.test(html) && /\.st\{ min-width:0/.test(html) && /class="tS"/.test(html),'27z portrait: grids can\'t be widened by long text; one-line phone header');
  const ic=await fetch(B+'/icon-cc.png'); const icb=Buffer.from(await ic.arrayBuffer()); ok(ic.status===200 && icb.slice(1,4).toString()==='PNG' && /apple-touch-icon" href="\/icon-cc.png"/.test(html),'28f: Command Center has its own home-screen icon');
  const sh=await (await fetch(B+'/lab/show')).text(); ok(/href="\/cc"/.test(sh),'Show tab links to it');
  const v=new JSDOM(html,{runScripts:'outside-only',url:B+'/cc',pretendToBeVisual:true}).window; v.fetch=(u,o)=>fetch(B+u,o);
  v.eval(v.document.querySelector('script').textContent); const $=id=>v.document.getElementById(id), txt=id=>$(id).querySelector('.v').textContent;
  const click=el=>el.dispatchEvent(new v.Event('click',{bubbles:true})), pd=el=>el.dispatchEvent(new v.Event('pointerdown',{bubbles:true,cancelable:true})), pu=el=>el.dispatchEvent(new v.Event('pointerup',{bubbles:true}));
  await sleep(900);
  ok(txt('sShow')==='OFF' && $('bShow').textContent==='SHOW OFF' && txt('sGrid')==='NO GRID','idle: show off, no grid');
  // show on + audio + grid
  const keepLv=setInterval(()=>post('/lv',{k:0.3}).catch(()=>{}),200);   // 28k: the Pi streams levels continuously; a silent stream now means 'Pi stopped listening' -> idle
  click($('bShow')); for(let i=0;i<6;i++){ await post('/lv',{k:i%2?0.1:0.4}); await snap(); await sleep(150); } await sleep(400);
  ok($('bShow').textContent==='SHOW ON' && /^ON/.test(txt('sShow')),'SHOW button turns the show on');
  ok(/125\.0/.test(txt('sGrid')) && /125\.0/.test($('nBpm').textContent),'grid + BPM on screen ('+txt('sGrid')+')');
  ok($('nSec').textContent==='GROOVE' && $('nPhr').children[4].className==='on','section GROOVE, phrase bar 5 of 8 lit');
  ok(/LISTENING/.test(txt('sPi')) && /%/.test(txt('sAud')),'Pi listening, audio level shown');
  // strobe level
  click(v.document.querySelector('.seg button[data-l="3"]')); await sleep(500); ok((await (await fetch(B+'/liveshow')).json()).level===3 && v.document.querySelector('.seg button[data-l="3"]').classList.contains('on'),'strobe level 3 from the segment control');
  // fixtures: mute / solo, checked on the wire
  await post('/dmx',{bulk:[[0,37,255],[0,41,200],[0,88,180],[0,95,170],[0,1,60]]}); await sleep(400);
  const chip=k=>v.document.querySelector('.chip[data-fx="'+k+'"]');
  click(chip('strobe')); await sleep(700); ok(ch(37)===0 && chip('strobe').classList.contains('mut') && /MUTED/.test(chip('strobe').textContent),'tap STROBE: muted on the wire + on screen');
  click(chip('strobe')); await sleep(700); ok(ch(37)===255 && !chip('strobe').classList.contains('mut'),'tap again: live');
  pd(chip('par2')); await sleep(700); pu(chip('par2')); click(chip('par2')); await sleep(700);
  ok(ch(95)>0 && ch(88)===0 && ch(1)===0 && chip('par2').classList.contains('solo') && !chip('par2').classList.contains('mut'),'hold PAR 2: solo (the tap after a hold does not mute it)');
  pd(chip('par2')); await sleep(700); pu(chip('par2')); click(chip('par2')); await sleep(700); ok(ch(88)>0,'hold again: solo off (PAR 1 back)');
  // drop, next colour, blackout
  let before=(await (await fetch(B+'/ccstate')).json()).wash.idx;
  click($('bNext')); await sleep(500); let s=await (await fetch(B+'/ccstate')).json(); ok(s.wash.idx===before+1,'NEXT COLOUR advances the wash');
  await snap(); click($('bDrop')); await sleep(300); await snap(); const L=(await (await fetch(B+'/liveshow')).json()).log; ok(L.some(x=>x.kind==='drop' && /manual/.test(x.why||'')) && L.some(x=>x.kind==='flash' && x.why==='drop'),'DROP! fires the drop look');
  s=await (await fetch(B+'/ccstate')).json(); ok(s.grid.section==='drop' && s.lastDropAgo!==null,'section shows DROP, last drop timed');
  pd($('bBlack')); await sleep(600); const all0=last && last.every(x=>x===0); ok(all0 && $('bBlack').classList.contains('held') && /BLACKOUT/.test(txt('sShow')),'hold BLACKOUT: the whole universe dark on the wire');
  pu($('bBlack')); await sleep(700); ok(last && last.some(x=>x>0) && !$('bBlack').classList.contains('held'),'release: output back');
  // Pi bridge / Link switches
  click($('bLink')); await sleep(500); ok((await (await fetch(B+'/linkctl')).json()).want===false,'LINK button switches the Pi Link reader off');
  click($('bLink')); await sleep(400);
  // power: roles + Govee chip
  await sleep(1200); ok(/GOVEE/.test($('pw').textContent) && /Fog plug/.test($('pw').textContent),'power row lists the Kasa plugs with their roles');
  const sel=v.document.querySelector('#roles select[data-r="fog"]'); sel.value='1'; sel.dispatchEvent(new v.Event('change')); await sleep(500);
  ok(((await (await fetch(B+'/showcfg')).json()).power.fog||{}).childId==='01','Setup: assign the fog plug to FOG');
  // setup: latency + manual bpm
  click(v.document.querySelector('[data-lat="10"]')); await sleep(400); ok((await (await fetch(B+'/liveshow')).json()).latencyMs===90,'latency +10');
  $('mb').value='128'; click($('mbSet')); await sleep(400); ok((await (await fetch(B+'/liveshow')).json()).manualBpm===128,'manual BPM from Setup');
  await sleep(500); ok(/\d+\/\d+ OK/.test($('pfSum').textContent) && $('pf').children.length>=5,'preflight list on Setup');
  clearInterval(keepLv); v.close(); await post('/liveshow',{enabled:false});
  console.log(`${n-f}/${n} passed`); p.kill(); sock.close(); process.exit(f?1:0); })().catch(e=>{ console.log('ERR',e.stack); p.kill(); process.exit(2); });
