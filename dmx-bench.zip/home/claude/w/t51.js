// 27e: live-engine preview (stage view plays what the rig would do) + the controller's reactive fallback
const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2]; const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx'));
fs.copyFileSync(FILE,path.join(d,'artnet-controller.js')); fs.mkdirSync(path.join(d,'logs')); fs.mkdirSync(path.join(d,'tracks'));
fs.copyFileSync('/mnt/user-data/uploads/track-39307571-582210.ndjson',path.join(d,'logs','track-39307571-582210.ndjson')); fs.writeFileSync(path.join(d,'tracks','DAMEN & Gil Glaze - Dolce.mp3'),Buffer.alloc(100));
fs.writeFileSync(path.join(d,'settings.json'),JSON.stringify({targetIP:'127.0.0.1'}));
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'});
const B='http://127.0.0.1:8080'; let fails=0,n=0; const ok=(c,m)=>{n++; if(!c){fails++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const post=(u,b)=>fetch(B+u,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)});
(async()=>{ await sleep(800); const {JSDOM}=require('jsdom');
  await fetch(B+'/liveshow',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({strobe:'full'})});   // 27s: this suite tests the FULL strobe behaviour
  // --- controller fallback
  await post('/liveshow',{enabled:true}); await post('/bridgestate',{levels:[0.3,0,0,0],active:[true,false,false,false],hits:[1,0,0,0],recording:true,build:'x'});
  let s=await (await fetch(B+'/liveshow')).json(); ok(s.mode==='reactive','music, no grid yet: REACTIVE ('+s.mode+')');
  const T0=Date.now(); await post('/bridgehit',{band:1,strength:2.5}); await sleep(100); s=await (await fetch(B+'/liveshow')).json();
  ok(s.log.some(x=>x.kind==='flash' && x.t>=T0) && s.log.some(x=>x.kind==='wash' && x.why==='reactive'),'reactive, not locked yet: each kick flashes (27j: the strobe mimics the bass)');
  await post('/bridgestate',{levels:[0.3,0,0,0],active:[true,false,false,false],hits:[2,0,0,0],recording:true,build:'x',live:{beatMs:480,nextBeatIn:300,pb:1,groove:true,mode:'heavy',slvl:1,kickOn:true,hatsOn:false,washIdx:3,washNextIn:null,bpm:125}});
  s=await (await fetch(B+'/liveshow')).json(); ok(s.mode==='predictive','grid arrives: PREDICTIVE');
  const T1=Date.now(); await sleep(260); await post('/bridgehit',{band:1,strength:2.5}); await sleep(60); s=await (await fetch(B+'/liveshow')).json();
  ok(!s.log.some(x=>x.why==='reactive' && x.t>=T1),'predictive: kick hits no longer fire reactively');
  await post('/liveshow',{enabled:false});
  const show=await (await fetch(B+'/lab/show')).text(); ok(/REACTIVE/.test(show) && /PREDICTIVE/.test(show),'Show tab names the mode');
  // --- viewer: live preview
  const v=new JSDOM(await (await fetch(B+'/logs/track-39307571-582210.ndjson')).text(),{runScripts:'outside-only',url:B+'/logs/x'}).window;
  v.HTMLCanvasElement.prototype.getContext=()=>new Proxy({},{get:(t,k)=>k==='measureText'?()=>({width:0}):(k in t?t[k]:()=>{}),set:(t,k,x)=>{t[k]=x;return true;}});
  v.fetch=(u,o)=>fetch(B+u,o); v.requestAnimationFrame=()=>0; v.eval([...v.document.querySelectorAll('script')].map(x=>x.textContent).join('\n'));
  for(let i=0;i<50 && !v.eval('TL');i++) await sleep(100);
  ok(v.document.getElementById('rigmode').value==='live','rig picker defaults to "live (what the rig would do)"');
  v.document.getElementById('stagebtn').click(); for(let i=0;i<900 && !v.eval('!!(TL.rigLive && STG.on)');i++) await sleep(100);
  ok(v.eval('!!(TL.rig && TL.rig.live && STG.on)'),'stage view simulates the live engine first, then opens on it');
  const P=JSON.parse(v.eval('JSON.stringify({s:TL.rig.strobe,l:TL.rig.slvl,m:TL.rig.modeT,c:TL.rig.cols,h:TL.rig.hits})')), SB=JSON.parse(v.eval('JSON.stringify(TL.sec.bars)'));
  const firstPred=(P.m.find(x=>x[1]==='predictive')||[1e9])[0];
  console.log('   live preview: modes',P.m.map(x=>(x[0]/1000).toFixed(1)+':'+x[1]).slice(0,6).join(' '),'| flashes',P.s.length,'| wash changes',P.c.length,'| drop cues',P.h.map(h=>(h.t/1000).toFixed(1)).join(','));
  ok((P.m.find(x=>x[1]!=='idle')||[])[1]==='reactive' && firstPred<60000,'starts REACTIVE, goes PREDICTIVE at '+(firstPred/1000).toFixed(1)+' s');
  ok(P.s.filter(t=>t<firstPred).length>=6,'the intro strobes reactively before the engine has a grid ('+P.s.filter(t=>t<firstPred).length+' flashes)');
  const beats=[]; SB.forEach(b=>{ const L=(b.t1-b.t)/4; for(let q=0;q<4;q++) beats.push(b.t+q*L); });
  const q16=[]; beats.forEach((b,k)=>{ const nx=beats[k+1]||b+500; for(let j=0;j<4;j++) q16.push(b+(nx-b)*j/4); });
  const pred=P.s.filter(t=>t>=firstPred+2000 && !P.h.some(h=>t-h.t>=-50 && t-h.t<1200)), onb=pred.filter(t=>q16.some(b=>Math.abs(b-t)<=40)).length;   // 27g: ramps run on 8ths/16ths; drop bursts excluded
  ok(pred.length>100 && onb/pred.length>=0.9,'predictive flashes on the grid (beats, or 8ths/16ths in a ramp): '+onb+'/'+pred.length);
  ok(P.h.some(h=>Math.abs(h.t-88700)<1500) && P.h.some(h=>Math.abs(h.t-192100)<1500),'both drops cue live');
  ok(P.c.length>=8,'wash changes through the track ('+P.c.length+')');
  ok(P.s.every((t,i)=>!i || t-P.s[i-1]>=55),'never faster than the burst floor (~11/s; drop burst 70 ms)');   // 27g: bursts allowed (Mike)
  v.close(); console.log(`${n-fails}/${n} passed`); p.kill(); process.exit(fails?1:0);
})().catch(e=>{ console.log('ERR',e.stack); p.kill(); process.exit(2); });
