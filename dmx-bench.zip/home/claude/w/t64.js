// 27p: a strobe hit sets the strobe's colour to white when it's all-zero (otherwise it flashes dark); a chosen colour is kept
const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os'), dgram=require('dgram');
const FILE=process.argv[2]; const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx')); fs.copyFileSync(FILE,path.join(d,'artnet-controller.js'));
fs.writeFileSync(path.join(d,'settings.json'),JSON.stringify({targetIP:'127.0.0.2'}));
let last=null; const sock=dgram.createSocket({type:'udp4',reuseAddr:true}); sock.on('message',m=>{ if(m.length>=530 && m.toString('latin1',0,7)==='Art-Net' && m.readUInt16LE(14)===0) last=Buffer.from(m.subarray(18)); }); sock.bind(6454,'127.0.0.2');
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'}); const B='http://127.0.0.1:8080'; let n=0,f=0; const ok=(c,m)=>{n++; if(!c){f++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const post=(u,b)=>fetch(B+u,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)});
const ch=c=>last?last[c-1]:-1;
(async()=>{ await sleep(900);
  last=null; await post('/bridgehit',{strength:1,band:1}); await sleep(60);
  ok(ch(37)>0 && ch(38)===255 && ch(39)===255 && ch(40)===255,'fresh start, first hit: strobe lit AND white (dim '+ch(37)+', RGB '+[ch(38),ch(39),ch(40)]+')');
  await post('/dmx',{bulk:[[0,38,0],[0,39,0],[0,40,255]]}); await sleep(400);
  last=null; await post('/bridgehit',{strength:1,band:1}); await sleep(60);
  ok(ch(37)>0 && ch(38)===0 && ch(39)===0 && ch(40)===255,'a colour you picked is kept (RGB '+[ch(38),ch(39),ch(40)]+')');
  console.log(`${n-f}/${n} passed`); p.kill(); sock.close(); process.exit(f?1:0); })().catch(e=>{ console.log('ERR',e.stack); p.kill(); process.exit(2); });
