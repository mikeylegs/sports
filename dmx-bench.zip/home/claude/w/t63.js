// 27o kick-band migration: old default 40-120 or 27n's 120-300 -> 100-250 @ 1.6 once; hand-tuned bands untouched
const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2]; let n=0,f=0; const ok=(c,m)=>{n++; if(!c){f++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function boot(bands,extra){ const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx')); fs.copyFileSync(FILE,path.join(d,'artnet-controller.js'));
  if(bands) fs.writeFileSync(path.join(d,'bridge.json'),JSON.stringify(Object.assign({bands:bands},extra||{})));
  const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'}); await sleep(700);
  const j=JSON.parse(fs.readFileSync(path.join(d,'bridge.json'),'utf8')); p.kill(); await sleep(150); return j.bands[0]; }
const rest=[{lo:1000,hi:4000,sens:1.6},{lo:6000,hi:12000,sens:1.6},{lo:12000,hi:16000,sens:1.3}];
(async()=>{
  let b=await boot([{lo:40,hi:120,sens:1.5,target:'both'},...rest]); ok(b.lo===100 && b.hi===250 && b.sens===1.6,'old default 40-120 @1.5 -> 100-250 @1.6 ('+JSON.stringify(b)+')');
  b=await boot([{lo:40,hi:120,sens:2.2,target:'both'},...rest]); ok(b.lo===100 && b.sens===2.2,'hand-tuned sensitivity kept');
  b=await boot([{lo:120,hi:300,sens:1.8,target:'both'},...rest],{kick27n:true}); ok(b.lo===100 && b.hi===250 && b.sens===1.6,'27n 120-300 @1.8 -> 100-250 @1.6');
  b=await boot([{lo:60,hi:150,sens:1.7,target:'both'},...rest]); ok(b.lo===60 && b.hi===150,'custom band left alone');
  b=await boot([{lo:40,hi:120,sens:1.5,target:'both'},...rest],{kick27o:true}); ok(b.lo===40,'only once: moved back by hand, it stays');
  b=await boot(null); ok(b.lo===100 && b.hi===250 && b.sens===1.6,'fresh install: 100-250 @1.6');
  console.log(`${n-f}/${n} passed`); process.exit(f?1:0); })();
