// 28l: PAR brightness master + sensitivity (on the wire); NEXT COLOUR restarts the Pi's phrase count
const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os'), dgram=require('dgram');
const FILE=process.argv[2], SRC=fs.readFileSync(FILE,'utf8'); const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx')); fs.copyFileSync(FILE,path.join(d,'artnet-controller.js'));
fs.writeFileSync(path.join(d,'settings.json'),JSON.stringify({targetIP:'127.0.0.2'}));
let last=null; const sock=dgram.createSocket({type:'udp4',reuseAddr:true}); sock.on('message',m=>{ if(m.length>=530 && m.toString('latin1',0,7)==='Art-Net' && m.readUInt16LE(14)===0) last=Buffer.from(m.subarray(18)); }); sock.bind(6454,'127.0.0.2');
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'}); const B='http://127.0.0.1:8080'; let n=0,f=0; const ok=(c,m)=>{n++; if(!c){f++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const post=(u,b)=>fetch(B+u,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)}); const ch=c=>last?last[c-1]:-1;
const snapBody={levels:[0.4,0,0,0],active:[true,false,false,false],hits:[1,0,0,0],recording:true,build:'x',live:{beatMs:480,nextBeatIn:100,pb:3,groove:true,mode:'heavy',slvl:1,kickOn:true,hatsOn:false,washIdx:2,washNextIn:9000,bpm:125}};
const level=async k=>{ for(let i=0;i<12;i++){ await post('/lv',{k:k}); if(i%4===0) await post('/bridgestate',snapBody); await sleep(30); } await sleep(150); return ch(88); };
(async()=>{ await sleep(900); await post('/liveshow',{enabled:true});
  let c=await (await fetch(B+'/liveshow')).json(); ok(c.parMax===100 && c.parSens==='med','defaults: brightness 100%, sensitivity MED');
  await level(0.6); const full=await level(0.6); await post('/liveshow',{parMax:50}); await sleep(400); const half=ch(88);
  ok(full>150 && Math.abs(half-Math.round(full/2))<=3,'brightness 50%: the PAR dimmer is halved on the wire ('+full+' -> '+half+')');
  await post('/liveshow',{parMax:100});
  // sensitivity: a modest level relative to the peak
  await level(0.6); const medLo=await level(0.25); await post('/liveshow',{parSens:'low'}); await level(0.6); const lowLo=await level(0.25); await post('/liveshow',{parSens:'high'}); await level(0.6); const hiLo=await level(0.25);
  ok(lowLo<medLo && medLo<hiLo,'sensitivity: the same modest bass gives LOW '+lowLo+' < MED '+medLo+' < HIGH '+hiLo);
  await post('/liveshow',{parSens:'med'});
  // NEXT COLOUR -> the Pi gets a one-shot command in its /bridgestate reply
  const r1=await (await post('/cc/next',{})).json(); const rep=await (await post('/bridgestate',snapBody)).json(); const rep2=await (await post('/bridgestate',snapBody)).json();
  ok(rep.cmd && rep.cmd.next===r1.wash.idx && !rep2.cmd,'NEXT COLOUR: the Pi is told once (colour '+(rep.cmd&&rep.cmd.next)+')');
  const LJ=(SRC.match(/const LIVE_JS = `([\s\S]*?)`;/)||[])[1]; const G={}; new Function('G',LJ+'\nG.LE=LiveEngine;')(G);
  const E=Object.create(G.LE.prototype); E.wash={idx:3,cueT:null,next:50000}; E.r={bpm:120,bars:[{t:0,t1:2000,pb:1,st:'G'}]}; E.lastBarAt=()=>({t:40000,t1:42000,pb:5});
  E.manualNext(45000,4); E.washTick(45100); ok(E.wash.idx===4 && Math.abs(E.wash.next-(45000+32*500))<=2000,'the Pi engine: that colour, next change 8 bars after the press, snapped to a bar line ('+E.wash.next+')');
  const html=await (await fetch(B+'/cc')).text(); ok((html.match(/data-pm="/g)||[]).length===4 && (html.match(/data-psn="/g)||[]).length===3 && /restarts phrase/.test(html),'Command Center Setup: brightness + sensitivity; NEXT COLOUR says it restarts the phrase');
  await post('/liveshow',{enabled:false}); console.log(`${n-f}/${n} passed`); p.kill(); sock.close(); process.exit(f?1:0); })().catch(e=>{ console.log('ERR',e.stack); p.kill(); process.exit(2); });
