// Sandstorm (ZANS Edit): wash follows the phrase cycle through the late-kick drop; strobe only on the beat
const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2]; const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx'));
fs.copyFileSync(FILE,path.join(d,'artnet-controller.js')); fs.mkdirSync(path.join(d,'logs'));
fs.copyFileSync('/mnt/user-data/uploads/track-37199921-932496.ndjson',path.join(d,'logs','track-37199921-932496.ndjson')); fs.mkdirSync(path.join(d,'tracks')); fs.writeFileSync(path.join(d,'tracks','Darude - Sandstorm (ZANS Edit) Supported by Layton Giordani, Meduza, Morten.m4a'),Buffer.alloc(100));
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'});
const B='http://127.0.0.1:8080'; let fails=0,n=0; const ok=(c,m)=>{n++; if(!c){fails++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{ await sleep(800); const {JSDOM}=require('jsdom');
  const v=new JSDOM(await (await fetch(B+'/logs/track-37199921-932496.ndjson')).text(),{runScripts:'outside-only',url:B+'/logs/x'}).window;
  v.HTMLCanvasElement.prototype.getContext=()=>new Proxy({},{get:(t,k)=>k==='measureText'?()=>({width:0}):(k in t?t[k]:()=>{}),set:(t,k,x)=>{t[k]=x;return true;}});
  v.fetch=(u,o)=>fetch(B+u,o); v.requestAnimationFrame=()=>0; v.eval([...v.document.querySelectorAll('script')].map(x=>x.textContent).join('\n'));
  for(let i=0;i<50 && !v.eval('TL');i++) await sleep(100);
  const R=JSON.parse(v.eval('JSON.stringify({cols:TL.rig.cols,strobe:TL.rig.strobe,bars:TL.rig.bars})')), SB=JSON.parse(v.eval('JSON.stringify(TL.sec.bars)'));
  const near=t=>R.cols.some(c=>Math.abs(c[0]-t)<=300);
  ok([60100,75200,90200,105200].every(near),'first half: wash on the marked phrase grid (1:00, 1:15, 1:30, 1:45)');
  ok([120300,135200,150200,165100,180100,195100].every(near),'after the 3.7 s pause the phrase count carries on: 2:00, 2:15, 2:30, 2:45 (the kick drop), 3:00, 3:15 ('+R.cols.map(c=>(c[0]/1000).toFixed(1)).join(',')+')');
  ok(JSON.parse(v.eval('JSON.stringify(TL.sec.drops)')).some(t=>Math.abs(t-165100)<300) && JSON.parse(v.eval('JSON.stringify(TL.sec.carried)')).length===1,'the second drop (2:45) is found now that the count is carried');
  ok(R.strobe.every(t=>{ const b=SB.find(x=>t>=x.t-90&&t<x.t1-90), L=(b.t1-b.t)/4, ph=(((t-b.t)%L)+L)%L; return Math.min(ph,L-ph)<=5; }),'every strobe flash on a beat ('+R.strobe.length+')');
  // stage view: controls stay until the empty stage is tapped
  v.document.getElementById('stagebtn').click(); v.eval('stagePaint(100000)'); const hud=v.document.getElementById('stHud'), wave=v.document.getElementById('stWave');
  const aud=v.document.getElementById('aud'); Object.defineProperty(aud,'paused',{get:()=>false}); v.eval('STG.hudT=Date.now()-10000; stageTick && 0');
  v.eval('STG.on=true; stagePaint(100000); (function(){ var hud=document.getElementById("stHud"); })()');
  v.eval('stageTick()'); ok(hud.style.opacity==='1' && wave.style.opacity==='1','playing 10 s untouched: controls still visible');
  v.document.getElementById('stage').dispatchEvent(new v.MouseEvent('click',{bubbles:true})); v.eval('stageTick()'); ok(hud.style.opacity==='0' && wave.style.opacity==='0' && wave.style.pointerEvents==='none','tap the empty stage: hidden');
  v.document.getElementById('stage').dispatchEvent(new v.MouseEvent('click',{bubbles:true})); v.eval('stageTick()'); ok(hud.style.opacity==='1','tap again: back');
  v.document.getElementById('rigmode').dispatchEvent(new v.MouseEvent('click',{bubbles:true})); v.eval('stageTick()'); ok(hud.style.opacity==='1','using the rig picker does not hide them');
  v.close(); console.log(`${n-fails}/${n} passed`); p.kill(); process.exit(fails?1:0);
})().catch(e=>{ console.log('ERR',e.stack); p.kill(); process.exit(2); });
