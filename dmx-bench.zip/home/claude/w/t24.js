const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2]; const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx'));
fs.copyFileSync(FILE,path.join(d,'artnet-controller.js'));
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'});
const B='http://127.0.0.1:8080'; let fails=0,n=0; const ok=(c,m)=>{n++; if(!c){fails++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{ await sleep(800); const {JSDOM}=require('jsdom');
  for(const pg of ['/console','/bridge']){
    const w=new JSDOM(await (await fetch(B+pg)).text(),{runScripts:'outside-only',url:B+pg}).window; w.fetch=(u,o)=>fetch(B+u,o); w.requestAnimationFrame=()=>0;
    Object.defineProperty(w.navigator,'mediaDevices',{value:{getUserMedia:()=>new Promise(()=>{})}});
    const b0=w.document.getElementById('lpow'); ok(!!b0,pg+': Link power button'); if(!b0){ w.close(); continue; }
    w.eval(w.document.querySelector('script:not([data-nl])').textContent); await sleep(500);
    const b=w.document.getElementById('lpow'), a=w.document.getElementById('lagent');
    ok(/ON/.test(b.textContent) && (pg!=='/console' || /supervisor not reporting/.test(a.textContent)),pg+': ON'+(pg==='/console'?', supervisor missing explained':''));
    await fetch(B+'/linkctl/agent',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({running:true,log:'link up, 1 peer'})});
    b.click(); await sleep(400);
    const c=await (await fetch(B+'/linkctl')).json(); ok(c.want===false && /OFF/.test(b.textContent),pg+': click switches OFF on the server');
    await fetch(B+'/linkctl/agent',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({running:false,log:'stopping link_bridge.py'})});
    w.eval('linkCtlPoll()'); await sleep(300); ok(/reader off/.test(a.textContent) && /stopping link_bridge/.test(a.textContent) && a.querySelector('.bad'),pg+': shows reader off (red) + last log');
    ok(/ off/.test(b.className),pg+': OFF button red');
    await sleep(400); ok(/^off$/.test(w.document.getElementById('lst').textContent) && w.document.getElementById('lst').querySelector('span').getAttribute('style').includes('--bad'),pg+': Link panel says off in red, no amber warning');
    b.click(); await sleep(400); ok((await (await fetch(B+'/linkctl')).json()).want===true,pg+': click back ON');
    w.close(); }
  console.log(`${n-fails}/${n} passed`); p.kill(); process.exit(fails?1:0);
})().catch(e=>{ console.log('ERR',e.message); p.kill(); process.exit(2); });
