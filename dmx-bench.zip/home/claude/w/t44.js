const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os');
const FILE=process.argv[2]; const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx'));
fs.copyFileSync(FILE,path.join(d,'artnet-controller.js')); fs.mkdirSync(path.join(d,'logs'));
fs.copyFileSync('/mnt/user-data/uploads/track-52285985-558042.ndjson',path.join(d,'logs','track-52285985-558042.ndjson'));
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'});
const B='http://127.0.0.1:8080'; let fails=0,n=0; const ok=(c,m)=>{n++; if(!c){fails++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{ await sleep(800); const {JSDOM}=require('jsdom');
  const pages=['/','/lab','/lab/show','/lab/mark','/lab/tracks','/lab/recordings','/lab/link','/lab/phrasetest','/logs/track-52285985-558042.ndjson','/perform','/react'];
  { const ch=await (await fetch(B+'/console')).text(); ok(!/id="mtrig"/.test(ch),'/console: no fog button'); }
  for(const u of pages){ const h=await (await fetch(B+u)).text(); const c=(h.match(/id="mtrig"/g)||[]).length;
    const scripts=[...h.matchAll(/<script>([\s\S]*?)<\/script>/g)]; let perr=null; scripts.forEach(m=>{ try{ new Function(m[1]); }catch(e){ perr=e.message; } });
    ok(c===1 && !perr, u+': one fog button'+(perr?' (script error: '+perr+')':'')+' ['+c+']'); }
  const vh=await (await fetch(B+'/logs/track-52285985-558042.ndjson')).text(); ok(/\.mtrig\{z-index:80\}/.test(vh),'viewer: fog button sits above the stage view');
  for(const u of ['/lab','/','/logs/track-52285985-558042.ndjson','/react','/perform']){
    const w=new JSDOM(await (await fetch(B+u)).text(),{runScripts:'outside-only',url:B+u,pretendToBeVisual:true}).window; const posts=[];
    w.HTMLCanvasElement.prototype.getContext=()=>new Proxy({},{get:(t,k)=>k==='measureText'?()=>({width:0}):(k in t?t[k]:()=>{}),set:(t,k,x)=>{t[k]=x;return true;}});
    w.fetch=(url,o)=>{ if(url==='/dmx') posts.push(JSON.parse(o.body)); return fetch(B+url,o); }; w.requestAnimationFrame=()=>0;
    if(!w.PointerEvent) w.PointerEvent=w.MouseEvent;
    [...w.document.querySelectorAll('script')].forEach(s=>{ try{ w.eval(s.textContent); }catch(e){} });
    const b=w.document.getElementById('mtrig'); b.setPointerCapture=()=>{}; b.releasePointerCapture=()=>{};
    Object.defineProperty(w,'innerWidth',{value:390,configurable:true}); Object.defineProperty(w,'innerHeight',{value:844,configurable:true});
    const cfg=w.eval('JSON.stringify(window.FOG_DEFAULT_DOCK||null)'); ok(/"side":"right","fixed":true/.test(cfg),u+': docks on the right, fixed (like Performance) '+cfg);
    ok(w.document.getElementById('mtrig').classList.contains('docked-right') && !w.localStorage.getItem('artnetFogPos'),u+': resting docked right, position not remembered');
    b.dispatchEvent(new w.MouseEvent('pointerdown',{bubbles:true})); await sleep(20); ok(!posts.length,u+': docked nub never fires');
    b.dispatchEvent(new w.MouseEvent('click',{bubbles:true})); await sleep(20);   // tap to reveal, as on Performance
    b.dispatchEvent(new w.MouseEvent('pointerdown',{bubbles:true,clientX:10,clientY:10})); await sleep(50);
    b.dispatchEvent(new w.MouseEvent('pointerup',{bubbles:true,clientX:10,clientY:10})); await sleep(50);
    ok(posts.length>=2 && JSON.stringify(posts[0].bulk)==='[[0,64,255],[0,81,255]]' && JSON.stringify(posts[posts.length-1].bulk)==='[[0,64,0],[0,81,0]]',u+': hold = both fog machines on, release = off ('+posts.map(x=>JSON.stringify(x.bulk)).join(' ')+')');
    w.close(); }
  console.log(`${n-fails}/${n} passed`); p.kill(); process.exit(fails?1:0);
})().catch(e=>{ console.log('ERR',e.stack); p.kill(); process.exit(2); });
