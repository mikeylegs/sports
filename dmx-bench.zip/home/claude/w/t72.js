// 27x: one show config -- mutes/solo on the wire, laser energy/scenes + power map on the mini PC, React page sync
const {spawn}=require('child_process'), fs=require('fs'), path=require('path'), os=require('os'), dgram=require('dgram');
const FILE=process.argv[2]; const d=fs.mkdtempSync(path.join(os.tmpdir(),'dmx')); fs.copyFileSync(FILE,path.join(d,'artnet-controller.js'));
fs.writeFileSync(path.join(d,'settings.json'),JSON.stringify({targetIP:'127.0.0.2',kasa:[{ip:'10.0.0.9',childId:null,alias:'Govee strip'},{ip:'10.0.0.8',childId:'01',alias:'Fog'}]}));
let last=null; const sock=dgram.createSocket({type:'udp4',reuseAddr:true}); sock.on('message',m=>{ if(m.length>=530 && m.toString('latin1',0,7)==='Art-Net' && m.readUInt16LE(14)===0) last=Buffer.from(m.subarray(18)); }); sock.bind(6454,'127.0.0.2');
const p=spawn('node',['artnet-controller.js'],{cwd:d,stdio:'ignore'}); const B='http://127.0.0.1:8080'; let n=0,f=0; const ok=(c,m)=>{n++; if(!c){f++; console.log('FAIL',m);} }; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const post=(u,b)=>fetch(B+u,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)});
const ch=c=>last?last[c-1]:-1; const cfg=async()=>(await fetch(B+'/showcfg')).json();
(async()=>{ await sleep(900);
  let c=await cfg(); ok(c.mutes && c.mutes.strobe===false && c.solo===null && c.power && c.power.par1===null,'defaults: nothing muted, no solo, PAR plugs not assigned yet');
  ok(c.power.govee && c.power.govee.ip==='10.0.0.9','Govee plug found by its name and assigned');
  await post('/dmx',{bulk:[[0,37,255],[0,41,200],[0,88,180],[0,95,170],[0,1,60],[0,82,255]]}); await sleep(600);
  ok(ch(37)===255 && ch(88)===180 && ch(1)===60,'live values out');
  await post('/showcfg',{mutes:{strobe:true}}); await sleep(600);
  ok(ch(37)===0 && ch(41)===0 && ch(88)===180 && ch(1)===60,'mute strobe: strobe dark on the wire, everything else untouched');
  await post('/showcfg',{mutes:{strobe:false}}); await sleep(600); ok(ch(37)===255 && ch(41)===200,'unmute: the strobe\'s live values come straight back');
  await post('/showcfg',{solo:'par1'}); await sleep(600); ok(ch(88)===180 && ch(82)===255 && ch(95)===0 && ch(37)===0 && ch(1)===0,'solo PAR 1: only PAR 1 lit (its colour kept)');
  await post('/showcfg',{solo:null}); await sleep(600); ok(ch(95)===170 && ch(1)===60,'solo off: all back');
  ok((await post('/showcfg',{solo:'nope'})).status===400,'bad solo rejected');
  await post('/showcfg',{power:{par1:{ip:'10.0.0.7',childId:'02'}}}); c=await cfg(); ok(c.power.par1 && c.power.par1.childId==='02','assign a PAR plug later (slot ready)');
  // React page hands its browser-saved energy channels + scenes to the mini PC
  const {JSDOM}=require('jsdom'); const html=await (await fetch(B+'/react')).text();
  const v=new JSDOM(html,{runScripts:'outside-only',url:B+'/react'}).window;
  v.localStorage.setItem('artnetEnergySlots',JSON.stringify({ids:[1],nextId:2,values:{1:{ch:'5',base:'10',peak:'90'}}}));
  v.localStorage.setItem('artnetEnergyScenes',JSON.stringify({checked:['s1'],mode:'seq',fire:'stay',noRepeat:true,enabled:true,chEnabled:true}));
  v.fetch=(u,o)=>fetch(B+u,o); v.requestAnimationFrame=()=>0; v.HTMLCanvasElement.prototype.getContext=()=>null;
  try{ v.eval([...v.document.querySelectorAll('script')].map(x=>x.textContent).join('\n')); }catch(e){ console.log('   (react page eval: '+e.message+')'); }
  await sleep(1200); c=await cfg();
  ok(c.laser.energy && c.laser.energy.values && c.laser.energy.values[1] && c.laser.energy.values[1].ch==='5','React page: this phone\'s energy channels now live on the mini PC');
  ok(c.laser.scenes && c.laser.scenes.checked && c.laser.scenes.checked[0]==='s1','React page: energy scenes too');
  const saved=JSON.parse(fs.readFileSync(path.join(d,'liveshow.json'),'utf8')); ok(saved.power.par1 && saved.laser.energy,'all of it persisted in liveshow.json');
  v.close(); console.log(`${n-f}/${n} passed`); p.kill(); sock.close(); process.exit(f?1:0); })().catch(e=>{ console.log('ERR',e.stack); p.kill(); process.exit(2); });
