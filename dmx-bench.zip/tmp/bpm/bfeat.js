// per-bar build cues on the master-tempo grid; how well does each separate "last 8 bars before a drop" from "far from drops"?
const fs=require('fs'); const TT=require('./tt3.js'); const TRK=[['dare',134.03],['meduza',126],['deceiver',126.98],['vision',130.05],['espresso',126],['dtmf',130],['dolce',130]];
function auc(pos,neg){ let s=0; pos.forEach(p=>neg.forEach(q=>{ s+=p>q?1:(p===q?0.5:0); })); return s/(pos.length*neg.length||1); }
const F={}; const add=(k,v,lab)=>{ (F[k]=F[k]||{p:[],n:[]})[lab].push(v); };
for(const [n,bpm] of TRK){ const L=JSON.parse(fs.readFileSync('/tmp/red/'+n+'.lv.json')); const N=L.ticks[0].length, tt=new TT({fw:2.5,w:[1,0.3,0.2,0,0,0],W2:30,WS:10,jumpN:2});
  const K=JSON.parse(fs.readFileSync('/tmp/'+n+'Kick.json')).map(x=>x*1000), beat=60000/bpm, D=K.filter((k,q)=>q>0 && k-K[q-1]>=16*beat && k>5000);
  // bar boundaries every 4 beats of the tracker (causal counter as in db.js)
  let lastBeat=null, bidx=0; const bars=[]; let cur=null;
  const lvl=(b,k)=>L.ticks[b][k]||0; let prevX=[0,0,0,0,0,0];
  for(let k=0;k<N;k++){ tt.feed([0,1,2,3,4,5].map(i=>lvl(i,k))); const t=k*1000/60;
    if(tt.bpm && tt.phaseAtK!=null){ const P=60000/tt.bpm, bt=(tt.phaseAtK+1)*1000/60-16;
      if(lastBeat===null) lastBeat=bt+Math.floor((t-bt)/P)*P; else if(t>=lastBeat+P-8){ let nx=lastBeat+P; const near=bt+Math.round((nx-bt)/P)*P; if(Math.abs(near-nx)<P*0.25) nx+=0.5*(near-nx); lastBeat=nx; bidx++;
        if(bidx%4===0){ if(cur) bars.push(cur); cur={t:lastBeat, e:[0,0,0,0,0,0], on:[0,0,0,0,0,0], n:0}; } } }
    if(cur){ cur.n++; for(let b=0;b<6;b++){ const x=Math.log(1+200*lvl(b,k)); cur.e[b]+=lvl(b,k); if(x-prevX[b]>0.35) cur.on[b]++; prevX[b]=x; } } }
  bars.forEach(b=>{ b.e=b.e.map(x=>x/Math.max(1,b.n)); });
  for(let i=4;i<bars.length;i++){ const b=bars[i], h=bars.slice(i-4,i+1); const lab=process.env.LAB==='late'?(D.some(x=>x>b.t && x-b.t<=4*4*beat+50)?'p':(D.some(x=>x-b.t>8*4*beat && x-b.t<=24*4*beat)?'n':null)):(D.some(x=>x>b.t && x-b.t<=8*4*beat+50)?'p':(D.every(x=>Math.abs(x-b.t)>16*4*beat)?'n':null)); if(!lab) continue;
    const slope=k=>{ const y=h.map(z=>Math.log(1e-4+z.e[k])); return (y[4]-y[0]); }, oslope=k=>h[4].on[k]-h[0].on[k];
    add('clap onsets per bar',b.on[1],lab); add('clap onset rise over 4 bars',oslope(1),lab); add('hats onset rise',oslope(2),lab);
    add('air level rise (riser)',slope(3),lab); add('hats level rise',slope(2),lab); add('sub level fall',-slope(4),lab); add('kick level fall',-slope(0),lab);
    add('brightness rise (air+hats vs sub)',(slope(3)+slope(2))/2-slope(4),lab); add('brightness now',Math.log((b.e[2]+b.e[3]+1e-4)/(b.e[4]+1e-4)),lab); }
}
Object.keys(F).map(k=>[k,auc(F[k].p,F[k].n),F[k].p.length,F[k].n.length]).sort((a,b)=>b[1]-a[1]).forEach(r=>console.log(r[1].toFixed(2),r[0],'(pre-drop bars '+r[2]+', far bars '+r[3]+')'));
