// downbeat ("the 1") detector research: per-beat band onsets folded into a 4-beat cycle; scored vs the drops (drops land on a 1)
const fs=require('fs'); const TT=require('./tt2.js');
const TRK=['dare','meduza','deceiver','vision','espresso','dtmf','dolce']; const TRUTH=JSON.parse(fs.readFileSync('/tmp/bpm/truth.json'));
const W=JSON.parse(process.env.W||'{"clap":1,"sub":0.5,"air":0.5,"low":0.3,"kick":0}'), HL=+(process.env.HL||8);
function nov(L,b,k){ const x=Math.log(1+200*(L.ticks[b][k]||0)); let m=0,c=0; for(let j=1;j<=3;j++){ if(k-j>=0){ m+=Math.log(1+200*(L.ticks[b][k-j]||0)); c++; } } return Math.max(0,x-(c?m/c:x)); }
let tot={ok:0,n:0}; const rows=[];
for(const n of TRK){ const L=JSON.parse(fs.readFileSync('/tmp/red/'+n+'.lv.json')); const N=L.ticks[0].length; const tt=new TT({fw:2.5,w:[1,0.3,0.2,0,0,0],W2:30});
  // causal: beats from the live tracker; per beat, band onset strength in the 0-100 ms after the beat
  const S={clap:[0,0,0,0],sub:[0,0,0,0],air:[0,0,0,0],low:[0,0,0,0],kick:[0,0,0,0],hat:[0,0,0,0]}; let lastBeat=null, bidx=0, P=null, decisions=[];
  const decay=Math.pow(0.5,1/(4*HL));
  for(let k=0;k<N;k++){ tt.feed([0,1,2,3,4,5].map(i=>L.ticks[i][k]||0)); const t=k*1000/60;
    if(tt.bpm && tt.phaseAtK!=null){ P=60000/tt.bpm; const bt=(tt.phaseAtK+1)*1000/60-16;
      // own beat counter: step one beat at a time, nudged onto the tracker's nearest beat (never skips / doubles)
      if(lastBeat===null){ lastBeat=bt+Math.floor((t-bt)/P)*P; }
      else if(t>=lastBeat+P-1000/120){ let nxt=lastBeat+P; const near=bt+Math.round((nxt-bt)/P)*P; if(Math.abs(near-nxt)<P*0.25) nxt=nxt+0.5*(near-nxt); lastBeat=nxt; bidx++; }
      if(t-lastBeat>=100 && t-lastBeat<100+1000/60){ const k0=Math.round((lastBeat)*60/1000); const p=bidx%4; const f={clap:0,sub:0,air:0,low:0,kick:0,hat:0};
        for(let j=k0;j<k0+6 && j<N;j++){ f.kick+=nov(L,0,j); f.clap+=nov(L,1,j); f.hat+=nov(L,2,j); f.air+=nov(L,3,j); f.sub+=nov(L,4,j); f.low+=nov(L,5,j); }
        for(const key in S){ for(let q=0;q<4;q++) S[key][q]*=decay; S[key][p]+=f[key]; }
        // score each candidate "1" (q = beat index mod 4 that is the downbeat)
        const nz=a=>{ const m=(a[0]+a[1]+a[2]+a[3])/4+1e-9; return a.map(x=>x/m); }; const C=nz(S.clap), SB=nz(S.sub), A=nz(S.air), LO=nz(S.low), KI=nz(S.kick);
        // stage 1: claps on 2 & 4 -> which half-bar pair {q, q+2} holds the 1 ; stage 2: the other cue picks 1 vs 3
        const par=(C[1]+C[3]-C[0]-C[2])>0?0:1;   // claps strongest on odd phases -> the 1 is on an even phase (0 or 2)
        const cue=q=>W.sub*SB[q]+W.air*A[q]+W.low*LO[q]+W.kick*KI[q];
        const bq=cue(par)>=cue(par+2)?par:par+2;
        decisions.push({t:lastBeat, idx:bidx, q:bq, P, C:C.map(x=>+x.toFixed(2)), SB:SB.map(x=>+x.toFixed(2))}); } } }
  // truth near each drop: the drop's beat index (mod 4) is the 1; judge decisions within 16 beats before .. 16 after
  let ok=0,cnt=0,okh=0; TRUTH[n].drops.forEach(dr=>{ if(n==='dare' && dr.d<85000) return; const dd=decisions.filter(x=>Math.abs(x.t-dr.d)<16*x.P); const at=dd.find(x=>Math.abs(x.t-dr.d)<x.P/2); if(!at) return; const q1=at.idx%4;
    dd.forEach(x=>{ cnt++; if(x.q===q1) ok++; if(x.q%2===q1%2) okh++; }); });
  if(process.env.DBG===n) TRUTH[n].drops.forEach(dr=>{ const at=decisions.find(x=>Math.abs(x.t-dr.d)<x.P/2); if(at) console.log('  drop',(dr.d/1000).toFixed(1),'beat idx',at.idx,'truth q',at.idx%4,'chosen',at.q,'clap by phase',JSON.stringify(at.C),'sub',JSON.stringify(at.SB)); });
  tot.ok+=ok; tot.n+=cnt; tot.h=(tot.h||0)+okh; rows.push(n+' '+(cnt?Math.round(100*okh/cnt)+'/'+Math.round(100*ok/cnt):'-')+'%');
}
console.log(JSON.stringify(W),'| half-bar (claps) right '+Math.round(100*tot.h/tot.n)+'% | the 1 right '+Math.round(100*tot.ok/tot.n)+'% | per track half/full: '+rows.join(' '));
