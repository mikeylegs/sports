const fs=require('fs'); const TT=require('./tt3.js');
const TR=[['dare',134.03],['meduza',126],['deceiver',126.98],['vision',130.05],['espresso',126],['dtmf',130],['dolce',130]];
const O=JSON.parse(process.env.OPT||'{}'); let all=[];
for(const [n,bpm] of TR){ const L=JSON.parse(fs.readFileSync('/tmp/red/'+n+'.lv.json')); const K=JSON.parse(fs.readFileSync('/tmp/'+n+'Kick.json')).map(x=>x*1000);
  const tt=new TT(O), N=L.ticks[0].length, ev=[]; let lock=null;
  for(let k=0;k<N;k++){ const b=tt.feed([0,1,2,3,4,5].map(i=>L.ticks[i][k]||0)); if(k%30===0 && b){ const t=k*1000/60; ev.push([t,b,tt.phaseAtK]); } }
  const truth=t=>n==='dare'?(t<55000?132.0:(t>85000?134.0:null)):bpm;   // Dare changes tempo: 132 -> 134 (verified from the audio, section by section)
  const evs=ev.filter(e=>truth(e[0])!=null); const within=(e,p)=>Math.abs(e[1]-truth(e[0]))/truth(e[0])<=p;
  const w01=evs.filter(e=>within(e,0.001)).length/Math.max(1,evs.length), w05=evs.filter(e=>within(e,0.005)).length/Math.max(1,evs.length);
  for(let i=0;i<evs.length;i++){ const nxt=evs.slice(i,i+40); if(nxt.length>=10 && nxt.filter(e=>within(e,0.005)).length>=0.9*nxt.length){ lock=evs[i][0]/1000; break; } }
  // phase: predicted beats (from the estimate's phase) vs true kicks in the next 2 s
  const pe=[]; ev.forEach(e=>{ if(e[2]==null) return; const P=60000/e[1], t0=e[2]*1000/60; for(let j=1;j<=4;j++){ const tb=t0+j*P; const kk=K.find(x=>Math.abs(x-tb)<P/2); if(kk!=null) pe.push(tb-kk); } });
  pe.sort((a,b)=>Math.abs(a)-Math.abs(b)); const med=pe.length?Math.abs(pe[Math.floor(pe.length/2)]):null;
  const first=ev.length?ev[0][0]/1000:null; all.push([n,w01,w05,lock,med]);
  console.log(n.padEnd(9)+' true '+(n==='dare'?'132>134':bpm.toFixed(2))+' | first '+(first==null?'-':first.toFixed(1)+'s')+' lock '+(lock==null?'never':lock.toFixed(1)+'s')+' | within 0.1%: '+Math.round(w01*100)+'%  0.5%: '+Math.round(w05*100)+'% | beat phase vs true kicks: median '+(med==null?'-':med.toFixed(0)+' ms')+' | median est '+(ev.length?ev.map(e=>e[1]).sort((a,b)=>a-b)[ev.length>>1].toFixed(2):'-'));
}
