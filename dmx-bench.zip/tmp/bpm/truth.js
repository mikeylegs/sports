// answer key: beat grid from the master tempo (offline, full track) + downbeat phase from the drops (drops land on a "1")
const fs=require('fs'); const TT=require('./tt2.js');
const TR={dare:[134.03],meduza:[126],deceiver:[126.98],vision:[130.05],espresso:[126],dtmf:[130],dolce:[130]};
const out={};
for(const n of Object.keys(TR)){ const L=JSON.parse(fs.readFileSync('/tmp/red/'+n+'.lv.json')); const tt=new TT({fw:2.5,w:[1,0.3,0.2,0,0,0],W2:30}); const N=L.ticks[0].length, beats=[];
  let lastBT=null; for(let k=0;k<N;k++){ tt.feed([0,1,2,3,4,5].map(i=>L.ticks[i][k]||0)); if(tt.bpm && tt.phaseAtK!=null && k%30===0){ beats.push({t:k*1000/60, bpm:tt.bpm, bt:(tt.phaseAtK+1)*1000/60-16}); } }
  const K=JSON.parse(fs.readFileSync('/tmp/'+n+'Kick.json')).map(x=>x*1000), beat=60000/TR[n][0];
  const D=K.filter((k,i)=>i>0 && k-K[i-1]>=16*beat && k>5000);
  // for each drop: which beat index (mod 4) of the tracker grid it sits on, measured from a common origin
  const rows=D.map(d=>{ const b=beats.filter(x=>x.t<=d+2000).pop(); if(!b) return null; const P=60000/b.bpm, idx=Math.round((d-b.bt)/P); return {d, idx, P, bt:b.bt, err:(d-(b.bt+idx*P))}; }).filter(Boolean);
  out[n]={drops:rows};
  console.log(n.padEnd(9)+' drops '+rows.map(r=>(r.d/1000).toFixed(1)+'s').join(', '));
}
fs.writeFileSync('/tmp/bpm/truth.json',JSON.stringify(out));
