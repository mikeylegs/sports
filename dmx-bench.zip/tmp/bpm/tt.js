// Master tempo prototype (causal). feed(levels6) every 60 Hz tick -> {bpm, phaseMs, conf}
function TempoTracker(o){ o=o||{}; this.fs=60; this.W1=o.W1||10; this.W2=o.W2||20; this.every=o.every||30; this.w=o.w||[1,0.5,0.35,0,0.3,0];
  this.env=[]; this.prev=[]; this.hist=[]; this.k=0; this.bpm=null; this.cand=null; this.candN=0; this.phase=null; this.conf=0; this.smooth=o.smooth||0.35; this.lo=o.lo||95; this.hi=o.hi||160; this.prior=o.prior!==false; this.fw=o.fw||1; }
TempoTracker.prototype.feed=function(lv){ var nov=0;
  for(var b=0;b<6;b++){ if(!this.w[b]) continue; var x=Math.log(1+200*(lv[b]||0)); var h=this.prev[b]||(this.prev[b]=[]); var m=h.length?(h.reduce(function(a,c){return a+c;},0)/h.length):x; nov+=this.w[b]*Math.max(0,x-m); h.push(x); if(h.length>3) h.shift(); }
  this.env.push(nov); var maxN=this.fs*this.W2+10; if(this.env.length>maxN) this.env.shift(); this.k++;
  if(this.k%this.every===0 && this.env.length>=this.fs*6) this.estimate(); return this.bpm; };
TempoTracker.prototype.score=function(P, W, retPh){ var E=this.env, N=E.length, n0=Math.max(0,N-Math.round(W*this.fs)), best=-1, bph=0;
  var val=function(i){ var i0=Math.floor(i), f=i-i0; if(i0<n0||i0+1>=N) return 0; return (E[i0]*(1-f)+E[i0+1]*f)+0.5*((E[i0-1]||0)+(E[i0+2]||0)); };
  for(var ph=0; ph<P; ph+=0.5){ var s=0, c=0; for(var t=N-1-ph; t>=n0+1; t-=P){ s+=val(t); c++; } if(c<4) continue; s/=c; if(s>best){ best=s; bph=ph; } }
  var mean=0; for(var i=n0;i<N;i++) mean+=E[i]; mean/=Math.max(1,N-n0); return retPh?{s:best/(mean*2+1e-9), ph:bph}:best/(mean*2+1e-9); };
TempoTracker.prototype.estimate=function(){ var bestB=0, bestS=-1, P, s;
  for(var bpm=this.lo; bpm<=this.hi; bpm+=0.5){ P=3600/bpm; s=this.score(P,this.W1); if(this.prior) s*=Math.exp(-0.5*Math.pow(Math.log2(bpm/126)/0.35,2)); if(s>bestS){ bestS=s; bestB=bpm; } }
  var fb=bestB, fs=-1, fph=0; var FW=this.fw||1; for(var b2=bestB-FW; b2<=bestB+FW; b2+=0.02){ var r=this.score(3600/b2,this.W2,true); if(r.s>fs){ fs=r.s; fb=b2; fph=r.ph; } }
  this.conf=fs; if(fs<1.15) return;   /* no clear pulse (breakdown): hold */
  if(this.bpm==null){ if(this.cand!=null && Math.abs(fb-this.cand)/this.cand<0.005){ if(++this.candN>=2){ this.bpm=fb; } } else { this.cand=fb; this.candN=1; } }
  else if(Math.abs(fb-this.bpm)/this.bpm<0.015) this.bpm+= this.smooth*(fb-this.bpm);
  else { if(this.cand!=null && Math.abs(fb-this.cand)/this.cand<0.005){ if(++this.candN>=3){ this.bpm=fb; this.candN=0; } } else { this.cand=fb; this.candN=1; } }
  this.phaseTick=this.env.length-1-fph; this.phaseAtK=this.k-fph; };
if(typeof module!=='undefined') module.exports=TempoTracker;
