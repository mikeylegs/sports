# synthetic DJ transitions from the real tracks; writes <name>.f32 (mono 44.1k) + <name>.truth.json [[t_ms, bpm], ...]
import numpy as np, subprocess, json
SR=44100; SRC={'meduza':('/mnt/user-data/uploads/Supermode_-_Tell_Me_Why__Meduza_Remix_.m4a',126.0),'espresso':('/mnt/user-data/uploads/Sabrina_Carpenter_-_Espresso__Finlay_C_Remix_.m4a',126.0),
  'deceiver':('/mnt/user-data/uploads/Chris_Lake__Green_Velvet_-_Deceiver__Max_Styler_Remix_.m4a',126.98),'vision':('/mnt/user-data/uploads/Kaskade___CID_-_Vision_Blurred.m4a',130.05),
  'dolce':('/mnt/user-data/uploads/1790688035822_DAMEN___Gil_Glaze_-_Dolce.mp3',130.0),'dare':('/mnt/user-data/uploads/1790626271136_Gorillaz_-_Dare__Odd_Mob___OMNOM_pres__HYPERBEAM_Remix___UNRLSD_CLEAN_.m4a',134.0)}
def seg(name,start,dur,tempo=1.0):
    path,bpm=SRC[name]; filt='atempo=%.6f'%tempo
    x=subprocess.run(['ffmpeg','-v','error','-ss',str(start),'-t',str(dur*tempo+0.5),'-i',path,'-af',filt,'-ac','1','-ar',str(SR),'-f','f32le','-'],capture_output=True).stdout
    a=np.frombuffer(x,dtype=np.float32).copy(); return a[:int(dur*SR)], bpm*tempo
def ride(name,start,bpm0,bpm1,dur,steps=12):   # pitch-fader ride: piecewise tempo steps
    path,bpm=SRC[name]; out=[]; tl=[]; pos=start; t=0
    for i in range(steps):
        tb=bpm0+(bpm1-bpm0)*(i+0.5)/steps; tempo=tb/bpm; d=dur/steps
        a,_=seg(name,pos,d,tempo); out.append(a); tl.append([t*1000,tb]); pos+=d*tempo; t+=d
    return np.concatenate(out), tl, pos
def xfade(a,b,n):
    w=np.linspace(0,1,n); m=np.concatenate([a[:-n], a[-n:]*(1-w)+b[:n]*w, b[n:]]); return m
def save(nm,x,tl): (x.astype(np.float32)).tofile(nm+'.f32'); json.dump(tl,open(nm+'.truth.json','w')); print(nm, round(len(x)/SR,1),'s', tl[:3],'...')
# S1 beatmatched blend, same tempo (126 -> 126), 16 s crossfade
A,_=seg('meduza',90,60); B,_=seg('espresso',55,60); X=xfade(A,B,16*SR); save('s1_blend_same',X,[[0,126.0]])
# S2 pitch-fader ride 126 -> 130 over 30 s, then hold
A,_=seg('meduza',90,30); R,tl,pos=ride('meduza',120,126.0,130.0,30); H,_=seg('meduza',pos,25,130/126)
save('s2_ride_up',np.concatenate([A,R,H]),[[0,126.0]]+[[30000+t,b] for t,b in tl]+[[60000,130.0]])
# S3 hard cut 126.98 -> 134 (no beatmatch)
A,_=seg('deceiver',95,45); B,_=seg('dare',100,45); save('s3_cut',np.concatenate([A,B]),[[0,126.98],[45000,134.0]])
# S4 blend into a track played faster (Deceiver pushed to 130 to match Dolce), then ride it back to its own 126.98
A,_=seg('dolce',100,45); B,_=seg('deceiver',110,45,130/126.98); X=xfade(A,B,16*SR); R,tl,pos=ride('deceiver',110+45*130/126.98,130.0,126.98,24); H,_=seg('deceiver',pos,20)
save('s4_blend_ride',np.concatenate([X,R,H]),[[0,130.0]]+[[len(X)/SR*1000+t,b] for t,b in tl]+[[(len(X)/SR+24)*1000,126.98]])
