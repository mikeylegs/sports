// 60 Hz band levels for each mix (the analyzer's own band code), cached
const fs=require('fs'); const SRC=fs.readFileSync('/home/claude/w/artnet-controller.js','utf8'); const TD=(SRC.match(/const TRACK_DETECT_JS = `([\s\S]*?)`;/)||[])[1];
global.setTimeout=(fn)=>fn(); const G={}; new Function('G',TD+'\nG.tdBand=tdBand;')(G);
for(const nm of ['s1_blend_same','s2_ride_up','s3_cut','s4_blend_ride']){ const buf=fs.readFileSync(nm+'.f32'); const x=new Float32Array(buf.buffer,buf.byteOffset,buf.length/4);
  const bands=[{lo:100,hi:250,sens:1.6},{lo:1000,hi:4000,sens:0},{lo:6000,hi:12000,sens:0},{lo:12000,hi:16000,sens:0},{lo:30,hi:100,sens:0},{lo:250,hi:1000,sens:0}], lv={ticks:[]};
  bands.forEach((b,i)=>{ const out={hits:[],frames:[],ft:[],tick:[]}; G.tdBand([x],44100,b,i,out,()=>{},()=>{}); lv.ticks[i]=out.tick; });
  fs.writeFileSync(nm+'.lv.json',JSON.stringify(lv)); console.log(nm,lv.ticks[0].length); }
