// the master tempo on DJ transitions vs the known tempo timeline
const fs=require('fs'); const SRC=fs.readFileSync('/home/claude/w/artnet-controller.js','utf8'); const TJ=(SRC.match(/const TEMPO_JS = String\.raw`([\s\S]*?)`;/)||[])[1];
const G={}; new Function('G',TJ+'\nG.TT=TempoTracker; G.O=TEMPO_OPT;')(G); const OPT=Object.assign({},G.O,JSON.parse(process.env.OPT||'{}'));
for(const nm of ['s1_blend_same','s2_ride_up','s3_cut','s4_blend_ride']){ const L=JSON.parse(fs.readFileSync(nm+'.lv.json')), TL=JSON.parse(fs.readFileSync(nm+'.truth.json'));
  const truth=t=>{ let b=TL[0][1]; TL.forEach(x=>{ if(x[0]<=t) b=x[1]; }); return b; }; const tt=new G.TT(OPT), N=L.ticks[0].length, ev=[];
  for(let k=0;k<N;k++){ tt.feed([0,1,2,3,4,5].map(i=>L.ticks[i][k]||0)); if(k%30===0 && tt.bpm) ev.push([k*1000/60, tt.bpm]); }
  const inT=(e,p)=>Math.abs(e[1]-truth(e[0]))/truth(e[0])<=p; const f05=Math.round(100*ev.filter(e=>inT(e,0.005)).length/ev.length), f1=Math.round(100*ev.filter(e=>inT(e,0.01)).length/ev.length);
  const worst=Math.max(...ev.map(e=>Math.abs(e[1]-truth(e[0]))/truth(e[0])*100));
  // recovery after each truth change: time until within 0.5% for 90% of the next 10 s
  const rec=TL.slice(1).filter((x,i)=>Math.abs(x[1]-TL[i][1])>0.5 || i===0).map(x=>{ for(const e of ev.filter(e=>e[0]>=x[0])){ const nx=ev.filter(z=>z[0]>=e[0]&&z[0]<e[0]+10000); if(nx.length>=10 && nx.filter(z=>inT(z,0.005)).length>=0.9*nx.length) return ((e[0]-x[0])/1000).toFixed(1)+'s'; } return 'never'; });
  const tl=[]; for(let s=0;s<N/60;s+=8){ const e=ev.filter(z=>z[0]>=s*1000).shift(); if(e) tl.push(s+':'+e[1].toFixed(1)+'('+truth(e[0]).toFixed(1)+')'); }
  console.log(nm.padEnd(14)+'| within 0.5%: '+f05+'%  1%: '+f1+'% | worst '+worst.toFixed(1)+'% | recovery after changes: '+(rec.join(', ')||'-'));
  if(process.env.TL) console.log('   '+tl.join(' ')); }
