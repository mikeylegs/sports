// the Tracks tab's own pipeline (tdAnalyze + tdEvents) on decoded audio -> ndjson
const fs=require('fs'); const SRC=fs.readFileSync(process.argv[2],'utf8'); const TD=(SRC.match(/const TRACK_DETECT_JS = `([\s\S]*?)`;/)||[])[1];
const RJ=(SRC.match(/const RED_JS = String\.raw`([\s\S]*?)`;/)||[])[1]+'\n'+((SRC.match(/const TEMPO_JS = String\.raw`([\s\S]*?)`;/)||[])[1]||'');
global.setTimeout=(fn)=>fn(); const G={}; new Function('G',RJ+'\n'+TD+'\nG.tdAnalyze=tdAnalyze; G.tdEvents=tdEvents;')(G);
const buf=fs.readFileSync(process.env.AUD); const x=new Float32Array(buf.buffer,buf.byteOffset,buf.length/4);
const bands=[{lo:100,hi:250,sens:1.6},{lo:1000,hi:4000,sens:1.05},{lo:6000,hi:12000,sens:1.3},{lo:12000,hi:16000,sens:1.3}];
G.tdAnalyze([x],44100,bands,()=>{},out=>{ const ev=G.tdEvents(out,{k:'start',src:'track',track:process.env.AUD,bands:bands,t:0},[],x.length/44.1);
  fs.writeFileSync(process.argv[3],ev.map(e=>JSON.stringify(e)).join('\n')+'\n'); console.log(process.argv[3].split('/').pop(),'tp',ev.filter(e=>e.k==='tp').length,'rd',ev.filter(e=>e.k==='rd').length,'rb',ev.filter(e=>e.k==='rb').length,'frames e',ev.find(e=>e.k==='f').e.length); });
